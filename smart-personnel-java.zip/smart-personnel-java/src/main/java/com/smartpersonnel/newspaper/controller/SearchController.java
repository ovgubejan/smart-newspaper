package com.smartpersonnel.newspaper.controller;

import com.smartpersonnel.newspaper.model.News;
import com.smartpersonnel.newspaper.service.NewsService;
import com.smartpersonnel.newspaper.session.UserSessionData;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
public class SearchController {

    private final NewsService newsService;
    private final UserSessionData userSessionData;

    @GetMapping("/search")
    public String search(@RequestParam(value = "query", required = false, defaultValue = "") String query, Model model) {
        List<News> results = new ArrayList<>();
        
        if (!query.isBlank()) {
            String lowerQuery = query.toLowerCase();
            results = newsService.getAllNews().stream()
                    .filter(n -> n.getTitle().toLowerCase().contains(lowerQuery) || 
                                 n.getSummary().toLowerCase().contains(lowerQuery))
                    .collect(Collectors.toList());
        }

        model.addAttribute("query", query);
        model.addAttribute("results", results);
        model.addAttribute("hasSearched", !query.isBlank());
        model.addAttribute("readArticles", userSessionData.getReadArticles());
        
        return "search";
    }
}
