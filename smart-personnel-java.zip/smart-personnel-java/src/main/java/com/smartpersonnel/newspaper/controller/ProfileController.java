package com.smartpersonnel.newspaper.controller;

import com.smartpersonnel.newspaper.session.UserSessionData;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class ProfileController {

    private final UserSessionData userSessionData;

    @GetMapping("/profile")
    public String profile(Model model) {
        model.addAttribute("user", userSessionData.getCurrentUser());
        model.addAttribute("preferencesCount", userSessionData.getPreferences().size());
        model.addAttribute("bookmarksCount", userSessionData.getBookmarks().size());
        model.addAttribute("readCount", userSessionData.getReadArticles().size());
        return "profile";
    }
}
