package com.smartpersonnel.newspaper.controller;

import com.smartpersonnel.newspaper.model.News;
import com.smartpersonnel.newspaper.service.NewsService;
import com.smartpersonnel.newspaper.session.UserSessionData;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
public class BookmarksController {

    private final NewsService newsService;
    private final UserSessionData userSessionData;

    @GetMapping("/bookmarks")
    public String bookmarks(Model model) {
        List<News> bookmarkedNews = newsService.getAllNews().stream()
                .filter(n -> userSessionData.getBookmarks().contains(n.getId()))
                .collect(Collectors.toList());
                
        model.addAttribute("bookmarks", bookmarkedNews);
        model.addAttribute("readArticles", userSessionData.getReadArticles());
        return "bookmarks";
    }

    @PostMapping("/bookmarks/{id}/remove")
    public String removeBookmark(@PathVariable("id") int id) {
        userSessionData.getBookmarks().remove(Integer.valueOf(id));
        return "redirect:/bookmarks";
    }
}
