package com.smartpersonnel.newspaper.config;

import com.smartpersonnel.newspaper.session.UserSessionData;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
@RequiredArgsConstructor
public class AuthInterceptor implements HandlerInterceptor {

    private final UserSessionData userSessionData;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (!userSessionData.isLoggedIn()) {
            response.sendRedirect("/login");
            return false;
        }
        return true;
    }
}
