package com.smartpersonnel.newspaper.service;

import com.smartpersonnel.newspaper.model.News;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class NewsService {
    
    private final List<News> allNews = new ArrayList<>();

    @PostConstruct
    public void init() {
        allNews.add(new News(1, "AI teknolojileri hızla gelişiyor", "Technology", "Tech Daily", "2026-03-10", 95, 
                "Yapay zeka sistemleri birçok sektörde daha fazla kullanılmaya başladı.", 
                "Yapay zeka artık eğitimden sağlığa, finanstan güvenliğe kadar birçok alanda aktif olarak kullanılmaya başlanmıştır. Bu gelişim, kurumların daha hızlı ve verimli karar almasına yardımcı olmaktadır."));
        
        allNews.add(new News(2, "Şirketler ekonomik büyümeye odaklanıyor", "Business", "Business World", "2026-03-12", 80, 
                "Kurumsal yatırımlar ve yeni stratejiler iş dünyasında öne çıkıyor.", 
                "Kurumsal şirketler yeni dönem stratejilerini büyüme, verimlilik ve dijital dönüşüm üzerine kuruyor. Bu süreçte veri odaklı karar verme daha önemli hale geliyor."));
        
        allNews.add(new News(3, "Yeni sağlık araştırmaları umut veriyor", "Health", "Health News", "2026-03-15", 88, 
                "Sağlık alanındaki yeni araştırmalar dikkat çekici sonuçlar üretiyor.", 
                "Son dönemde yapılan sağlık araştırmaları, erken teşhis ve kişiselleştirilmiş tedavi yöntemleri açısından umut verici sonuçlar ortaya koymaktadır."));
        
        allNews.add(new News(4, "Bilim dünyasında yeni keşifler yapıldı", "Science", "Science Globe", "2026-03-11", 72, 
                "Yeni bilimsel çalışmalar önemli sonuçlar ortaya koymaya başladı.", 
                "Bilim dünyasında yapılan yeni araştırmalar, hem akademik hem de endüstriyel uygulamalar açısından dikkat çekici fırsatlar sunmaktadır."));
        
        allNews.add(new News(5, "Eğitim teknolojilerinde yeni dönem", "Education", "Edu Today", "2026-03-14", 67, 
                "Dijital eğitim araçları öğrenme deneyimini değiştirmeye devam ediyor.", 
                "Eğitim teknolojileri, öğrenci takibi, kişiselleştirilmiş içerik ve uzaktan öğrenme süreçlerinde önemli katkılar sağlamaktadır."));
    }

    public List<News> getAllNews() {
        return allNews;
    }

    public Optional<News> getNewsById(int id) {
        return allNews.stream().filter(n -> n.getId() == id).findFirst();
    }
}
