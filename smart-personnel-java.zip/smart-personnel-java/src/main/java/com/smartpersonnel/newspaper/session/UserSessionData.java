package com.smartpersonnel.newspaper.session;

import com.smartpersonnel.newspaper.model.User;
import lombok.Data;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import java.util.ArrayList;
import java.util.List;

@Data
@Component
@SessionScope
public class UserSessionData {
    private User currentUser;
    private List<String> preferences = new ArrayList<>();
    private List<Integer> bookmarks = new ArrayList<>();
    private List<Integer> readArticles = new ArrayList<>();

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public void clear() {
        currentUser = null;
        preferences.clear();
        bookmarks.clear();
        readArticles.clear();
    }
}
