package com.smartpersonnel.newspaper.controller;

import com.smartpersonnel.newspaper.session.UserSessionData;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Arrays;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class PreferencesController {

    private final UserSessionData userSessionData;
    private final List<String> availableCategories = Arrays.asList(
            "Technology", "Business", "Health", "Science", "Education", "Entertainment"
    );

    @GetMapping("/preferences")
    public String preferences(Model model) {
        model.addAttribute("allCategories", availableCategories);
        model.addAttribute("selectedCategories", userSessionData.getPreferences());
        return "preferences";
    }

    @PostMapping("/preferences")
    public String savePreferences(@RequestParam(value = "categories", required = false) List<String> categories) {
        if (categories == null) {
            userSessionData.getPreferences().clear();
        } else {
            userSessionData.setPreferences(categories);
        }
        return "redirect:/feed";
    }
}
