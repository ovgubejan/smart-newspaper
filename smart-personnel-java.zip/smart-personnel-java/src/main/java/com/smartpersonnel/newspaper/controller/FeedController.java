package com.smartpersonnel.newspaper.controller;

import com.smartpersonnel.newspaper.model.News;
import com.smartpersonnel.newspaper.service.NewsService;
import com.smartpersonnel.newspaper.session.UserSessionData;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
public class FeedController {

    private final NewsService newsService;
    private final UserSessionData userSessionData;

    @GetMapping("/feed")
    public String feed(@RequestParam(value = "sortBy", defaultValue = "relevance") String sortBy, Model model) {
        List<News> filteredNews = newsService.getAllNews();

        if (!userSessionData.getPreferences().isEmpty()) {
            filteredNews = filteredNews.stream()
                    .filter(n -> userSessionData.getPreferences().contains(n.getCategory()))
                    .collect(Collectors.toList());
        }

        if ("date".equals(sortBy)) {
            filteredNews.sort((a, b) -> b.getDate().compareTo(a.getDate()));
        } else if ("popularity".equals(sortBy) || "relevance".equals(sortBy)) {
            filteredNews.sort((a, b) -> Integer.compare(b.getPopularity(), a.getPopularity()));
        }

        model.addAttribute("newsList", filteredNews);
        model.addAttribute("preferences", userSessionData.getPreferences());
        model.addAttribute("readArticles", userSessionData.getReadArticles());
        model.addAttribute("sortBy", sortBy);

        return "feed";
    }

    @GetMapping("/article/{id}")
    public String article(@PathVariable("id") int id, Model model) {
        Optional<News> newsOpt = newsService.getNewsById(id);
        if (newsOpt.isEmpty()) {
            return "redirect:/feed";
        }
        
        News news = newsOpt.get();
        if (!userSessionData.getReadArticles().contains(id)) {
            userSessionData.getReadArticles().add(id);
        }

        model.addAttribute("article", news);
        model.addAttribute("isBookmarked", userSessionData.getBookmarks().contains(id));
        return "article";
    }

    @PostMapping("/article/{id}/bookmark")
    public String toggleBookmark(@PathVariable("id") int id) {
        List<Integer> bookmarks = userSessionData.getBookmarks();
        if (bookmarks.contains(id)) {
            bookmarks.remove(Integer.valueOf(id));
        } else {
            bookmarks.add(id);
        }
        return "redirect:/article/" + id;
    }
}
