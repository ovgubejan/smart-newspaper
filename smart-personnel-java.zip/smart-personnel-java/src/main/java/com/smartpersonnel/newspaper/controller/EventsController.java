package com.smartpersonnel.newspaper.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class EventsController {

    @GetMapping("/events")
    public String events(Model model) {
        return "events";
    }
}
