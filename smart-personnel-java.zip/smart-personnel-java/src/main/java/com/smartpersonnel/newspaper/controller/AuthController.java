package com.smartpersonnel.newspaper.controller;

import com.smartpersonnel.newspaper.model.User;
import com.smartpersonnel.newspaper.session.UserSessionData;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final UserSessionData userSessionData;
    
    // In-memory mock DB for registered users
    private static final Map<String, User> mockUsersDb = new HashMap<>();

    @GetMapping("/login")
    public String loginPage(Model model) {
        if (userSessionData.isLoggedIn()) {
            return "redirect:/feed";
        }
        return "login";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam("email") String email, @RequestParam("password") String password, Model model) {
        User user = mockUsersDb.get(email);
        
        if (user == null) {
            model.addAttribute("error", "Önce kayıt olmanız gerekiyor.");
            return "login";
        }
        
        if (user.getPassword().equals(password)) {
            userSessionData.setCurrentUser(user);
            return "redirect:/preferences";
        } else {
            model.addAttribute("error", "E-posta veya şifre hatalı.");
            return "login";
        }
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        if (userSessionData.isLoggedIn()) {
            return "redirect:/feed";
        }
        return "register";
    }

    @PostMapping("/register")
    public String doRegister(@RequestParam("fullName") String fullName, @RequestParam("email") String email, @RequestParam("password") String password, Model model) {
        if (mockUsersDb.containsKey(email)) {
            model.addAttribute("error", "Bu e-posta zaten kayıtlı.");
            return "register";
        }
        
        User newUser = User.builder()
                .fullName(fullName)
                .email(email)
                .password(password)
                .role("User")
                .build();
                
        mockUsersDb.put(email, newUser);
        return "redirect:/login";
    }

    @GetMapping("/logout")
    public String logout() {
        userSessionData.clear();
        return "redirect:/login";
    }
}
