package com.smartpersonnel.newspaper.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class News {
    private int id;
    private String title;
    private String category;
    private String source;
    private String date;
    private int popularity;
    private String summary;
    private String content;
}
