// js/main.js

// --- GLOBAL HELPERS ---
function getFallbackImage(category, artId) {
    const normalizedCategory = (category || "").toLowerCase();

    // Pseudo-random hash for variety
    let hash = 0;
    const str = String(artId || Math.random());
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    hash = Math.abs(hash);

    let photoIds = ["1495020689067-958852a7765e", "1504711434969-e33886168f5c", "1585829365295-ab7cd400c167", "1508921340878-ba53e1b016b8"]; // Default
    if (normalizedCategory.includes("tech") || normalizedCategory.includes("teknoloji")) {
        photoIds = ["1518770660439-4636190af475", "1550751827438-b7ab4f8664ec", "1519389953810-c4709d1105ce", "1451187580459-43490279c0fa", "1526374965328-7f61d4dc18c5"];
    } else if (normalizedCategory.includes("politi") || normalizedCategory.includes("siyaset")) {
        photoIds = ["1529107386315-e1a2ed48a620", "1555848962-6eca55f9ce15", "1541872703-74c5e43aece1", "1575314022359-19c240188ef7"];
    } else if (normalizedCategory.includes("econ") || normalizedCategory.includes("ekonomi")) {
        photoIds = ["1611974789855-9c2a0a7236a3", "1590283603385-17ffb1b6dc24", "1526304640581-d334cdbbf45e", "1460925895917-afdab827c52f", "1518186285570-0814bd039bbf"];
    } else if (normalizedCategory.includes("sport") || normalizedCategory.includes("spor")) {
        photoIds = ["1540747913346-19e32dc3e97e", "1461896836934-ffe607ba8211", "1517649763962-0c623066013b", "1500512635930-6dbca41c10d3", "1511527661048-7098e910af6e"];
    } else if (normalizedCategory.includes("health") || normalizedCategory.includes("sağlık")) {
        photoIds = ["1505751172876-fa1923c5c528", "1532938911079-1b06ac7ceec7", "1584308666744-247e8f68e0d6", "1576091160399-112ba8d25d1d"];
    } else if (normalizedCategory.includes("world") || normalizedCategory.includes("dünya")) {
        photoIds = ["1451187580459-43490279c0fa", "1507413245164-6160d8298b31", "1521295121783-8a321d551ad2", "1496055401348-18e3beed1281", "1488190256565-d450ae71ed62"];
    }

    let photoId = photoIds[hash % photoIds.length];
    return `https://images.unsplash.com/photo-${photoId}?auto=format&fit=crop&w=800&q=80`;
}

function escapeAttr(value) {
    return String(value ?? "").replace(/'/g, "\\'");
}

function formatSourceName(sourceStr) {
    if (!sourceStr) return "HABER";
    if (String(sourceStr).toLowerCase().startsWith("http")) {
        try {
            let host = new URL(sourceStr).hostname.replace(/^www\./i, "");
            host = host.replace(/^feeds\./i, "").replace(/^rss\./i, "");
            return host.toUpperCase();
        } catch (e) { }
    }
    return String(sourceStr).toUpperCase();
}

function escapeHtml(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function formatAISummary(summaryText) {
    const cleaned = String(summaryText || "")
        .replace(/\r\n/g, "\n")
        .replace(/^[\-\u2022]\s*/gm, "")
        .trim();

    const paragraphs = cleaned
        .split(/\n+/)
        .map(line => line.trim())
        .filter(Boolean);

    if (paragraphs.length === 0) {
        return `
            <span class="ai-badge"><i class="fas fa-robot"></i> Yapay Zeka Ozeti</span>
            <p class="text-gray-300 italic">Ozet su anda hazir degil.</p>
        `;
    }

    return `
        <span class="ai-badge"><i class="fas fa-robot"></i> Yapay Zeka Ozeti</span>
        <div class="space-y-2">
            ${paragraphs.map(p => `<p class="leading-relaxed">${escapeHtml(p)}</p>`).join("")}
        </div>
    `;
}

function formatArticleContent(contentText) {
    const cleaned = String(contentText || "")
        .replace(/\r\n/g, "\n")
        .replace(/\n{3,}/g, "\n\n")
        .trim();

    const paragraphs = cleaned
        .split(/\n\s*\n/)
        .map(block => block.replace(/\n/g, " ").trim())
        .filter(Boolean);

    if (paragraphs.length === 0) {
        return `
            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-dashed border-gray-300 dark:border-slate-700">
                <p class="text-sm text-gray-500 dark:text-gray-300">Icerik bulunamadi.</p>
            </div>
        `;
    }

    return `
        <div class="space-y-4 text-sm md:text-[14px] text-slate-700 dark:text-gray-200 leading-7">
            ${paragraphs.map(p => `<p>${escapeHtml(p)}</p>`).join("")}
        </div>
    `;
}

function buildLocalArticleContent(art) {
    const parts = [];
    const title = String(art?.title || "").trim();
    const description = String(art?.description || "").trim();
    const summary = String(art?.ai_summary || art?.summary || "").trim();

    if (title) parts.push(title);
    if (description) parts.push(description);
    if (summary && summary !== description) {
        parts.push(summary.replace(/^[\-\u2022]\s*/gm, "").trim());
    }

    return parts.filter(Boolean).join("\n\n");
}

function scheduleNonCriticalTask(task, delay = 0) {
    const runner = () => window.setTimeout(task, delay);
    if (typeof window.requestIdleCallback === "function") {
        window.requestIdleCallback(runner, { timeout: 1500 });
        return;
    }
    runner();
}
// ---------------------

document.addEventListener("DOMContentLoaded", () => {

    const searchInput = document.getElementById("searchInput");
    let categoryNavs = document.querySelectorAll("#categoryNav li:not(#gazette-nav-btn):not(#nav-comparison-tab)");
    const heroHeadline = document.getElementById("hero-headline");
    const topStoriesGrid = document.getElementById("top-stories-grid");
    const pinnedFeed = document.getElementById("pinnedFeed");
    const categoryChartCanvas = document.getElementById("preferenceChart");
    let categoryChart;

    // Global data and widgets are delayed slightly so the first paint is not blocked.
    scheduleNonCriticalTask(() => initGlobalPulse(), 100);
    scheduleNonCriticalTask(() => initSidebarWidgets(), 200);
    // --- NEW: RAG Chat Initialization ---
    initRagChat();
    // --- NEW: Global Chat Initialization ---
    scheduleNonCriticalTask(() => initGlobalChat(), 250);
    // --- NEW: Backend Features (Clusters & WS) ---
    scheduleNonCriticalTask(() => initCriticalNewsWebSocket(), 800);

    // Sayfalama
    const ARTICLES_PER_PAGE = 8;
    let currentPage = 1;

    // --- Kategori haritası (data-category → Türkçe label) ---
    const CAT_MAP = {
        "Home": "Anasayfa",
        "World": "Dünya",
        "Politics": "Politika",
        "Economy": "Ekonomi",
        "Technology": "Teknoloji",
        "Sports": "Spor",
        "Health": "Sağlık"
    };
    const ALL_CATS = ["World", "Politics", "Economy", "Technology", "Sports", "Health"];

    // Nav'ı tercihlere göre yenile — auth.js'ten de çağrılabilir
    // Kategori → i18n key mapping
    const catI18nKey = {
        "Home": "home", "Technology": "technology", "Politics": "politics",
        "Economy": "economy", "Sports": "sports", "Health": "health",
        "Science": "science", "World": "world", "Weather": "weather",
        "Culture": "culture", "Education": "education"
    };

    function getCatLabel(cat) {
        const key = catI18nKey[cat];
        if (key && typeof t === 'function') {
            const translated = t(key);
            if (translated && translated !== key) return translated;
        }
        return CAT_MAP[cat] || cat;
    }

    window.updateNavForPreferences = function (prefs) {
        const navList = document.getElementById('categoryNav');
        if (!navList) return;

        // Gösterilecek kategoriler: Anasayfa + tercihler (yoksa tümü)
        const showCats = (prefs && prefs.length > 0) ? prefs : ALL_CATS;
        const homeLabel = getCatLabel("Home");
        const gazetteLabel = (typeof t === 'function') ? t('gazette') : 'Gazete';

        navList.innerHTML = `
            <li data-category="Home"
                class="block py-4 border-b-2 border-brandRed text-brandRed cursor-pointer nav-item">
                ${homeLabel}
            </li>
            ${showCats.map(cat => `
            <li data-category="${cat}"
                class="block py-4 border-b-2 border-transparent hover:text-brandRed transition cursor-pointer nav-item">
                ${getCatLabel(cat)}
            </li>`).join('')}
            <li id="gazette-nav-btn"
                onclick="openGazetteModal()"
                class="block py-4 border-b-2 border-transparent hover:text-yellow-400 transition cursor-pointer flex items-center gap-1.5 text-yellow-300 font-black nav-item">
                <i class="fas fa-newspaper"></i> ${gazetteLabel}
            </li>
            <li id="nav-comparison-tab"
                data-category="Comparison"
                onclick="window.openComparisonPage()"
                class="block py-4 border-b-2 border-transparent hover:text-indigo-300 transition cursor-pointer flex items-center gap-1.5 text-indigo-300 font-black nav-item">
                <i class="fas fa-layer-group" style="font-size:11px"></i>
                Karşılaştırma
                <span style="background:#CC0000;color:#fff;font-size:8px;font-weight:900;padding:2px 6px;border-radius:3px;letter-spacing:0.1em;margin-left:2px;">BETA</span>
            </li>
        `;

        // Tıklama eventlerini yeniden bağla (Comparison ve gazette hariç)
        categoryNavs = document.querySelectorAll('#categoryNav .nav-item:not(#gazette-nav-btn):not(#nav-comparison-tab)');
        bindNavEvents();

    };

    // Nav tıklama eventlerini bağla (yeniden kullanılabilir)
    function bindNavEvents() {
        categoryNavs.forEach(nav => {
            nav.addEventListener('click', (e) => {
                const cat = e.currentTarget.getAttribute('data-category');
                if (!cat || cat === 'Comparison') return;
                // Karşılaştırma sayfası açıksa kapat
                _hideComparisonPage();
                categoryNavs.forEach(n => n.classList.remove('text-brandRed', 'border-b-2', 'border-brandRed'));
                e.currentTarget.classList.add('text-brandRed', 'border-b-2', 'border-brandRed');
                currentPage = 1;
                AppState.setCategory(cat);
                window._globalNewsPage = 1;
                if (window._globalNewsData) renderGlobalNewsGrid(window._globalNewsData);
            });
        });
    }

    function _hideComparisonPage() {
        const sec = document.getElementById('comparison-tab-section');
        if (sec) sec.classList.add('hidden');
        document.querySelectorAll('#main-content-column > section:not(#comparison-tab-section), #main-content-column > div:not(#comparison-tab-section)')
            .forEach(el => el.classList.remove('hidden'));
        const compTab = document.getElementById('nav-comparison-tab');
        if (compTab) { compTab.classList.remove('text-brandRed','border-b-2','border-brandRed'); compTab.classList.add('border-transparent'); }
    }

    window.openComparisonPage = function() {
        document.querySelectorAll('#categoryNav li').forEach(n => n.classList.remove('text-brandRed','border-b-2','border-brandRed'));
        const compTab = document.getElementById('nav-comparison-tab');
        if (compTab) { compTab.classList.add('text-brandRed','border-b-2','border-brandRed'); compTab.classList.remove('border-transparent'); }

        document.querySelectorAll('#main-content-column > section:not(#comparison-tab-section), #main-content-column > div:not(#comparison-tab-section)')
            .forEach(el => el.classList.add('hidden'));

        const sec = document.getElementById('comparison-tab-section');
        if (sec) sec.classList.remove('hidden');

        if (typeof window.initComparisonTab === 'function') {
            window.initComparisonTab().then(() => {
                const statsEl = document.getElementById('comp-tab-hero-stats');
                if (statsEl && window._CE) {
                    const cnt = window._CE.pairs ? window._CE.pairs.length : 0;
                    statsEl.innerHTML = cnt > 0
                        ? `<span><i class="fas fa-check-circle" style="color:#10b981;margin-right:6px"></i>${cnt} karşılaştırma tespit edildi</span>`
                        : `<span><i class="fas fa-info-circle" style="color:#f59e0b;margin-right:6px"></i>Ek veriler API'den çekildi</span>`;
                }
            }).catch(err => console.error('[CE] initComparisonTab hatası:', err));
        }
    };


    // Widget Nodes
    const widgetSettingsBtn = document.getElementById("widgetSettingsBtn");
    const settingsPanel = document.getElementById("settingsPanel");
    const pinSettings = document.getElementById("pinSettings");
    const saveSettingsBtn = document.getElementById("saveSettingsBtn");

    // --- 2. Widgets (Clock, Date, Weather) ---
    function updateDateTime() {
        const now = new Date();
        const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit' };

        const dateEl = document.getElementById("current-date");
        const timeEl = document.getElementById("current-time");

        const langStr = (window.currentLang || 'tr') === 'en' ? 'en-US' : (window.currentLang || 'tr');
        if (dateEl) dateEl.innerHTML = `<i class="far fa-calendar-alt mr-1.5 text-brandRed"></i> ${now.toLocaleDateString(langStr, dateOptions)}`;
        if (timeEl) timeEl.innerHTML = `<i class="far fa-clock mr-1.5 text-brandRed font-bold"></i> ${now.toLocaleTimeString(langStr, timeOptions)}`;
    }

    const cities = [
        { name: "Istanbul", temp: "14°C", icon: "fa-cloud-sun", color: "text-yellow-400" },
        { name: "London", temp: "11°C", icon: "fa-cloud-showers-heavy", color: "text-blue-400" },
        { name: "New York", temp: "9°C", icon: "fa-wind", color: "text-gray-400" },
        { name: "Tokyo", temp: "18°C", icon: "fa-sun", color: "text-yellow-500" }
    ];
    let cityIndex = 0;

    function rotateWeather() {
        const widget = document.getElementById("weather-widget");
        if (!widget) return;

        widget.classList.add("opacity-0", "-translate-y-2");

        setTimeout(() => {
            cityIndex = (cityIndex + 1) % cities.length;
            const city = cities[cityIndex];
            widget.innerHTML = `
                <i class="fas ${city.icon} ${city.color} mr-1.5"></i> 
                <span>${city.name}</span> 
                <span class="ml-1 font-bold">${city.temp}</span>
            `;
            widget.classList.remove("opacity-0", "-translate-y-2");
        }, 500);
    }

    setInterval(updateDateTime, 1000);
    setInterval(rotateWeather, 5000);
    updateDateTime();

    // --- 3. Event Listeners ---
    let debounceTimer;
    if (searchInput) {
        searchInput.addEventListener("input", (e) => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                currentPage = 1; // Arama değişince 1. sayfaya dön
                AppState.setSearchQuery(e.target.value);
            }, 500);
        });
    }

    // Nav event'lerini ilk kez bağla
    bindNavEvents();

    // --- İLK YÜKLEME: Session varsa nav'ı güncelle ---
    const initSession = typeof Auth !== 'undefined' ? Auth.getSession() : null;
    if (initSession && initSession.selectedTopics && initSession.selectedTopics.length > 0) {
        updateNavForPreferences(initSession.selectedTopics);
        AppState.userPrefs = initSession.selectedTopics;
    } else {
        // Nav'a Gazete butonunu yine de ekle
        updateNavForPreferences([]);
    }

    if (widgetSettingsBtn) {
        widgetSettingsBtn.addEventListener("click", () => {
            settingsPanel.classList.toggle("hidden");
            renderSettingsCheckboxes();
        });
        saveSettingsBtn.addEventListener("click", () => {
            settingsPanel.classList.add("hidden");
        });
    }

    function renderSettingsCheckboxes() {
        const categories = ["Technology", "Politics", "Economy", "Sports"];
        pinSettings.innerHTML = categories.map(cat => `
            <label class="flex items-center space-x-2 cursor-pointer text-gray-700">
                <input type="checkbox" onchange="AppState.togglePin('${cat}')" ${AppState.pinnedCategories.includes(cat) ? 'checked' : ''}>
                <span>${cat}</span>
            </label>
        `).join("");
    }

    // --- 4. News Image Helpers ---
    // Moved to global scope at the top of the file

    function getVisibleArticles({ applySearch = true } = {}) {
        const { currentCategory, searchQuery, articles, userPrefs } = AppState;
        let visibleArticles = [...articles];

        // Only filter by userPrefs if we are on the Home dashboard
        if (currentCategory === "Home" && userPrefs && userPrefs.length > 0) {
            visibleArticles = visibleArticles.filter(a => userPrefs.includes(a.ai_category));
        } else if (currentCategory !== "Home" && currentCategory !== "World" && currentCategory !== "Dashboard") {
            // If viewing a specific category, show only that category's news
            visibleArticles = visibleArticles.filter(a => a.ai_category === currentCategory);
        }

        if (applySearch && searchQuery) {
            visibleArticles = visibleArticles.filter(a =>
                (a.title || "").toLowerCase().includes(searchQuery) ||
                (a.ai_summary && a.ai_summary.toLowerCase().includes(searchQuery))
            );
        }

        return visibleArticles;
    }

    function renderPreferenceChart(filteredArticles) {
        const { userPrefs } = AppState;
        const canvas = document.getElementById('preferenceChart');
        if (!canvas) return;

        const prefs = (userPrefs && userPrefs.length > 0) ? userPrefs : ALL_CATS;
        const counts = prefs.map(cat =>
            filteredArticles.filter(article => article.ai_category === cat).length
        );

        if (categoryChart) {
            categoryChart.destroy();
        }

        categoryChart = new Chart(canvas, {
            type: "doughnut",
            data: {
                labels: prefs.map(cat => CAT_MAP[cat] || cat),
                datasets: [{
                    data: counts,
                    backgroundColor: ["#1E293B", "#CC0000", "#0F766E", "#B45309", "#4338CA", "#047857"],
                    borderWidth: 2,
                    borderColor: '#fff',
                    hoverBorderWidth: 3,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                cutout: '55%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            font: { size: 10, weight: '700', family: 'Inter' },
                            padding: 12,
                            usePointStyle: true,
                            pointStyleWidth: 8
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => ` ${ctx.label}: ${ctx.raw} haber`
                        }
                    }
                }
            }
        });
    }

    // Profil modalı açıldığında grafiği renderla
    window.renderProfileChart = function () {
        const displayArticles = getVisibleArticles({ applySearch: false });
        renderPreferenceChart(displayArticles);
    };

    // Main Hydration Function (FR-5.1)
    function hydrateDOM() {
        // Dışarıdan sayfa geçişi istendi mi?
        if (AppState._requestedPage !== undefined) {
            const totalForCheck = AppState.articles.length;
            const newPage = AppState._requestedPage;
            if (newPage >= 1 && newPage <= Math.ceil(totalForCheck / ARTICLES_PER_PAGE)) {
                currentPage = newPage;
            }
            delete AppState._requestedPage;
        }

        const { currentCategory, articles, pinnedCategories, userPrefs } = AppState;
        const displayArticles = getVisibleArticles();
        renderPreferenceChart(displayArticles);

        // --- Layout Visibility Management ---
        const categoryFocusSection = document.getElementById("category-focus");
        if (currentCategory !== "Home") {
            if (categoryFocusSection) categoryFocusSection.classList.add("hidden");
        } else {
            if (categoryFocusSection) categoryFocusSection.classList.remove("hidden");
        }

        // Güncel Haberler Grid'ini senkronize et (Örn: Tercihler değiştiğinde)
        if (window._globalNewsData) {
            renderGlobalNewsGrid(window._globalNewsData);
        }

        // --- Render Hero Carousel ---
        if (displayArticles.length > 0 || (window._globalNewsData && window._globalNewsData.length > 0)) {
            // Carousel verilerini hazırla: Yerel + Global haberleri karıştır
            const localArts = displayArticles.slice(0, 3).map(art => ({
                id: art.id,
                title: art.title,
                summary: art.ai_summary || '',
                category: art.ai_category || 'Haber',
                source: art.source || 'BİLİMHABER',
                image: (art.image_url && art.image_url.trim().length > 10)
                    ? art.image_url
                    : getFallbackImage(art.ai_category, art.id),
                fallbackImage: getFallbackImage(art.ai_category, art.id),
                isGlobal: false
            }));

            // Global haberlerden de ekle
            const globalNews = window._globalNewsData || [];
            const globalArts = globalNews.slice(0, 5).map(item => ({
                id: `global_${btoa(item.link)}`,
                title: item.title,
                summary: item.description || '',
                category: item.country || 'DÜNYA',
                source: item.source || 'Global',
                image: (item.image_url && item.image_url.trim().length > 10)
                    ? item.image_url
                    : getFallbackImage('World', item.link),
                fallbackImage: getFallbackImage('World', item.link),
                isGlobal: true,
                link: item.link
            }));

            // Karıştır: yerel-global-yerel-global... sıralaması
            const mixed = [];
            const maxLen = Math.max(localArts.length, globalArts.length);
            for (let i = 0; i < maxLen; i++) {
                if (i < localArts.length) mixed.push(localArts[i]);
                if (i < globalArts.length) mixed.push(globalArts[i]);
            }

            window._heroCarouselData = mixed.length > 0 ? mixed : localArts;

            // İlk yüklemede veya veri değişiminde carousel'ı başlat
            const newHash = JSON.stringify(window._heroCarouselData.map(d => d.id));
            if (!window._heroCarouselInit || window._heroCarouselDataHash !== newHash) {
                window._heroCarouselDataHash = newHash;
                initHeroCarousel();
            }
        }

        // --- Render Top Stories Grid (Sayfalama ile) ---
        // Eğer global haberler (105 kaynak) zaten yüklendiyse, grid'i ezme —
        // renderGlobalNewsGrid() zaten doldurdu. Sadece global veri yoksa backend haberlerini göster.
        let gridArts = [];
        let totalPages = 1;
        let startIdx = 0;

        if (!window._globalNewsData || window._globalNewsData.length === 0) {
            gridArts = displayArticles.slice(3);
            totalPages = Math.ceil(gridArts.length / ARTICLES_PER_PAGE);
            startIdx = (currentPage - 1) * ARTICLES_PER_PAGE;
            const pageArts = gridArts.slice(startIdx, startIdx + ARTICLES_PER_PAGE);

            if (gridArts.length === 0) {
                topStoriesGrid.innerHTML = '<div class="col-span-1 sm:col-span-2 text-gray-500 py-12 text-center border overflow-hidden rounded-md bg-white/40 dark:bg-slate-800/40 backdrop-blur-sm border-gray-200/50">Haber bulunamadı.</div>';
            } else {
                topStoriesGrid.innerHTML = pageArts.map((art) => {
                    const catColorMap = {
                        "Technology": "bg-darkBlue",
                        "Economy": "bg-green-700",
                        "Sports": "bg-orange-600",
                        "Politics": "bg-brandRed",
                        "Health": "bg-teal-600"
                    };
                    const color = catColorMap[art.ai_category] || "bg-brandRed";
                    const cardImg = (art.image_url && art.image_url.trim().length > 10)
                        ? art.image_url
                        : getFallbackImage(art.ai_category, art.id);

                    return `
                    <article class="flex flex-col group cursor-pointer article-card p-2 border border-transparent hover:border-gray-200 hover:bg-gray-50 transition min-h-[420px]" onclick="window.readArticle('${escapeAttr(art.id)}')" data-article-id="${escapeHtml(art.id)}">
                        <div class="block rounded-sm overflow-hidden mb-4 h-52 relative border-b-2 border-brandRed/20 bg-slate-100">
                            <img loading="lazy" src="${cardImg}" class="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all duration-500" onerror="this.onerror=null; this.src='${getFallbackImage(art.ai_category, art.id)}'">
                            <span class="absolute top-0 left-0 px-2 py-0.5 ${color} text-white text-[9px] font-black uppercase tracking-tighter shadow-md">${art.ai_category}</span>
                        </div>
                        <div class="flex justify-between items-start gap-2 mb-3">
                            <h3 class="text-lg font-black leading-tight group-hover:text-brandRed transition-colors dark:text-gray-100 font-serif">${art.title || "Haber Başlığı"}</h3>
                            <button onclick="handleLike('${escapeAttr(art.id)}', event)" data-like-button="1" class="text-gray-400 hover:text-brandRed transition px-2" title="Haberi Beğen">
                                <i class="fas fa-heart"></i>
                            </button>
                        </div>
                        
                        ${art.ai_summary && art.ai_summary.trim().length > 0 ? `
                        <div class="bg-gray-100 dark:bg-slate-800 p-3 rounded-sm text-xs text-gray-700 dark:text-gray-400 mb-4 border-l-2 border-brandRed font-serif italic line-clamp-3">
                             ${art.ai_summary}
                        </div>
                        ` : ''}
                        
                        <div class="mt-auto pt-3 border-t border-gray-100 dark:border-slate-800 text-[10px] text-softGray dark:text-gray-500 font-black uppercase tracking-widest flex justify-between">
                            <span><i class="far fa-clock mr-1 text-brandRed"></i> ${art.source === 'Hürriyet' ? 'HÜRRİYET' : 'YENİ HABER'}</span>
                            <span>${art.source || "BİLİMHABER"}</span>
                        </div>
                    </article>
                    `;
                }).join("");
            }
        } else {
            // Global haberler var — renderGlobalNewsGrid() zaten grid'i doldurdu, sayfalamayı gizle
            let paginationEl2 = document.getElementById('pagination-controls');
            if (paginationEl2) paginationEl2.innerHTML = '';
        }

        // --- Sayfalama Kontrolleri ---
        let paginationEl = document.getElementById('pagination-controls');
        if (!paginationEl) {
            paginationEl = document.createElement('div');
            paginationEl.id = 'pagination-controls';
            topStoriesGrid.parentElement.appendChild(paginationEl);
        }

        if (totalPages <= 1) {
            paginationEl.innerHTML = '';
        } else {
            // Kaç sayfa göstereceğiz (max 7 sayfa numarası)
            const maxVisible = 7;
            let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
            let endPage = Math.min(totalPages, startPage + maxVisible - 1);
            if (endPage - startPage < maxVisible - 1) startPage = Math.max(1, endPage - maxVisible + 1);

            let pageButtons = '';
            for (let p = startPage; p <= endPage; p++) {
                const isActive = p === currentPage;
                pageButtons += `<button onclick="goToPage(${p})" class="pagination-btn ${isActive ? 'pagination-btn-active' : ''}">${p}</button>`;
            }

            paginationEl.innerHTML = `
                <div class="flex items-center justify-center gap-1.5 mt-8 mb-2">
                    <button onclick="goToPage(${currentPage - 1})" ${currentPage <= 1 ? 'disabled' : ''} class="pagination-btn pagination-arrow">
                        <i class="fas fa-chevron-left"></i>
                    </button>
                    ${startPage > 1 ? `<button onclick="goToPage(1)" class="pagination-btn">1</button>${startPage > 2 ? '<span class="pagination-ellipsis">…</span>' : ''}` : ''}
                    ${pageButtons}
                    ${endPage < totalPages ? `${endPage < totalPages - 1 ? '<span class="pagination-ellipsis">…</span>' : ''}<button onclick="goToPage(${totalPages})" class="pagination-btn">${totalPages}</button>` : ''}
                    <button onclick="goToPage(${currentPage + 1})" ${currentPage >= totalPages ? 'disabled' : ''} class="pagination-btn pagination-arrow">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
                <p class="text-center text-xs text-gray-400 mt-2">${startIdx + 1}–${Math.min(startIdx + ARTICLES_PER_PAGE, gridArts.length)} / ${gridArts.length} haber</p>
            `;
        }

        // --- Optional: Hydrate Technology Grid if on Home ---
        const techGrid = document.getElementById("technology-grid");
        const categoryFocusTitle = document.querySelector("#category-focus h2");
        if (currentCategory === "Home" && techGrid) {
            let focusArts = articles.filter(a => a.ai_category === "Technology").slice(0, 3);
            if (userPrefs && userPrefs.length > 0) {
                focusArts = userPrefs
                    .map(cat => displayArticles.find(article => article.ai_category === cat))
                    .filter(Boolean)
                    .slice(0, 3);
                if (categoryFocusTitle) categoryFocusTitle.textContent = "Seçtiğim Konulardan Öne Çıkanlar";
            } else if (categoryFocusTitle) {
                categoryFocusTitle.textContent = "Teknoloji Öne Çıkanlar";
            }

            if (focusArts.length > 0) {
                techGrid.innerHTML = focusArts.map(art => `
                    <article class="group cursor-pointer" onclick="readArticle('${escapeAttr(art.id)}')">
                        <div class="h-40 bg-gray-200 mb-3 overflow-hidden rounded-sm relative">
                            <img loading="lazy" src="${art.image_url || getFallbackImage('Technology', art.id)}" class="w-full h-full object-cover">
                        </div>
                        <h4 class="font-black text-sm leading-tight group-hover:text-brandRed transition">${art.title}</h4>
                    </article>
                `).join("");
            }
        }

        // --- Render Trending List (Sidebar) ---
        // Now powered by window._globalNewsData (100+ sources) if available
        const trendingList = document.getElementById("trending-list");
        if (trendingList) {
            const globalNews = window._globalNewsData;
            if (globalNews && globalNews.length > 0) {
                // Pick 5 from different sources
                const seen = new Set();
                const picks = [];
                for (const item of globalNews) {
                    if (!seen.has(item.source) && picks.length < 5) {
                        seen.add(item.source);
                        picks.push(item);
                    }
                }
                trendingList.innerHTML = picks.map((item, idx) => `
                    <li class="flex items-start space-x-3 group cursor-pointer" onclick="window.open('${escapeAttr(item.link)}','_blank')">
                        <span class="text-2xl font-black text-gray-200 group-hover:text-brandRed transition-colors pt-1">${idx + 1}</span>
                        <div class="flex-1">
                            <span class="text-[9px] font-bold text-brandRed uppercase tracking-widest block mb-0.5">${item.source} &bull; ${item.country}</span>
                            <h4 class="text-sm font-bold leading-tight group-hover:underline line-clamp-2 text-slate-900 dark:text-white">${item.title}</h4>
                        </div>
                    </li>
                `).join("");
            } else if (articles.length > 0) {
                // Fallback to recommendation articles
                const trendArts = displayArticles.slice(0, 5);
                trendingList.innerHTML = trendArts.map((art, idx) => `
                    <li class="flex items-start space-x-3 group cursor-pointer" onclick="readArticle('${escapeAttr(art.id)}')">
                        <span class="text-2xl font-black text-gray-200 group-hover:text-brandRed transition-colors pt-1">${idx + 1}</span>
                        <div class="flex-1">
                            <span class="text-[9px] font-bold text-brandRed uppercase tracking-widest block mb-0.5">${art.ai_category}</span>
                            <h4 class="text-sm font-bold leading-tight group-hover:underline line-clamp-2 text-slate-900 dark:text-white">${art.title}</h4>
                            <span class="text-[8px] text-gray-400 uppercase mt-1 block">${art.source || 'BİLİMHABER'}</span>
                        </div>
                    </li>
                `).join("");
            }
        }

        // --- Render Latest News Feed (Sidebar) ---
        // Powered by global news (100+ sources) when available
        const latestFeed = document.getElementById("latest-feed");
        if (latestFeed) {
            const globalNews = window._globalNewsData;
            if (globalNews && globalNews.length > 0) {
                const latestGlobal = globalNews.slice(0, 10);
                latestFeed.innerHTML = latestGlobal.map(item => `
                    <li class="relative pl-6 pb-4 last:pb-0" onclick="window.open('${escapeAttr(item.link)}','_blank')" style="cursor:pointer">
                        <div class="absolute left-0 top-1.5 w-4 h-4 bg-white border-2 border-brandRed rounded-full z-10"></div>
                        <div class="group">
                            <span class="text-[8px] font-black text-brandRed uppercase tracking-widest block mb-0.5">${item.source} &bull; ${item.country}</span>
                            <h4 class="text-sm font-bold leading-snug group-hover:text-brandRed transition-colors line-clamp-2 text-slate-900 dark:text-white">${item.title}</h4>
                        </div>
                    </li>
                `).join("");
            } else if (articles.length > 0) {
                // Fallback
                const lastArts = [...displayArticles].slice(0, 10);
                latestFeed.innerHTML = lastArts.map(art => `
                    <li class="relative pl-6 pb-6 last:pb-0" onclick="readArticle('${escapeAttr(art.id)}')">
                        <div class="absolute left-0 top-1.5 w-4 h-4 bg-white dark:bg-slate-900 border-2 border-brandRed rounded-full z-10"></div>
                        <div class="cursor-pointer group">
                            <span class="text-[8px] font-black text-brandRed uppercase tracking-widest block mb-0.5">${art.source || "BİLİMHABER"} KAYNAK</span>
                            <h4 class="text-sm font-bold leading-snug group-hover:text-brandRed transition-colors line-clamp-2 text-slate-900 dark:text-white">${art.title}</h4>
                        </div>
                    </li>
                `).join("");
            }
        }

        // --- Render Sidebar: GÜNLÜK ÖZET (Powered by Global News) ---
        if (pinnedFeed) {
            const globalNews = window._globalNewsData;
            if (globalNews && globalNews.length > 0) {
                // Group by country, pick top 1 from each
                const byCountry = {};
                for (const item of globalNews) {
                    if (!byCountry[item.country]) byCountry[item.country] = item;
                }
                const countries = Object.keys(byCountry).slice(0, 6);
                const countryFlags = { 'TR': '🇹🇷', 'US': '🇺🇸', 'UK': '🇬🇧', 'DE': '🇩🇪', 'FR': '🇫🇷', 'JP': '🇯🇵', 'KR': '🇰🇷', 'IN': '🇮🇳', 'BR': '🇧🇷', 'IL': '🇮🇱', 'RU': '🇷🇺', 'CN': '🇨🇳', 'AU': '🇦🇺', 'CA': '🇨🇦', 'MX': '🇲🇽', 'AR': '🇦🇷', 'ZA': '🇿🇦', 'NG': '🇳🇬', 'KE': '🇰🇪', 'EG': '🇪🇬', 'SA': '🇸🇦', 'AE': '🇦🇪' };

                pinnedFeed.innerHTML = countries.map(code => {
                    const item = byCountry[code];
                    const flag = countryFlags[code] || '🌍';
                    return `
                        <article class="cursor-pointer group block border-b pb-3 mb-3 border-gray-100 last:border-0" onclick="window.open('${escapeAttr(item.link)}','_blank')">
                            <span class="text-[10px] font-black text-brandRed block mb-1 uppercase tracking-widest">${flag} ${item.source} &bull; ${code}</span>
                            <h4 class="font-black text-sm leading-snug group-hover:text-brandRed transition font-serif line-clamp-2 text-slate-900 dark:text-white">${item.title}</h4>
                        </article>
                    `;
                }).join("");
            } else if (pinnedCategories.length === 0) {
                const discoveryArt = displayArticles[0] || articles[0];
                pinnedFeed.innerHTML = discoveryArt ? `
                    <div class="bg-white/40 dark:bg-slate-800/40 p-4 rounded-sm border border-dashed border-indigo-200 dark:border-indigo-900/50">
                        <span class="inline-block px-1.5 py-0.5 bg-indigo-500 text-white text-[8px] font-black uppercase mb-3">Keşif</span>
                        <h4 class="font-black text-sm leading-snug dark:text-gray-100 font-serif mb-2 cursor-pointer hover:text-brandRed transition" onclick="readArticle('${escapeAttr(discoveryArt.id)}')">${discoveryArt.title}</h4>
                        <p class="text-[10px] text-gray-500 italic">Belirli kategorileri günlük özetinize sabitlemek için ayarları kullanın.</p>
                    </div>
                ` : `<p class="text-sm text-gray-500">Gösterilecek haber bulunamadı.</p>`;
            } else {
                let pinnedHtml = "";
                pinnedCategories.forEach(cat => {
                    const topArt = displayArticles.find(a => a.ai_category === cat) || AppState.articles.find(a => a.ai_category === cat);
                    if (topArt) {
                        pinnedHtml += `
                            <article class="cursor-pointer group block border-b pb-4 mb-4 border-indigo-100 dark:border-slate-700 last:border-0" onclick="readArticle('${escapeAttr(topArt.id)}')">
                                <span class="text-[10px] font-black text-brandRed block mb-1 uppercase tracking-widest">${cat}</span>
                                <h4 class="font-black text-sm leading-snug group-hover:text-indigo-600 transition dark:text-gray-100 font-serif">${topArt.title}</h4>
                            </article>
                        `;
                    }
                });
                pinnedFeed.innerHTML = pinnedHtml;
            }
        }
    }

    AppState.subscribe(hydrateDOM);
    window.hydrateDOM = hydrateDOM;
    hydrateDOM();

    scheduleNonCriticalTask(async () => {
        const articles = await fetchRecommendations(AppState.userId);
        AppState.setArticles(articles);
    }, 0);
});

let readingTimer;
function readArticle(articleId) {
    try {
        const allAvailableNews = [...(AppState.articles || []), ...(window._globalNewsData || [])];
        const art = allAvailableNews.find(a => String(a.id) === String(articleId));
        if (!art) {
            console.warn("Haber sistemde bulunamadı (ID eşleşmedi):", articleId);
            return;
        }

        // 2. GÖREV: Dinamik Kaynak Analizi — Havuz hazır olana kadar retry ile çağır
        const _runComparisons = () => {
            const pool = [...(AppState.articles || []), ...(window._globalNewsData || [])];
            if (typeof setupDynamicComparisons === 'function') {
                setupDynamicComparisons(art, pool);
            }
        };

        // Panelleri hemen spinner ile doldur (boş görünmesin)
        const _spinnerHTML = `<div class="flex flex-col items-center justify-center h-full space-y-3 py-10 opacity-60">
            <i class="fas fa-circle-notch fa-spin text-2xl text-blue-400"></i>
            <span class="text-[10px] font-bold text-gray-400 uppercase tracking-widest animate-pulse">Kaynaklar yükleniyor...</span>
        </div>`;
        const _s1 = document.getElementById('compare-source-1');
        const _s2 = document.getElementById('compare-source-2');
        const _c1 = document.getElementById('compare-content-1');
        const _c2 = document.getElementById('compare-content-2');
        if (_c1) _c1.innerHTML = _spinnerHTML;
        if (_c2) _c2.innerHTML = _spinnerHTML;
        if (_s1) _s1.innerHTML = '<option value="" disabled selected>Yükleniyor...</option>';
        if (_s2) _s2.innerHTML = '<option value="" disabled selected>Yükleniyor...</option>';

        // Havuz doluysa anında, boşsa 600ms sonra tekrar dene
        const pool = [...(AppState.articles || []), ...(window._globalNewsData || [])];
        console.log('[readArticle] Havuz boyutu:', pool.length);
        if (pool.length > 1) {
            _runComparisons();
        } else {
            setTimeout(_runComparisons, 600);
        }

        // Modal alanlarını doldur
        const img = document.getElementById('article-modal-img');
        const imgWrap = document.getElementById('article-modal-img-wrap');
        const fallback = typeof getFallbackImage === 'function' ? getFallbackImage(art.ai_category || art.category || 'General', art.id || art.url) : '';
        const src = (typeof art.image_url === 'string' && art.image_url.trim().length > 10) ? art.image_url : fallback;
        if (img) {
            img.src = src;
            img.onerror = () => { img.onerror = null; img.src = fallback; };
        }
        if (imgWrap) imgWrap.classList.remove('hidden');

        const catEl = document.getElementById('article-modal-cat');
        if (catEl) catEl.textContent = art.ai_category || '';

        const sourceEl = document.getElementById('article-modal-source');
        if (sourceEl) {
            sourceEl.textContent = typeof formatSourceName === 'function' ? formatSourceName(art.source || 'BİLİMHABER') : (art.source || 'BİLİMHABER');
        }

        const titleEl = document.getElementById('article-modal-title');
        if (titleEl) titleEl.textContent = art.title || '';

        const likeBtn = document.getElementById('article-modal-like-btn');
        if (likeBtn) {
            likeBtn.onclick = (e) => {
                if (typeof handleLike === 'function') handleLike(art.id, e);
            };
            const icon = likeBtn.querySelector('i');
            if (icon) {
                icon.classList.remove('fas', 'text-brandRed');
                icon.classList.add('far');
            }
            likeBtn.classList.remove('text-brandRed');
            likeBtn.classList.add('text-gray-300');
        }

        const summaryEl = document.getElementById('article-modal-summary');
        const contentEl = document.getElementById('article-modal-content');

        if (summaryEl) {
            summaryEl.innerHTML = `
                <span class="ai-badge"><i class="fas fa-robot"></i> Yapay Zeka Özeti</span>
                <div class="ai-summary-loading">${typeof t === 'function' ? t('loading') : 'Haber içeriği çekiliyor...'}</div>
            `;
        }
        if (contentEl) {
            contentEl.innerHTML = `
                <div class="article-content-loading">
                    <div class="ai-summary-loading">Haber tam metni yükleniyor...</div>
                </div>
            `;
        }

        const bgContainer = document.getElementById('article-modal-dynamic-bg');
        if (bgContainer && src) {
            bgContainer.style.backgroundImage = `url('${src}')`;
        }

        // Modal'ı hemen aç
        const modal = document.getElementById('article-modal');
        if (modal) {
            modal.classList.remove('hidden', 'opacity-0', 'pointer-events-none');
            modal.classList.add('flex');
            document.body.style.overflow = 'hidden';
        }

        // Kaynak linki
        const linkEl = document.getElementById('article-modal-link');
        const linkElBottom = document.getElementById('article-modal-link-bottom');
        const readMoreBtn = document.getElementById('article-modal-read-more-btn');
        const articleUrl = art.url || art.link || '';
        if (articleUrl) {
            if (linkEl) { linkEl.href = articleUrl; linkEl.classList.remove('hidden'); }
            if (linkElBottom) { linkElBottom.href = articleUrl; linkElBottom.classList.remove('hidden'); }
            if (readMoreBtn) {
                readMoreBtn.onclick = () => window.open(articleUrl, '_blank');
                readMoreBtn.classList.remove('hidden');
            }
        } else {
            if (linkEl) { linkEl.classList.add('hidden'); }
            if (linkElBottom) { linkElBottom.classList.add('hidden'); }
            if (readMoreBtn) { readMoreBtn.classList.add('hidden'); }
        }

        // Backend'den tam içerik + AI özet çek
        if (articleUrl && typeof fetchArticleContent === 'function') {
            fetchArticleContent(articleUrl, art.title).then(async data => {
                if (!data) {
                    if (typeof _showFallbackContent === 'function') _showFallbackContent(summaryEl, contentEl, art);
                } else {
                    let targetLang = (typeof window.currentLang !== 'undefined') ? window.currentLang : (localStorage.getItem('pref_lang') || 'tr');
                    
                    // KÖKLÜ ÇÖZÜM: GERÇEK ZAMANLI DİL DEĞİŞİMİ İÇİN HAM VERİYİ (RAW) HAFIZADA TUT
                    window.currentActiveArticleRawData = {
                        title: art.title,
                        summary: data.summary || art.ai_summary,
                        content: data.content || 'İçerik bulunamadı.'
                    };
                    
                    // Frontend Çevirisi - İçerik ve AI Özeti de Çevir:
                    if (targetLang && typeof translateTextFree === 'function') {
                        if (summaryEl) summaryEl.innerHTML = `<span class="ai-badge"><i class="fas fa-robot"></i> ${targetLang} çevirisi hazırlanıyor...</span>`;
                        if (contentEl) contentEl.innerHTML = `<div class="ai-summary-loading">${targetLang} tercümesi yapılıyor...</div>`;
                        
                        if (data.summary) data.summary = await translateTextFree(data.summary, targetLang);
                        if (data.content) data.content = await translateTextFree(data.content, targetLang);
                    }
                    
                    art.ai_summary = data.summary || art.ai_summary;
                    if (summaryEl) summaryEl.style.opacity = '0';
                    if (contentEl) contentEl.style.opacity = '0';
                    setTimeout(() => {
                        if (summaryEl && typeof formatAISummary === 'function') summaryEl.innerHTML = formatAISummary(art.ai_summary);
                        if (contentEl && typeof formatArticleContent === 'function') contentEl.innerHTML = formatArticleContent(data.content || 'İçerik bulunamadı.');
                        if (summaryEl) summaryEl.style.opacity = '1';
                        if (contentEl) contentEl.style.opacity = '1';
                        if (typeof injectNewsIntoRag === 'function') injectNewsIntoRag(art.title, data.content || data.summary || art.ai_summary);
                    }, 50);
                }
            }).catch(e => {
                if (typeof _showFallbackContent === 'function') _showFallbackContent(summaryEl, contentEl, art);
            });
        } else {
            if (typeof _showFallbackContent === 'function') _showFallbackContent(summaryEl, contentEl, art);
        }
    } catch (e) {
        // DEFENSIVE: asla alert() çıkarma — modalı beyaza boyuyor
        console.error('[readArticle] HATA (modal açılmaya devam eder):', e.message, e);
    }
}

// =========================================================================
// MİMARİ DEVRİM: DETAY SAYFASINDAYKEN DİL DEĞİŞİRSE ANINDA ÇEVİR (ON-THE-FLY)
// =========================================================================
window.reTranslateActiveModal = async function(targetLang) {
    const rawData = window.currentActiveArticleRawData;
    const modal = document.getElementById('article-modal');
    
    // Eğer modal açık değilse veya ham veri yoksa işlem yapma
    if (!modal || modal.classList.contains('hidden') || !rawData) return;
    
    const titleEl = document.getElementById('article-modal-title');
    const summaryEl = document.getElementById('article-modal-summary');
    const contentEl = document.getElementById('article-modal-content');
    
    if (typeof translateTextFree !== 'function') return;

    if (summaryEl) summaryEl.innerHTML = `<span class="ai-badge"><i class="fas fa-sync-alt fa-spin"></i> ${targetLang.toUpperCase()} diline uyarlanıyor...</span>`;
    if (contentEl) contentEl.innerHTML = `<div class="ai-summary-loading">${targetLang.toUpperCase()} yapay zeka çevirisi uygulanıyor...</div>`;
    
    const [newTitle, newSummary, newContent] = await Promise.all([
        translateTextFree(rawData.title, targetLang),
        translateTextFree(rawData.summary, targetLang),
        translateTextFree(rawData.content, targetLang)
    ]);
    
    if (titleEl) titleEl.textContent = newTitle;
    if (summaryEl && typeof formatAISummary === 'function') {
        summaryEl.style.opacity = '0';
        setTimeout(() => {
            summaryEl.innerHTML = formatAISummary(newSummary);
            summaryEl.style.opacity = '1';
        }, 100);
    }
    if (contentEl && typeof formatArticleContent === 'function') {
        contentEl.style.opacity = '0';
        setTimeout(() => {
            contentEl.innerHTML = formatArticleContent(newContent);
            contentEl.style.opacity = '1';
        }, 150);
    }
};

async function _showFallbackContent(summaryEl, contentEl, art) {
    function stripHtml(html) {
        const tmp = document.createElement('div');
        tmp.innerHTML = html;
        return tmp.textContent || tmp.innerText || '';
    }

    let targetLang = (typeof window.currentLang !== 'undefined') ? window.currentLang : (localStorage.getItem('pref_lang') || 'tr');
    let rawSummary = art.ai_summary || art.summary || art.description || '';

    // KESİN ÇÖZÜM: Fallback özeti de çeviri motorundan geçir
    if (rawSummary && targetLang && typeof translateTextFree === 'function') {
        if (summaryEl) summaryEl.innerHTML = `<span class="ai-badge"><i class="fas fa-sync-alt fa-spin"></i> Özet çevriliyor...</span>`;
        rawSummary = await translateTextFree(stripHtml(rawSummary), targetLang);
    }

    if (rawSummary) {
        const cleaned = rawSummary.replace(/^[-•]\s*/gm, '').trim();
        const paras = cleaned.split('\n').filter(l => l.trim());
        summaryEl.innerHTML = `
            <span class="ai-badge"><i class="fas fa-robot"></i> Yapay Zeka Özeti</span>
            ${paras.map(p => `<p class="mb-2">${p}</p>`).join('')}
        `;
    } else {
        summaryEl.innerHTML = `
            <span class="ai-badge"><i class="fas fa-robot"></i> Yapay Zeka Özeti</span>
            <p class="text-gray-400 italic">Özet mevcut değil.</p>
        `;
    }
    contentEl.innerHTML = `
        <div class="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-xl text-center border border-dashed border-gray-300 dark:border-slate-700">
            <i class="fas fa-exclamation-triangle text-3xl text-orange-400 mb-3 block"></i>
            <h4 class="text-lg font-black text-slate-800 dark:text-gray-200 mb-2">Haberin Tam Metni Çekilemedi</h4>
            <p class="text-sm text-gray-500 mb-4">Bu haber kaynağı (SSL/Güvenlik politikaları nedeniyle) otomatik okumaya izin vermiyor olabilir.</p>
            <p class="text-sm text-brandRed font-bold">Lütfen "Daha Fazla Oku" butonunu kullanarak orijinal kaynağı ziyaret edin.</p>
        </div>
    `;

    // Ham özeti de kasaya kaydet (dil değişiminde re-translate yapılsın)
    if (!window.currentActiveArticleRawData) {
        window.currentActiveArticleRawData = { title: art.title, summary: art.ai_summary || art.description || '', content: '' };
    }
}

function readArticleEnhanced(articleId) {
    try {
        // Her iki kaynaktan haberi ara — AppState + globalNewsData
        const pool = [
            ...( Array.isArray(AppState.articles)      ? AppState.articles      : []),
            ...( Array.isArray(window._globalNewsData) ? window._globalNewsData : [])
        ];
        const art = pool.find(a => String(a.id) === String(articleId));
        if (!art) {
            console.warn('[readArticleEnhanced] Haber bulunamadi:', articleId);
            return;
        }

        // Karşılaştırma motoru: panelleri aninda spinner'a al, sonra doldur
        const _c1 = document.getElementById('compare-content-1');
        const _c2 = document.getElementById('compare-content-2');
        const _s1 = document.getElementById('compare-source-1');
        const _s2 = document.getElementById('compare-source-2');
        const _spinner = '<div style="padding:20px;text-align:center;"><i class="fas fa-circle-notch fa-spin" style="color:#60a5fa;font-size:20px;"></i><p style="margin-top:8px;font-size:11px;color:#9ca3af;">Kaynaklar yükleniyor...</p></div>';
        if (_c1) _c1.innerHTML = _spinner;
        if (_c2) _c2.innerHTML = _spinner;
        if (_s1) _s1.innerHTML = '<option value="" disabled selected>Yükleniyor...</option>';
        if (_s2) _s2.innerHTML = '<option value="" disabled selected>Yükleniyor...</option>';

        // Havuz boşsa 600ms bekle; doluysa aninda
        const runComp = () => {
            const merged = [
                ...(Array.isArray(AppState.articles)      ? AppState.articles      : []),
                ...(Array.isArray(window._globalNewsData) ? window._globalNewsData : [])
            ];
            if (typeof setupDynamicComparisons === 'function') {
                setupDynamicComparisons(art, merged);
            }
        };
        if (pool.length > 1) { runComp(); }
        else { setTimeout(runComp, 600); }

        const img = document.getElementById('article-modal-img');
        const imgWrap = document.getElementById('article-modal-img-wrap');
        const fallback = typeof getFallbackImage === 'function' ? getFallbackImage(art.ai_category || art.category || 'General', art.id || art.url) : '';
        const src = (typeof art.image_url === 'string' && art.image_url.trim().length > 10) ? art.image_url : fallback;
        if (img) {
            img.src = src;
            img.onerror = () => { img.onerror = null; img.src = fallback; };
        }
        if (imgWrap) imgWrap.classList.remove('hidden');

        const catEl = document.getElementById('article-modal-cat');
        if (catEl) catEl.textContent = art.ai_category || art.category || '';

        const sourceEl = document.getElementById('article-modal-source');
        if (sourceEl) {
            sourceEl.textContent = typeof formatSourceName === 'function' ? formatSourceName(art.source || 'BILIMHABER') : (art.source || 'BILIMHABER');
        }

        const titleEl = document.getElementById('article-modal-title');
        if (titleEl) titleEl.textContent = art.title || '';

        const summaryEl = document.getElementById('article-modal-summary');
        const contentEl = document.getElementById('article-modal-content');
        const localReadableContent = buildLocalArticleContent(art);

        if (summaryEl) {
            summaryEl.innerHTML = formatAISummary(art.ai_summary || art.summary || art.description || '');
        }
        if (contentEl) {
            contentEl.innerHTML = formatArticleContent(localReadableContent || 'Icerik hazirlaniyor...');
        }

        const bgContainer = document.getElementById('article-modal-dynamic-bg');
        if (bgContainer && src) {
            bgContainer.style.backgroundImage = `url('${src}')`;
        }

        const modal = document.getElementById('article-modal');
        if (modal) {
            modal.classList.remove('hidden', 'opacity-0', 'pointer-events-none');
            modal.classList.add('flex');
            document.body.style.overflow = 'hidden';
        }

        const linkEl = document.getElementById('article-modal-link');
        const linkElBottom = document.getElementById('article-modal-link-bottom');
        const readMoreBtn = document.getElementById('article-modal-read-more-btn');
        const articleUrl = art.url || art.link || '';
        if (articleUrl) {
            if (linkEl) { linkEl.href = articleUrl; linkEl.classList.remove('hidden'); }
            if (linkElBottom) { linkElBottom.href = articleUrl; linkElBottom.classList.remove('hidden'); }
            if (readMoreBtn) {
                readMoreBtn.onclick = () => window.open(articleUrl, '_blank');
                readMoreBtn.classList.remove('hidden');
            }
        }

        if (articleUrl && typeof fetchArticleContent === 'function') {
            fetchArticleContent(articleUrl, art.title).then(data => {
                if (!data) {
                    if (typeof _showFallbackContent === 'function') _showFallbackContent(summaryEl, contentEl, art);
                    return;
                }

                art.ai_summary = data.summary || art.ai_summary;
                art.description = art.description || data.content || '';

                if (summaryEl) summaryEl.innerHTML = formatAISummary(art.ai_summary || art.description || '');
                if (contentEl) contentEl.innerHTML = formatArticleContent(data.content || localReadableContent || 'Icerik bulunamadi.');

                if (typeof injectNewsIntoRag === 'function') {
                    injectNewsIntoRag(art.title, data.content || data.summary || art.ai_summary);
                }
            }).catch(() => {
                if (typeof _showFallbackContent === 'function') _showFallbackContent(summaryEl, contentEl, art);
            });
        } else if (typeof _showFallbackContent === 'function') {
            _showFallbackContent(summaryEl, contentEl, art);
        }
    } catch (e) {
        // DEFENSIVE: alert() hiçbir zaman modalı durdurmamalı
        console.error('[readArticleEnhanced] HATA (modal acılmaya devam eder):', e.message, e);
    }
}

function handleArticleCardDelegation(event) {
    if (event.target.closest('[data-like-button]')) return;

    const articleCard = event.target.closest('[data-article-id], [data-global-index]');
    if (!articleCard) return;

    const articleId = articleCard.getAttribute('data-article-id');
    const globalIndex = articleCard.getAttribute('data-global-index');

    if (articleId) {
        if (typeof window.readArticle === 'function') {
            window.readArticle(articleId);
        }
        return;
    }

    if (globalIndex !== null && globalIndex !== '' && typeof window.readArticleByIndex === 'function') {
        window.readArticleByIndex(Number(globalIndex));
    }
}

function showFallbackContentEnhanced(summaryEl, contentEl, art) {
    if (summaryEl) {
        summaryEl.innerHTML = formatAISummary(art.ai_summary || art.summary || art.description || '');
    }

    const fallbackContent = buildLocalArticleContent(art);
    if (contentEl) {
        if (fallbackContent) {
            contentEl.innerHTML = `
                ${formatArticleContent(fallbackContent)}
                <div class="mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-gray-300 dark:border-slate-700">
                    <p class="text-xs text-gray-500 dark:text-gray-300">
                        Tam kaynak metni otomatik olarak alinmadi. Bu nedenle eldeki ozet ve aciklama gosteriliyor.
                    </p>
                </div>
            `;
        } else {
            contentEl.innerHTML = `
                <div class="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-xl text-center border border-dashed border-gray-300 dark:border-slate-700">
                    <i class="fas fa-exclamation-triangle text-3xl text-orange-400 mb-3 block"></i>
                    <h4 class="text-lg font-black text-slate-800 dark:text-gray-200 mb-2">Haber icerigi su anda alinmadi</h4>
                    <p class="text-sm text-gray-500 mb-4">Orijinal kaynagi kullanarak haberi acabilirsiniz.</p>
                </div>
            `;
        }
    }
}

document.addEventListener('click', handleArticleCardDelegation);

_showFallbackContent = showFallbackContentEnhanced;
readArticle = readArticleEnhanced;
window.readArticle = readArticleEnhanced;
window.closeArticleModal = closeArticleModal;
window.goToPage = goToPage;

function closeArticleModal() {
    const modal = document.getElementById('article-modal');
    if (modal) {
        modal.classList.add('opacity-0', 'pointer-events-none');
        setTimeout(() => {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }, 300);
    }
    document.body.style.overflow = '';
}


// Sayfa geçiş fonksiyonu (global — HTML onclick'ten çağrılır)
function goToPage(page) {
    // currentPage iç scope'ta, AppState üzerinden tetikle
    AppState._requestedPage = page;
    AppState.notify();
    // Haberlere scroll
    const grid = document.getElementById('top-stories-grid');
    if (grid) grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// --- SIDEBAR WIDGETS: Global news data'yı widgetlara aktar ---
async function initSidebarWidgets() {
    let attempts = 0;
    // PERFORMANS: setInterval yerine tek seferlik retry — tekrarlayan DOM sıfırlaması donmaya yol açıyordu
    function _tryPopulate() {
        attempts++;
        if (window._globalNewsData && window._globalNewsData.length > 0) {
            _doPopulate();
        } else if (attempts < 30) {
            // 500ms'de bir retry, max 15 saniye
            setTimeout(_tryPopulate, 500);
        }
    }

    async function _doPopulate() {

            // Populating trending-list
            const trendEl = document.getElementById("trending-list");
            if (trendEl) {
                const trends = window._globalNewsData.slice(0, 5);
                trendEl.innerHTML = trends.map((item, idx) => `
                    <li class="flex items-start gap-3 cursor-pointer group" onclick="window.readArticleCustom('${btoa(item.link)}')">
                        <span class="text-2xl font-black text-gray-200 dark:text-slate-800 group-hover:text-orange-500 transition">0${idx + 1}</span>
                        <div>
                            <span class="text-[10px] text-orange-500 font-black uppercase tracking-widest">${formatSourceName(item.source)}</span>
                            <h4 class="text-xs font-bold text-darkBlue dark:text-gray-200 group-hover:text-orange-500 transition line-clamp-2">${item.title}</h4>
                        </div>
                    </li>
                `).join('');
            }

            // Populating latest-feed
            const latestEl = document.getElementById("latest-feed");
            if (latestEl) {
                const latests = window._globalNewsData.slice(5, 10);
                latestEl.innerHTML = latests.map((item) => `
                    <li class="relative pl-6 pb-4 last:pb-0 cursor-pointer group" onclick="window.readArticleCustom('${btoa(item.link)}')">
                        <span class="absolute left-0 top-1.5 w-2 h-2 rounded-full bg-brandRed z-10 ring-4 ring-white dark:ring-slate-900 group-hover:scale-150 transition-transform"></span>
                        <span class="text-[9px] text-gray-400 font-bold uppercase tracking-wider block mb-1">ŞİMDİ</span>
                        <h4 class="text-xs font-bold text-gray-700 dark:text-gray-300 group-hover:text-brandRed transition line-clamp-2">${item.title}</h4>
                    </li>
                `).join('');
            }

            // Populating recommended-feed
            const recEl = document.getElementById("recommended-feed");
            if (recEl) {
                const session = typeof Auth !== 'undefined' ? Auth.getSession() : null;
                const userId = session ? session.id : 'guest';

                try {
                    const res = await fetch(`${API_BASE_URL}/recommend/${userId}?limit=4`);
                    if (res.ok) {
                        const data = await res.json();
                        const recs = data.recommendations || [];
                        if (recs.length === 0) {
                            recEl.innerHTML = `<li><span class="text-gray-500 text-xs italic">Senin için haber toplanıyor... Lütfen haberleri beğen!</span></li>`;
                        } else {
                            recEl.innerHTML = recs.map(rec => {
                                const item = window._globalNewsData.find(g => g.link === rec.url) || rec;
                                const onclickAction = item.link ? `window.readArticleCustom('${btoa(item.link)}')` : `window.readArticle('${item.id}')`;
                                return `
                                <li class="cursor-pointer group flex flex-col gap-1 border-b border-indigo-100 dark:border-indigo-800/50 pb-3 last:border-0" onclick="${onclickAction}">
                                    <div class="flex items-center justify-between">
                                        <span class="text-[9px] font-black text-indigo-500 uppercase tracking-widest">${item.ai_category || item.category || 'ÖZEL'}</span>
                                        <span class="text-[9px] text-gray-400 font-bold"><i class="fas fa-fire text-orange-500"></i> Eşleşme Yüksek</span>
                                    </div>
                                    <h4 class="text-xs font-bold text-indigo-950 dark:text-indigo-100 group-hover:text-indigo-600 transition line-clamp-2">${item.title}</h4>
                                </li>
                               `;
                            }).join('');
                        }
                    } else {
                        recEl.innerHTML = `<li><span class="text-gray-500 text-xs italic">Henüz özel öneri oluşmadı.</span></li>`;
                    }
                } catch (err) {
                    recEl.innerHTML = `<li><span class="text-gray-500 text-xs italic">Kişiselleştirilmiş bağlantı kurulamadı.</span></li>`;
                }
            }

            // Güncel Haberler grid'ini global haberlerle doldur
            renderGlobalNewsGrid(window._globalNewsData);
            if (typeof hydrateDOM === 'function') hydrateDOM();
            updateLastRefreshBadge();
        }  // _doPopulate biter

    // _tryPopulate başlat
    _tryPopulate();
}


// ================================================================
// GÜNCEL HABERLER GRİDİ — 105 KAYNAKTAN GLOBAL HABERLER
// ================================================================
function renderGlobalNewsGrid(newsItems) {
    const grid = document.getElementById('top-stories-grid');
    if (!grid) return;
    
    let combinedItems = newsItems || [];
    if (typeof AppState !== 'undefined' && AppState.articles && AppState.articles.length > 0) {
        const existingLinks = new Set(combinedItems.map(g => g.link || g.url));
        const dbFiltered = AppState.articles.filter(a => !existingLinks.has(a.url) && !existingLinks.has(a.link));
        combinedItems = [...dbFiltered, ...combinedItems];
    }
    if (!combinedItems || combinedItems.length === 0) return;

    let filteredItems = combinedItems;
    if (typeof AppState !== 'undefined') {
        if (AppState.currentCategory && AppState.currentCategory !== "Home") {
            filteredItems = combinedItems.filter(item => {
                const cat = (item.ai_category || item.category || "World").toLowerCase();
                return cat === AppState.currentCategory.toLowerCase() || cat.includes(AppState.currentCategory.toLowerCase());
            });
        }
        // Removed aggressive userPrefs filtering on Home so all news are visible
    }

    if (filteredItems.length === 0) {
        grid.innerHTML = `<div class="col-span-full py-16 text-center text-gray-400 font-bold text-lg"><i class="fas fa-satellite-dish text-5xl mb-4 block text-gray-300"></i>${typeof window.t === 'function' ? window.t('empty_category_msg') : 'Bu kategoride henüz güncel bir haber akışı yok, lütfen daha sonra tekrar kontrol edin.'}</div>`;
        const paginationContainer = document.getElementById('global-news-pagination');
        if (paginationContainer) paginationContainer.innerHTML = '';
        return;
    }

    const catColorMap = {
        "Technology": "bg-darkBlue",
        "Economy": "bg-green-700",
        "Sports": "bg-orange-600",
        "Politics": "bg-brandRed",
        "Health": "bg-teal-600",
        "World": "bg-indigo-700",
    };

    const countryFlags = {
        'TR': '🇹🇷', 'US': '🇺🇸', 'UK': '🇬🇧', 'DE': '🇩🇪', 'FR': '🇫🇷',
        'JP': '🇯🇵', 'KR': '🇰🇷', 'IN': '🇮🇳', 'BR': '🇧🇷', 'IL': '🇮🇱',
        'RU': '🇷🇺', 'CN': '🇨🇳', 'AU': '🇦🇺', 'CA': '🇨🇦', 'MX': '🇲🇽',
        'AR': '🇦🇷', 'ZA': '🇿🇦', 'NG': '🇳🇬', 'KE': '🇰🇪', 'EG': '🇪🇬',
        'SA': '🇸🇦', 'AE': '🇦🇪', 'PL': '🇵🇱', 'ES': '🇪🇸', 'IT': '🇮🇹',
        'NL': '🇳🇱', 'SE': '🇸🇪', 'NO': '🇳🇴', 'CH': '🇨🇭', 'PT': '🇵🇹'
    };

    // Pagination Parameters
    window._globalNewsPage = window._globalNewsPage || 1;
    const itemsPerPage = 12;
    const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
    if (window._globalNewsPage > totalPages) window._globalNewsPage = Math.max(1, totalPages);

    const startIdx = (window._globalNewsPage - 1) * itemsPerPage;
    const picks = filteredItems.slice(startIdx, startIdx + itemsPerPage);

    const globalIndexMap = new Map();
    if (Array.isArray(window._globalNewsData)) {
        window._globalNewsData.forEach((item, index) => {
            const key = item.link || item.url;
            if (key && !globalIndexMap.has(key)) {
                globalIndexMap.set(key, index);
            }
        });
    }

    grid.style.opacity = '0';
    grid.style.transition = 'opacity 0.15s ease';

    requestAnimationFrame(() => {
        grid.innerHTML = picks.map((item) => {
            const flag = countryFlags[item.country] || '🌍';
            const cat = item.ai_category || item.category || 'Dünya';
            const fallbackImg = getFallbackImage(cat, item.link || item.id || item.title);
            const imgSrc = (item.image_url && item.image_url.trim().length > 10)
                ? item.image_url
                : fallbackImg;
            const color = catColorMap[cat] || catColorMap['World'] || "bg-indigo-700";

            // HTML etiketlerini (ör. <img>, <p>) temizle
            let cleanDesc = '';
            if (item.description) {
                cleanDesc = item.description.replace(/<[^>]*>?/gm, '').trim();
            }

            // Güvenli referans için globalData içerisindeki orjinal indeksini bul
            let originalIndex = globalIndexMap.get(item.link);
            
            // Eğer -1 ise ve link değil url kullanıyorsa (DB makaleleri) tekrar ara
            if (originalIndex === undefined && item.url) {
                originalIndex = globalIndexMap.get(item.url);
            }
            if (originalIndex === undefined) {
                originalIndex = -1;
            }

            const isLocalItem = originalIndex === -1 && item.id !== undefined;
            const clickAction = isLocalItem ? `window.readArticle('${String(item.id).replace(/'/g, "\\'")}')` : `window.readArticleByIndex(${originalIndex})`;
            const articleDataAttrs = isLocalItem
                ? `data-article-id="${escapeHtml(item.id)}"`
                : `data-global-index="${originalIndex}"`;

            // Tasarım Dinamikleri (Akıllı Gazete - Glassmorphism & Watermark)
            let bgClass = "bg-white dark:bg-slate-800";
            let watermarkIcon = "fa-newspaper";
            let headHoverLight = "group-hover:text-indigo-600";
            let headHoverDark = "dark:group-hover:text-indigo-400";
            let liveDot = "bg-indigo-500";
            let arrowColor = "text-indigo-500";

            if (cat === "Politics") {
                bgClass = "bg-slate-50/80 dark:bg-slate-900/60 backdrop-blur-xl";
                watermarkIcon = "fa-landmark text-slate-400 dark:text-slate-500";
                headHoverLight = "group-hover:text-slate-600";
                headHoverDark = "dark:group-hover:text-slate-400";
                liveDot = "bg-slate-500";
                arrowColor = "text-slate-500";
            } else if (cat === "Sports") {
                bgClass = "bg-orange-50/80 dark:bg-slate-900/60 backdrop-blur-xl";
                watermarkIcon = "fa-volleyball-ball text-orange-400 dark:text-orange-500";
                headHoverLight = "group-hover:text-orange-600";
                headHoverDark = "dark:group-hover:text-orange-400";
                liveDot = "bg-orange-500";
                arrowColor = "text-orange-500";
            } else if (cat === "Economy") {
                bgClass = "bg-green-50/80 dark:bg-slate-900/60 backdrop-blur-xl";
                watermarkIcon = "fa-chart-line text-green-400 dark:text-green-500";
                headHoverLight = "group-hover:text-green-600";
                headHoverDark = "dark:group-hover:text-green-400";
                liveDot = "bg-green-500";
                arrowColor = "text-green-500";
            } else if (cat === "Technology") {
                bgClass = "bg-blue-50/80 dark:bg-slate-900/60 backdrop-blur-xl";
                watermarkIcon = "fa-microchip text-blue-400 dark:text-blue-500";
                headHoverLight = "group-hover:text-blue-600";
                headHoverDark = "dark:group-hover:text-blue-400";
                liveDot = "bg-blue-500";
                arrowColor = "text-blue-500";
            } else {
                bgClass = "bg-white/80 dark:bg-slate-800/60 backdrop-blur-xl";
            }

            return `
            <article class="relative overflow-hidden flex flex-col group cursor-pointer article-card p-4 transition-all duration-300 min-h-[380px] rounded-2xl border border-white/40 dark:border-white/10 shadow-sm hover:shadow-2xl hover:-translate-y-1 ${bgClass}"
                onclick="${clickAction}" ${articleDataAttrs}>
                
                <!-- Watermark -->
                <i class="fas ${watermarkIcon} absolute -bottom-4 -right-4 text-[120px] opacity-[0.04] dark:opacity-[0.08] group-hover:scale-110 group-hover:opacity-[0.08] dark:group-hover:opacity-[0.12] transition-all duration-700 pointer-events-none z-0"></i>

                <div class="block rounded-xl overflow-hidden mb-4 relative z-10 border border-white/20 shadow-sm">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent z-10 opacity-70 group-hover:opacity-90 transition-opacity"></div>
                    <img loading="lazy" src="${imgSrc}"
                        class="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-700 blur-[2px] group-hover:blur-0"
                        onerror="this.onerror=null; this.src='${fallbackImg}'">
                    
                    <span class="absolute top-2 left-2 px-2.5 py-1 ${color} text-white text-[10px] font-black uppercase tracking-widest shadow-md rounded-md z-20 bg-opacity-90 backdrop-blur-md">
                        ${flag} ${cat}
                    </span>
                    
                    <span class="absolute bottom-2 left-2 px-2 py-1 bg-black/60 backdrop-blur-md text-white text-[9px] font-bold rounded flex items-center z-20">
                        <i class="fas fa-rss mr-1 opacity-70"></i> ${formatSourceName(item.source)}
                    </span>
                </div>
                
                <h3 class="text-[17px] font-black leading-snug mb-3 ${headHoverLight} ${headHoverDark} transition-colors text-slate-900 dark:text-gray-50 font-serif line-clamp-3 relative z-10 drop-shadow-sm">
                    ${item.title || 'Haber Başlığı'}
                </h3>
                
                ${cleanDesc.length > 0 ? `
                <div class="text-[13px] text-gray-600 dark:text-gray-300 mb-4 line-clamp-2 relative z-10 font-medium">
                    ${cleanDesc}
                </div>` : ''}
                
                <div class="mt-auto pt-3 border-t border-gray-200/50 dark:border-white/10 text-[10px] text-gray-500 dark:text-gray-400 font-bold uppercase tracking-widest flex justify-between items-center relative z-10">
                    <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full ${liveDot} group-hover:animate-ping inline-block"></span>CANLI AKIŞ</span>
                    <i class="fas fa-arrow-right opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all duration-300 ${arrowColor} text-sm"></i>
                </div>
            </article>
            `;
        }).join('');

        // Sayfalama Kontrolleri Ekleme
        let paginationContainer = document.getElementById('global-news-pagination');
        if (!paginationContainer) {
            paginationContainer = document.createElement('div');
            paginationContainer.id = 'global-news-pagination';
            paginationContainer.className = 'col-span-full flex flex-wrap justify-center items-center mt-8 gap-2';
            if (grid.parentNode) grid.parentNode.insertBefore(paginationContainer, grid.nextSibling);
        }

        if (totalPages > 1) {
            let pageHtml = `<button onclick="window._globalNewsPage=Math.max(1, window._globalNewsPage-1); renderGlobalNewsGrid(window._globalNewsData)" class="px-3 py-1 rounded bg-gray-200 hover:bg-gray-300 dark:bg-slate-700 dark:hover:bg-slate-600 ${window._globalNewsPage === 1 ? 'opacity-50 cursor-not-allowed' : ''}" ${window._globalNewsPage === 1 ? 'disabled' : ''}><i class="fas fa-chevron-left"></i></button>`;

            let startPage = Math.max(1, window._globalNewsPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            if (endPage - startPage < 4 && startPage > 1) {
                startPage = Math.max(1, endPage - 4);
            }

            for (let i = startPage; i <= endPage; i++) {
                pageHtml += `<button onclick="window._globalNewsPage=${i}; renderGlobalNewsGrid(window._globalNewsData)" class="px-3 py-1 rounded ${window._globalNewsPage === i ? 'bg-brandRed text-white font-bold' : 'bg-gray-100 hover:bg-gray-200 dark:bg-slate-800 dark:hover:bg-slate-700'}">${i}</button>`;
            }

            pageHtml += `<button onclick="window._globalNewsPage=Math.min(${totalPages}, window._globalNewsPage+1); renderGlobalNewsGrid(window._globalNewsData)" class="px-3 py-1 rounded bg-gray-200 hover:bg-gray-300 dark:bg-slate-700 dark:hover:bg-slate-600 ${window._globalNewsPage === totalPages ? 'opacity-50 cursor-not-allowed' : ''}" ${window._globalNewsPage === totalPages ? 'disabled' : ''}><i class="fas fa-chevron-right"></i></button>`;

            paginationContainer.innerHTML = pageHtml;
        } else {
            paginationContainer.innerHTML = '';
        }

        requestAnimationFrame(() => {
            grid.style.opacity = '1';
        });
    });
}

// Son güncelleme zamanını gösteren badge günceller
function updateLastRefreshBadge() {
    let badge = document.getElementById('guncel-haberler-refresh-badge');
    if (!badge) {
        const section = document.querySelector('#top-stories-grid')?.closest('section');
        const header = section?.querySelector('.flex.items-center.justify-between');
        if (header) {
            badge = document.createElement('span');
            badge.id = 'guncel-haberler-refresh-badge';
            badge.className = 'text-[10px] text-green-600 dark:text-green-400 font-bold flex items-center gap-1';
            header.appendChild(badge);
        }
    }
    if (badge) {
        const now = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
        badge.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse inline-block"></span> Son güncelleme: ${now}`;
    }
}

// Global Pulse scroll buttons
function scrollPulse(direction) {
    const container = document.getElementById("global-news-container");
    if (!container) return;
    container.scrollBy({ left: direction * 300, behavior: 'smooth' });
}
window.scrollPulse = scrollPulse;

// --- GLOBAL PULSE NEWS SCROLLER ---
async function initGlobalPulse() {
    const slider = document.getElementById("global-news-slider");
    if (!slider || typeof fetchGlobalNews !== 'function') return;

    const data = await fetchGlobalNews(120);
    if (!data || !data.news || data.news.length === 0) {
        slider.innerHTML = '<span class="pulse-item">Haberler yükleniyor...</span>';
        return;
    }

    const newsItems = data.news.map((item, idx) => `
        <div class="pulse-item cursor-pointer hover:text-brandRed transition group" onclick="window.readArticleByIndex(${idx})">
            <span class="mr-2 opacity-50 font-black">${formatSourceName(item.source)} <i class="fas fa-arrow-right scale-75"></i></span>
            <span class="whitespace-nowrap">${item.title}</span>
            <span class="ml-3 px-1 bg-brandRed/20 text-brandRed rounded text-[8px]">${item.country}</span>
        </div>
    `).join("");

    // Repeat for smooth infinite marquee
    slider.innerHTML = newsItems + newsItems;

    // Store globally for custom reader
    window._globalNewsData = data.news;

    // === 1 DAKİKADA BİR OTOMATİK YENİLEME İPTAL EDİLDİ (Caching Optimizasyonu) ===
}

// ====== MAKSİMUM PERFORMANS: KULLANICI TETİKLEMELİ FORCE FETCH (TAZE HABERLER) ======
window.refreshGlobalNewsForcefully = async function() {
    const grid = document.getElementById('top-stories-grid');
    const buttonList = document.querySelectorAll('.taze-haberler-btn');
    
    // Disable buttons
    buttonList.forEach(btn => {
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Yenileniyor...';
        btn.classList.add('opacity-70', 'pointer-events-none');
    });
    
    // 4. GÖREV: Gerçek "Taze Haberler" Butonu, State Reset ve Cache-Busting
    window._globalNewsData = []; // DOM State EMPTY yapıldı
    let targetLang = (typeof window.currentLang !== 'undefined') ? window.currentLang : (localStorage.getItem('pref_lang') || 'tr');
    localStorage.removeItem(`bilimhaber_global_news_${targetLang}`);
    
    // Eğlenceli ve şeffaf dinamik mesajlar (Kullanıcı etkileşimi - i18n Destekli)
    let funMessages = [
        "Önceki haberler süpürülüyor...",
        "İngiliz/Alman/Çin kaynaklarına taze veri talebi gönderildi...",
        "Tercüme motoru en son manşetleri senin diline çeviriyor...",
        "Heyecanla beklediğini biliyorum, taze haberler fırından yeni çıkıyor!",
        "Dünyayı senin için tarıyorum, çok az kaldı...",
        "Haberler yola çıktı, sıcak sıcak masana geliyor!"
    ];
    if (window.currentLang === 'en') {
        funMessages = [
            "Sweeping old news...",
            "Requesting fresh data from global sources...",
            "Translation engine translating headlines to your language...",
            "Almost there, fresh news coming right out of the oven!",
            "Scanning the world for you...",
            "News on the way, served hot!"
        ];
    } else if (window.currentLang === 'fr') {
        funMessages = [
            "Balayage des anciennes actualités...",
            "Demande de données fraîches en cours...",
            "Traduction des gros titres en cours...",
            "Les nouvelles sont presque là, sorties du four !",
            "Analyse du monde pour vous...",
            "Les nouvelles arrivent, toutes chaudes !"
        ];
    } else if (window.currentLang === 'es') {
        funMessages = [
            "Borrando noticias antiguas...",
            "Solicitando datos frescos...",
            "Motor de traducción en marcha...",
            "¡Casi listas, noticias recién salidas del horno!",
            "Escaneando el mundo para ti...",
            "¡Noticias en camino!"
        ];
    }
    let msgIndex = 0;
    
    if(grid) {
        grid.style.opacity = '0';
        setTimeout(() => {
            grid.innerHTML = `
                <div class="col-span-1 md:col-span-2 py-24 flex flex-col items-center justify-center text-brandRed">
                    <i class="fas fa-circle-notch fa-spin text-5xl mb-4"></i>
                    <span id="force-fetch-status-msg" class="font-bold tracking-widest uppercase text-sm text-center px-4 transition-opacity duration-300">${funMessages[0]}</span>
                </div>
            `;
            grid.style.opacity = '1';
        }, 150);
    }
    
    // Mesajları 1.5 saniyede bir değiştir
    let msgInterval = setInterval(() => {
        msgIndex = (msgIndex + 1) % funMessages.length;
        const msgEl = document.getElementById('force-fetch-status-msg');
        if (msgEl) {
            msgEl.style.opacity = '0';
            setTimeout(() => {
                msgEl.innerText = funMessages[msgIndex];
                msgEl.style.opacity = '1';
            }, 300);
        }
    }, 1500);

    // 10 saniyelik güvenlik koruması (Timeout)
    const timeoutPromise = new Promise((resolve) => {
        setTimeout(() => resolve({ error: "timeout" }), 10000);
    });

    try {
        // API'ye force fetch isteği at
        const fetchPromise = fetchGlobalNews(120, true).catch(e => ({ error: "fetch_error" }));
        const freshData = await Promise.race([fetchPromise, timeoutPromise]);
        
        clearInterval(msgInterval);

        if (freshData && freshData.error) {
            throw new Error(freshData.error);
        }

        if(freshData && freshData.news && freshData.news.length > 0) {
            window._globalNewsData = freshData.news;
            
            // Yeni haberleri yumuşak bir fade-in animasyonu ile yükle
            if(grid) grid.style.opacity = '0';
            setTimeout(() => {
                renderGlobalNewsGrid(freshData.news);
                if(grid) grid.style.opacity = '1';
            }, 300);

            // Kayan Yazı (Marquee Ticker) Şeridini Yenile
            const freshItems = freshData.news.map(item => `
                <div class="pulse-item cursor-pointer hover:text-brandRed transition group" onclick="window.readArticleCustom('${btoa(item.link)}')">
                    <span class="mr-2 opacity-50 font-black">${formatSourceName(item.source)} <i class="fas fa-arrow-right scale-75"></i></span>
                    <span class="whitespace-nowrap">${item.title}</span>
                    <span class="ml-3 px-1 bg-brandRed/20 text-brandRed rounded text-[8px]">${item.country}</span>
                </div>
            `).join("");
            const s = document.getElementById("global-news-slider");
            if (s) s.innerHTML = freshItems + freshItems;
            
            if (typeof hydrateDOM === 'function') hydrateDOM();
        } else {
            throw new Error("empty_data"); // Veri gelmediyse veya 0 ise hataya atla
        }
    } catch (err) {
        clearInterval(msgInterval);
        
        // Hata durumunda tatlı bir dil ile tekrar deneme iste
        if(grid) {
            grid.style.opacity = '0';
            setTimeout(() => {
                grid.innerHTML = `
                    <div class="col-span-1 md:col-span-2 py-16 flex flex-col items-center justify-center text-slate-500 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-300 dark:border-slate-700">
                        <i class="fas fa-unlink text-4xl mb-4 text-orange-400 opacity-80"></i>
                        <span class="font-bold text-sm text-center px-4 mb-4 uppercase tracking-wider">Bağlantıda ufak bir sorun oldu ama pes etmiyorum<br>Lütfen tekrar dene!</span>
                        <button onclick="refreshGlobalNewsForcefully()" class="inline-flex items-center justify-center bg-brandRed text-white px-6 py-2.5 rounded-full font-black text-xs uppercase tracking-widest shadow-md hover:bg-red-700 hover:scale-105 active:scale-95 transition-all"><i class="fas fa-sync-alt mr-2"></i>Tekrar Dene</button>
                    </div>
                `;
                grid.style.opacity = '1';
            }, 150);
        }
    }
    
    // Butonları eski haline döndür
    buttonList.forEach(btn => {
        btn.innerHTML = '<i class="fas fa-sync-alt mr-2"></i>Taze Haberler';
        btn.classList.remove('opacity-70', 'pointer-events-none');
    });
}

// Safe index-based global reader
window.readArticleByIndex = function (index) {
    try {
        if (!window._globalNewsData || index < 0 || index >= window._globalNewsData.length) {
            console.warn("Global haber datasında index bulunamadı:", index);
            return;
        }

        const item = window._globalNewsData[index];

        // Ensure we have a valid article ID format for the reader
        // Convert GlobalNewsItem to Article-like object
        const encodedLink = btoa(unescape(encodeURIComponent(item.link || '')));
        const artId = 'global_' + encodedLink;

        const art = {
            id: artId,
            title: item.title,
            url: item.link,
            source: typeof formatSourceName === 'function' ? formatSourceName(item.source) : item.source,
            ai_category: item.ai_category || item.category || "Dünya",
            ai_summary: item.description,
            description: item.description || '',
            image_url: item.image_url || (typeof getFallbackImage === 'function' ? getFallbackImage(item.ai_category || item.category || "World", item.link) : '')
        };

        // Inject into articles if not there (for reader to find it)
        let targetId = art.id;
        const existingArt = AppState.articles.find(a => a.url === item.link || a.link === item.link);
        if (!existingArt) {
            AppState.articles.push(art);
        } else {
            existingArt.description = existingArt.description || item.description || '';
            existingArt.ai_summary = existingArt.ai_summary || item.description || '';
            existingArt.image_url = existingArt.image_url || art.image_url;
            targetId = existingArt.id;
        }

        if (typeof window.readArticle === 'function') {
            window.readArticle(targetId);
        }
    } catch (err) {
        alert("Haberi Açarken Hata: " + err.message);
        console.error("readArticleByIndex error:", err);
    }
}

window.readArticleCustom = function (encodedLinkOrUrl) {
    try {
        if (!encodedLinkOrUrl) return;

        let resolvedUrl = String(encodedLinkOrUrl);
        try {
            resolvedUrl = atob(encodedLinkOrUrl);
        } catch (_) {
            // Parametre zaten duz URL olabilir.
        }

        const normalizedUrl = resolvedUrl.trim();
        if (!normalizedUrl) return;

        if (Array.isArray(window._globalNewsData) && window._globalNewsData.length > 0) {
            const globalIndex = window._globalNewsData.findIndex(item =>
                String(item.link || item.url || '').trim() === normalizedUrl
            );

            if (globalIndex >= 0) {
                window.readArticleByIndex(globalIndex);
                return;
            }
        }

        const localArticle = (AppState.articles || []).find(item =>
            String(item.url || item.link || '').trim() === normalizedUrl || String(item.id) === normalizedUrl
        );

        if (localArticle && typeof window.readArticle === 'function') {
            window.readArticle(localArticle.id);
            return;
        }

        console.warn("readArticleCustom: Haber kaydi bulunamadi:", normalizedUrl);
    } catch (err) {
        console.error("readArticleCustom error:", err);
    }
}

// --- RAG CHAT LOGIC ---
function initRagChat() {
    const sendBtn = document.getElementById("rag-chat-send");
    const input = document.getElementById("rag-chat-input");
    const msgContainer = document.getElementById("rag-chat-messages");

    if (!sendBtn || !input) return;

    window.addChatMessage = (role, text) => {
        const div = document.createElement("div");
        div.className = `p-2 rounded-xl text-[11px] leading-relaxed message-enter ${role === 'user'
                ? 'bg-brandRed/10 border-r-4 border-brandRed ml-4 text-right'
                : 'bg-white dark:bg-slate-700 border-l-4 border-gray-300 mr-4 shadow-sm'
            }`;
        div.innerHTML = `<strong>${role === 'user' ? 'Sen' : 'Asistan'}:</strong><br>${text}`;
        msgContainer.appendChild(div);
        msgContainer.scrollTop = msgContainer.scrollHeight;
    }

    const handleSend = async () => {
        const question = input.value.trim();
        if (!question) return;

        const currentArtId = window._currentArticleId;
        if (!currentArtId) return;

        addChatMessage('user', question);
        input.value = "";

        // "Düşünüyor..." placeholder
        const loadingDiv = document.createElement("div");
        loadingDiv.className = "text-[10px] text-gray-400 italic ml-2 animate-pulse";
        loadingDiv.innerText = "Yapay zeka yanıt veriyor...";
        msgContainer.appendChild(loadingDiv);

        const session = typeof Auth !== 'undefined' ? Auth.getSession() : null;
        const token = session ? session.id : 'demo-token';
        const res = await chatWithArticle(currentArtId, question, token);

        loadingDiv.remove();
        addChatMessage('ai', res.answer);
    };

    sendBtn.onclick = handleSend;
    input.onkeypress = (e) => { if (e.key === 'Enter') handleSend(); };
}

// Update readArticle to store current ID
const originalReadArticle = window.readArticle;
window.readArticle = function (id) {
    window._currentArticleId = id;
    // Chat'i temizle
    const msgContainer = document.getElementById("rag-chat-messages");
    if (msgContainer) msgContainer.innerHTML = "";
    originalReadArticle(id);
}
readArticle = window.readArticle;

// --- GLOBAL CHAT LOGIC ---
function initGlobalChat() {
    const floatBtn = document.getElementById("ai-float-btn");
    const containerEl = document.getElementById("ai-float-container");
    const panel = document.getElementById("ai-float-panel");
    const closeBtn = document.getElementById("ai-float-close");
    const startBtn = document.getElementById("ai-float-start-btn");
    const introView = document.getElementById("ai-float-intro");
    const chatView = document.getElementById("ai-float-chat");
    const chatInput = document.getElementById("ai-float-input");
    const chatSend = document.getElementById("ai-float-send");
    const chatMessages = document.getElementById("ai-float-messages");

    if (!floatBtn || !panel) return;

    let isOpen = false;

    // Paneli Aç / Kapat
    function togglePanel() {
        isOpen = !isOpen;
        if (isOpen) {
            panel.classList.remove("invisible", "opacity-0", "translate-y-4");
        } else {
            panel.classList.add("invisible", "opacity-0", "translate-y-4");
        }
    }

    floatBtn.addEventListener("click", togglePanel);
    closeBtn.addEventListener("click", togglePanel);

    // Sohbet Başlat
    startBtn.addEventListener("click", () => {
        introView.classList.add("hidden");
        chatView.classList.remove("hidden");
        chatView.classList.add("flex");
        chatInput.focus();
    });

    // Chat Mesaj Ekleme
    function addMessage(role, text) {
        const div = document.createElement("div");
        div.className = `p-2 rounded-xl text-[11px] leading-relaxed shadow-sm w-11/12 ${role === "user"
                ? "bg-brandRed/10 border-r-4 border-brandRed text-right self-end text-gray-800 dark:text-gray-100"
                : "bg-white dark:bg-slate-700 border-l-4 border-gray-300 text-gray-700 dark:text-gray-200 self-start"
            }`;
        div.innerHTML = `<strong>${role === "user" ? "Sen" : "Asistan"}:</strong><br>${text}`;
        chatMessages.appendChild(div);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Gönderim Olayı
    async function handleglobalSend() {
        const query = chatInput.value.trim();
        if (!query) return;

        addMessage("user", query);
        chatInput.value = "";

        // Düşünüyor
        const loadingDiv = document.createElement("div");
        loadingDiv.className = "text-[10px] text-gray-400 italic ml-2 animate-pulse self-start";
        loadingDiv.innerText = "Yapay zeka yanıt veriyor...";
        chatMessages.appendChild(loadingDiv);

        // Gündem verisini topla (Bağlam için)
        // Maksimum 15 haberi context olarak al
        let contextData = "";
        const allItems = window._globalNewsData || AppState.articles || [];
        const topItems = allItems.slice(0, 15);
        if (topItems.length > 0) {
            contextData = topItems.map((item, idx) => `[${idx + 1}] Başlık: ${item.title} | Kaynak: ${item.source || 'Bilinmiyor'} | Açıklama: ${item.ai_summary || item.description || ''}`).join("\n");
        } else {
            contextData = "Şu an haber bulunamadı.";
        }

        const answer = await chatWithGlobalAI(query, contextData);

        loadingDiv.remove();
        addMessage("ai", answer);
    }

    chatSend.addEventListener("click", handleglobalSend);
    chatInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") handleglobalSend();
    });
}

// ================================================================
// HERO KARUSEL SİSTEMİ
// ================================================================

let _heroCarouselIndex = 0;
let _heroCarouselTimer = null;
let _heroCarouselProgressTimer = null;
const HERO_CAROUSEL_INTERVAL = 5000; // 5 saniye

function initHeroCarousel() {
    const data = window._heroCarouselData;
    if (!data || data.length === 0) return;

    window._heroCarouselInit = true;
    _heroCarouselIndex = 0;

    // Dot'ları oluştur
    const dotsContainer = document.getElementById('hero-carousel-dots');
    if (dotsContainer) {
        dotsContainer.innerHTML = data.map((_, i) =>
            `<button class="hero-carousel-dot ${i === 0 ? 'active' : ''}" onclick="heroCarouselGoTo(${i})" aria-label="Haber ${i + 1}"></button>`
        ).join('');
    }

    // İlk haberi göster
    showHeroSlide(0, false);

    // Otomatik geçişi başlat
    startHeroAutoPlay();

    // Hover'da durdur
    const strip = document.getElementById('hero-carousel');
    if (strip) {
        strip.addEventListener('mouseenter', () => {
            stopHeroAutoPlay();
        });
        strip.addEventListener('mouseleave', () => {
            startHeroAutoPlay();
        });
    }
}

function showHeroSlide(index, animate = true) {
    const data = window._heroCarouselData;
    if (!data || data.length === 0) return;

    _heroCarouselIndex = index;
    const item = data[index];

    const imgEl = document.getElementById('hero-carousel-img');
    const titleEl = document.getElementById('hero-carousel-title');
    const summaryEl = document.getElementById('hero-carousel-summary');
    const catEl = document.getElementById('hero-carousel-cat');
    const sourceEl = document.getElementById('hero-carousel-source');
    const contentWrap = document.querySelector('.hero-carousel-content');

    if (!imgEl || !titleEl) return;

    if (animate) {
        // Fade out
        contentWrap.classList.add('hero-carousel-fade-out');
        contentWrap.classList.remove('hero-carousel-fade-in');
        imgEl.classList.add('fade-out');
        imgEl.classList.remove('fade-in');

        setTimeout(() => {
            // İçerik güncelle
            _updateHeroContent(item, imgEl, titleEl, summaryEl, catEl, sourceEl);

            // Fade in
            contentWrap.classList.remove('hero-carousel-fade-out');
            contentWrap.classList.add('hero-carousel-fade-in');
            imgEl.classList.remove('fade-out');
            imgEl.classList.add('fade-in');
        }, 350);
    } else {
        _updateHeroContent(item, imgEl, titleEl, summaryEl, catEl, sourceEl);
    }

    // Dot'ları güncelle
    const dots = document.querySelectorAll('.hero-carousel-dot');
    dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === index);
    });

    // Progress bar sıfırla
    resetProgressBar();
}

function _updateHeroContent(item, imgEl, titleEl, summaryEl, catEl, sourceEl) {
    imgEl.src = item.image;
    imgEl.onerror = () => { imgEl.src = item.fallbackImage; };
    titleEl.textContent = item.title;

    // Global haberler yeni sekmede açılır, yerel haberler modal'da
    if (item.isGlobal && item.link) {
        titleEl.onclick = () => window.open(item.link, '_blank');
    } else {
        titleEl.onclick = () => readArticle(item.id);
    }

    summaryEl.textContent = item.summary.replace(/\\n/g, ' ').substring(0, 150);
    catEl.textContent = item.category;

    if (item.isGlobal) {
        sourceEl.innerHTML = `<i class="fas fa-globe-americas mr-1"></i>${formatSourceName(item.source)}`;
    } else {
        sourceEl.innerHTML = `<i class="fas fa-rss mr-1"></i>${formatSourceName(item.source)}`;
    }
}

function heroCarouselNext() {
    const data = window._heroCarouselData;
    if (!data || data.length === 0) return;
    const next = (_heroCarouselIndex + 1) % data.length;
    showHeroSlide(next, true);
    // Reset autoplay
    stopHeroAutoPlay();
    startHeroAutoPlay();
}

function heroCarouselPrev() {
    const data = window._heroCarouselData;
    if (!data || data.length === 0) return;
    const prev = (_heroCarouselIndex - 1 + data.length) % data.length;
    showHeroSlide(prev, true);
    // Reset autoplay
    stopHeroAutoPlay();
    startHeroAutoPlay();
}

function heroCarouselGoTo(index) {
    showHeroSlide(index, true);
    stopHeroAutoPlay();
    startHeroAutoPlay();
}

function startHeroAutoPlay() {
    stopHeroAutoPlay();
    _heroCarouselTimer = setInterval(() => {
        heroCarouselNext();
    }, HERO_CAROUSEL_INTERVAL);
    resetProgressBar();
}

function stopHeroAutoPlay() {
    if (_heroCarouselTimer) {
        clearInterval(_heroCarouselTimer);
        _heroCarouselTimer = null;
    }
    if (_heroCarouselProgressTimer) {
        clearInterval(_heroCarouselProgressTimer);
        _heroCarouselProgressTimer = null;
    }
}

function resetProgressBar() {
    const bar = document.getElementById('hero-carousel-progress-bar');
    if (!bar) return;

    bar.style.width = '0%';

    if (_heroCarouselProgressTimer) {
        clearInterval(_heroCarouselProgressTimer);
    }

    let progress = 0;
    const step = 100 / (HERO_CAROUSEL_INTERVAL / 50); // Her 50ms'de güncelle

    _heroCarouselProgressTimer = setInterval(() => {
        progress += step;
        if (progress >= 100) {
            progress = 100;
            clearInterval(_heroCarouselProgressTimer);
        }
        bar.style.width = progress + '%';
    }, 50);
}

// Global erişim
window.heroCarouselNext = heroCarouselNext;
window.heroCarouselPrev = heroCarouselPrev;
window.heroCarouselGoTo = heroCarouselGoTo;

// ==========================================
// YENİ EKLENEN FONKSİYONLAR (Like, WS, Cluster)
// ==========================================

async function handleLike(articleId, event) {
    if (event) event.stopPropagation(); // Habere tıklanıp modal açılmasını engelle

    const session = typeof Auth !== 'undefined' ? Auth.getSession() : null;
    if (!session) {
        if (typeof openSigninModal === 'function') openSigninModal();
        showToast("Uyarı", "Haberi beğenmek ve sana özel haberler görebilmek için giriş yapmalısın.", "warning");
        return;
    }

    try {
        const btn = event.currentTarget || event.target.closest('button');
        const icon = btn.querySelector('i');

        // Backend API
        const tk = session.token || session.id || "dummy-token-for-local";
        const res = await (typeof toggleLikeApi === 'function' ? toggleLikeApi(articleId, tk) : Promise.reject('API yok'));
        if (res && res.status === 'liked') {
            icon.classList.remove('fa-heart', 'far'); // far varsayarsan
            icon.classList.add('fa-heart', 'fas');
            btn.classList.remove('text-gray-400');
            btn.classList.add('text-brandRed');
            showToast("BİLİMHABER", "Haber beğenildi. Önerileriniz güncellenecek.", "success");
        } else {
            icon.classList.remove('fa-heart', 'fas');
            icon.classList.add('far', 'fa-heart');
            btn.classList.remove('text-brandRed');
            btn.classList.add('text-gray-400');
            showToast("BİLİMHABER", "Beğeni geri alındı.", "info");
        }
    } catch (e) {
        showToast("Hata", e.message || "Beğeni işlemi sırasında hata oluştu.", "error");
    }
}
window.handleLike = handleLike;

// WebSocket Initialization
let wsCriticalNews = null;
function initCriticalNewsWebSocket() {
    if (wsCriticalNews) return;
    try {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        // API_BASE_URL den url çek (http://127.0.0.1:8000/api/v1 => ws://127.0.0.1:8000/api/v1/ws/critical-news)
        let wsUrl = API_BASE_URL.replace(/^http/, 'ws') + '/ws/critical-news';

        wsCriticalNews = new WebSocket(wsUrl);

        wsCriticalNews.onmessage = function (event) {
            try {
                const data = JSON.parse(event.data);
                if (data.message && data.article) {
                    showToast("✨ İLGİNİ ÇEKEBİLİR: " + (data.article.category || 'GÜNDEM'), data.article.title, "magic", data.article.link);
                }
            } catch (e) { }
        };

        wsCriticalNews.onerror = function () {
            console.warn("WebSocket bağlantsında hata. Arkaplanda tekrar denenecek.");
        };

        wsCriticalNews.onclose = function () {
            wsCriticalNews = null;
            setTimeout(initCriticalNewsWebSocket, 10000); // 10s sonra tekrar dene
        };
    } catch (err) {
        console.error("WS INIT ERROR", err);
    }
}
window.initCriticalNewsWebSocket = initCriticalNewsWebSocket;

// Cluster Render
// Cluster Render (REMOVED: User wants clusters to appear as regular news cards)
// Toast UI Functionality
function showToast(title, message, type = 'info', link = null) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'w-80 bg-white dark:bg-slate-900 rounded-lg shadow-2xl overflow-hidden border-l-4 transform transition-all duration-300 translate-x-full pointer-events-auto';

    // Type Colors
    let colorClass = 'border-blue-500';
    let icon = 'fa-info-circle text-blue-500';
    if (type === 'error') { colorClass = 'border-red-600'; icon = 'fa-exclamation-triangle text-red-600'; }
    if (type === 'success') { colorClass = 'border-green-500'; icon = 'fa-check-circle text-green-500'; }
    if (type === 'warning') { colorClass = 'border-orange-500'; icon = 'fa-bell text-orange-500 animate-swing'; }
    if (type === 'magic') { colorClass = 'border-indigo-500'; icon = 'fa-lightbulb text-indigo-500 animate-pulse'; }

    toast.classList.add(colorClass);

    toast.innerHTML = `
        <div class="p-4 flex items-start gap-3">
            <div class="flex-shrink-0 mt-0.5"><i class="fas ${icon} text-xl"></i></div>
            <div class="flex-1">
                <h4 class="text-xs font-black uppercase tracking-wider text-gray-900 dark:text-white mb-1">${title}</h4>
                <p class="text-sm text-gray-600 dark:text-gray-300 leading-snug">${message}</p>
                ${link ? `<a href="${link}" target="_blank" class="text-[10px] text-brandRed font-bold mt-2 inline-block hover:underline">Habere Git &rarr;</a>` : ''}
            </div>
            <button class="text-gray-400 hover:text-gray-600 flex-shrink-0" onclick="this.closest('div.border-l-4').remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

    container.appendChild(toast);

    // Animate in
    requestAnimationFrame(() => {
        toast.classList.remove('translate-x-full');
    });

    // Auto remove
    setTimeout(() => {
        toast.classList.add('translate-x-full', 'opacity-0');
        setTimeout(() => toast.remove(), 300);
    }, 6000);
}
window.showToast = showToast;

// ================================================================
// KARŞILAŞTIRMA MOTORu — KAYNAK-BAZLI (SOURCE-FIRST) MİMARİ
//
// Kullanım:
//   1. readArticle() tetiklendiğinde `setupDynamicComparisons(art, allNews)` çağrılır.
//   2. Tüm haber havuzundan benzersiz kaynaklar çekilip her iki Dropdown'a doldurulur.
//   3. Kullanıcı kaynak seçince `matchArticleBySource(targetSource, currentArt, allNews)`
//      üzerinden eşleşen haber bulunur ve panel'e basılır.
//
// Haber objesi yapısı: { id, title, description, source, ai_category,
//                        sentiment, ai_summary, url, image_url, country }
// ================================================================

// Aktif haber ve tüm havuz — readArticle tarafından doldurulur
window._comparisonCurrentArt = null;
window._comparisonAllNews    = [];

// ---- YARDIMCI: Başlık + Açıklama üzerinden keyword örtüşme skoru ----
function _keywordScore(artA, artB) {
    const stopWords = new Set([
        'the','and','for','that','with','this','from','are','was','has','been',
        'bir','ve','bu','için','olan','ile','de','da','den','dan','şu','çok',
        'daha','en','ne','ya','ki','mi','mu','mü','mı','o','da','de'
    ]);
    const textA = ((artA.title || '') + ' ' + (artA.description || '')).toLowerCase();
    const textB = ((artB.title || '') + ' ' + (artB.description || '')).toLowerCase();
    const wordsA = new Set(
        textA.split(/[\s,.!?;:()\[\]""'']+/)
             .filter(w => w.length > 3 && !stopWords.has(w))
    );
    let score = 0;
    for (const w of wordsA) {
        if (textB.includes(w)) score++;
    }
    return score;
}

// ---- YARDIMCI: Verilen kaynaktan, currentArt konusuna en yakın haberi bul ----
// ŞART 1: haber.source normalized === targetSource (FARKLI KAYNAK garanti readArticle'da)
// ŞART 2a: haber.ai_category === currentArt.ai_category (öncelik)
// ŞART 2b: keyword overlap skoru >= 1 (fallback)
function matchArticleBySource(targetSourceNorm, currentArt, allNews) {
    const pool = allNews.filter(a => {
        if (String(a.id) === String(currentArt.id)) return false;
        return formatSourceName(a.source || '') === targetSourceNorm;
    });
    if (pool.length === 0) return null;

    // Önce aynı kategori
    const sameCat = pool.filter(a => a.ai_category === currentArt.ai_category);
    if (sameCat.length > 0) {
        // Aynı kategoridekiler arasında keyword skoru en yükseği
        return sameCat
            .map(a => ({ ...a, _score: _keywordScore(currentArt, a) }))
            .sort((a, b) => b._score - a._score)[0];
    }

    // Fallback: keyword skoru en yüksek
    const ranked = pool
        .map(a => ({ ...a, _score: _keywordScore(currentArt, a) }))
        .sort((a, b) => b._score - a._score);
    return ranked[0]?._score >= 1 ? ranked[0] : null;
}

// ---- ANA FONKSİYON: Modal açıldığında çağrılır — TAM DEFENSIVE ----
function setupDynamicComparisons(currentArt, allNews) {
    // AI analiz kutusunu ve panel sayacını sıfırla
    window._comparisonPanelsReady = 0;
    const aiBody = document.getElementById('comparison-ai-analysis-body');
    const aiBar  = document.getElementById('comparison-ai-refresh-bar');
    if (aiBody) aiBody.innerHTML = '<div style="padding:24px;text-align:center;color:#9ca3af;font-size:12px;font-style:italic;"><i class="fas fa-balance-scale" style="font-size:28px;opacity:0.15;display:block;margin-bottom:8px;"></i>İki kaynak seçildiğinde yapay zeka tarafsız medya analizi üretir.</div>';
    if (aiBar)  aiBar.classList.add('hidden');

    // Havuzu: geçilen + AppState + globalNewsData birleştir (boşlukları kapat)
    const mergedNews = [
        ...(Array.isArray(allNews)               ? allNews               : []),
        ...(Array.isArray(AppState.articles)     ? AppState.articles     : []),
        ...(Array.isArray(window._globalNewsData)? window._globalNewsData: [])
    ];
    // ID bazlı tekilleştir
    const seenIds = new Set();
    const dedupedNews = [];
    for (const a of mergedNews) {
        if (!a || !a.id) continue;
        const key = String(a.id);
        if (!seenIds.has(key)) { seenIds.add(key); dedupedNews.push(a); }
    }
    console.log('[Comparison] setupDynamicComparisons çağrıldı. Birleşik havuz:', dedupedNews.length, 'haber');
    console.log('[Comparison] currentArt:', currentArt);

    try {
        const select1  = document.getElementById('compare-source-1');
        const select2  = document.getElementById('compare-source-2');
        const content1 = document.getElementById('compare-content-1');
        const content2 = document.getElementById('compare-content-2');

        // DEFENSIVE: UI elementleri yoksa sessizce çık
        if (!select1 || !select2 || !content1 || !content2) {
            console.warn('[Comparison] DOM elementleri bulunamadı (modal henüz render edilmemiş olabilir).');
            return;
        }

        // DEFENSIVE: currentArt null/undefined ise Early Return
        if (!currentArt || typeof currentArt !== 'object') {
            console.warn('[Comparison] currentArt geçersiz:', currentArt);
            const msg = '<div class="flex flex-col items-center justify-center h-full text-gray-400 opacity-60 py-10 text-sm italic text-center"><i class="fas fa-info-circle text-3xl mb-3 opacity-30"></i><span>Ana sayfadan haber verisi bekleniyor...</span></div>';
            content1.innerHTML = msg;
            content2.innerHTML = msg;
            return;
        }

        // DEFENSIVE: allNews array kontrolü — artık dedupedNews kullan
        const safeNews = dedupedNews;

        // Aktif haberi ve havuzu global'e kaydet
        window._comparisonCurrentArt = currentArt;
        window._comparisonAllNews    = safeNews;

        // ---- 1. Tüm kaynakları al — mevcut haberin kaynağını hariç tut ----
        const currentSourceNorm = formatSourceName(currentArt.source || '');
        console.log('[Comparison] Aktif kaynak (hariç tutulacak):', currentSourceNorm);

        const uniqueSourceMap = new Map();
        for (const a of safeNews) {
            // DEFENSIVE: her kart nesnesini kontrol et
            if (!a || typeof a !== 'object') continue;
            const norm = formatSourceName(a.source || '');
            if (norm && norm !== currentSourceNorm && !uniqueSourceMap.has(norm)) {
                uniqueSourceMap.set(norm, norm);
            }
        }

        const sources = [...uniqueSourceMap.keys()].sort();
        console.log('[Comparison] Bulunan benzersiz kaynaklar:', sources);

        // ---- 2. Yükleniyor spinner ----
        const spinnerHTML = '<div class="flex flex-col items-center justify-center h-full space-y-3 py-10 opacity-70"><i class="fas fa-satellite-dish fa-spin text-3xl text-blue-400"></i><span class="text-[10px] font-bold text-gray-500 uppercase tracking-widest animate-pulse">Kaynak taranıyor...</span></div>';
        content1.innerHTML = spinnerHTML;
        content2.innerHTML = spinnerHTML;

        // ---- 3. Dropdown'ları doldur ----
        select1.innerHTML = '';
        select2.innerHTML = '';

        // DEFENSIVE: Hiç kaynak yoksa zarif boş durum göster
        if (!sources || sources.length === 0) {
            console.warn('[Comparison] Karşılaştırılacak kaynak bulunamadı. Havuz boş olabilir.');
            select1.innerHTML = '<option value="" disabled selected>Kaynak bulunamadı</option>';
            select2.innerHTML = '<option value="" disabled selected>Kaynak bulunamadı</option>';
            const noSrcMsg = '<div class="flex flex-col items-center justify-center h-full text-gray-400 opacity-60 py-10 text-sm italic text-center"><i class="fas fa-satellite-dish text-4xl mb-3 opacity-30"></i><span>Sistemde karşılaştırılacak başka kaynak bulunamadı.</span></div>';
            content1.innerHTML = noSrcMsg;
            content2.innerHTML = noSrcMsg;
            return;
        }

        // Placeholder + option'ları ekle
        const ph1 = new Option('— Kaynak A Seçin —', '');
        ph1.disabled = true; ph1.selected = true;
        select1.appendChild(ph1);

        const ph2 = new Option('— Kaynak B Seçin —', '');
        ph2.disabled = true; ph2.selected = true;
        select2.appendChild(ph2);

        // DEFENSIVE: sources gerçekten array mi?
        if (Array.isArray(sources) && sources.length > 0) {
            sources.forEach(srcNorm => {
                if (!srcNorm) return; // boş string'leri geç
                select1.appendChild(new Option(srcNorm, srcNorm));
                select2.appendChild(new Option(srcNorm, srcNorm));
            });
        }

        // ---- 4. En alakalı 2 kaynağı otomatik seç ----
        const rankedSources = sources
            .filter(s => !!s) // boş string guard
            .map(srcNorm => {
                let score = -1;
                try {
                    const match = matchArticleBySource(srcNorm, currentArt, safeNews);
                    if (match) {
                        score = (match.ai_category === currentArt.ai_category ? 100 : 0) + (match._score || 0);
                    }
                } catch (matchErr) {
                    console.warn('[Comparison] matchArticleBySource hatası:', matchErr.message);
                }
                return { srcNorm, score };
            })
            .sort((a, b) => b.score - a.score);

        console.log('[Comparison] Sıralanmış kaynaklar:', rankedSources);

        const srcA = (rankedSources[0] && rankedSources[0].srcNorm) ? rankedSources[0].srcNorm : sources[0];
        const srcB = (rankedSources[1] && rankedSources[1].srcNorm) ? rankedSources[1].srcNorm : (sources[1] || sources[0]);

        console.log('[Comparison] Otomatik seçilen Kaynak A:', srcA, '| Kaynak B:', srcB);

        select1.value = srcA;
        select2.value = srcB;

        // ---- 5. Her iki paneli render et ----
        window.renderComparisonPanel(1, srcA);
        window.renderComparisonPanel(2, srcB);

    } catch (err) {
        // DEFENSIVE: Hiçbir hata modalı beyaza boyamaz
        console.error('[Comparison] setupDynamicComparisons HATA:', err.message, err);
    }
}

window.setupDynamicComparisons = setupDynamicComparisons;

// ---- KULLANICI DROPDOWN DEĞİŞTİRİNCE ÇAĞRILIR (onchange hook) ----
// HTML: onchange="window.updateComparisonUI(1, this.value)"
window.updateComparisonUI = function(panelIndex, selectedSourceNorm) {
    window.renderComparisonPanel(panelIndex, selectedSourceNorm);
};

// ---- PANEL RENDER: Seçili kaynağın bu konudaki haberini bul ve bas ----
window.renderComparisonPanel = async function(panelIndex, selectedSourceNorm) {
    console.log(`[Comparison] renderComparisonPanel(${panelIndex}) → kaynak: "${selectedSourceNorm}"`); try {
    const contentEl = document.getElementById(`compare-content-${panelIndex}`);
    if (!contentEl) return;

    const currentArt = window._comparisonCurrentArt;
    const allNews    = window._comparisonAllNews;

    // Yükleniyor
    contentEl.innerHTML = `
        <div class="flex flex-col items-center justify-center h-full space-y-4 py-10 opacity-70">
            <i class="fas fa-circle-notch fa-spin text-3xl text-blue-500"></i>
            <span class="text-[10px] font-bold text-gray-500 uppercase tracking-widest animate-pulse">
                ${selectedSourceNorm} kaynağı taranıyor...
            </span>
        </div>`;

    if (!selectedSourceNorm || !currentArt) {
        contentEl.innerHTML = `
            <div class="flex flex-col items-center justify-center h-full text-gray-400 opacity-60 py-10 text-sm italic text-center">
                <i class="fas fa-hand-pointer text-4xl mb-3 opacity-30"></i>
                <span>Lütfen yukarıdan bir kaynak seçin.</span>
            </div>`;
        return;
    }

    // Eşleşen haberi bul
    const match = matchArticleBySource(selectedSourceNorm, currentArt, allNews);

    // BOŞLUK DURUMU: Bu kaynak bu konuda haber yapmamış
    if (!match) {
        contentEl.innerHTML = `
            <div class="flex flex-col items-center justify-center h-full text-gray-400 opacity-60 py-10 text-sm text-center">
                <i class="fas fa-newspaper text-5xl mb-4 opacity-20"></i>
                <p class="font-bold text-base mb-1 text-slate-500 dark:text-slate-400">${selectedSourceNorm}</p>
                <p class="italic text-sm">Bu kaynak, bu konu hakkında henüz bir haber yayınlamadı.</p>
                <p class="text-xs mt-2 opacity-60">Farklı bir kaynak seçmeyi deneyin.</p>
            </div>`;
        return;
    }

    // Çeviri
    const targetLang = (typeof window.currentLang !== 'undefined')
        ? window.currentLang
        : (localStorage.getItem('pref_lang') || 'tr');

    let title     = match.title       || 'Adsız Haber';
    let desc      = match.description || match.ai_summary || 'Bu kaynak konuyu okumak için orijinal habere gidin.';
    let sentiment = match.sentiment   || 'Neutral';
    let aiKeycat  = match.ai_category || 'Genel';

    if (targetLang && typeof translateTextFree === 'function') {
        const sentimentMap = {
            'Positive': targetLang === 'en' ? 'Positive Approach'  : 'Pozitif Yaklaşım',
            'Negative': targetLang === 'en' ? 'Critical / Negative': 'Eleştirel / Negatif',
            'Urgent':   targetLang === 'en' ? 'Urgent & Breaking'  : 'Sıcak & Acil',
            'Neutral':  targetLang === 'en' ? 'Neutral Coverage'   : 'Tarafsız İzleme'
        };
        [title, desc] = await Promise.all([
            translateTextFree(title, targetLang),
            translateTextFree(desc,  targetLang)
        ]);
        sentiment = sentimentMap[match.sentiment] || sentiment;
    }

    const panelColor = panelIndex === 1 ? 'blue' : 'red';
    const articleLink = match.url || match.link || '';

    console.log(`[Comparison] Panel ${panelIndex} render tamamlandı. Başlık: "${title.substring(0, 60)}..."`); contentEl.innerHTML = `
        <div class="animate-fade-in flex flex-col h-full">
            <div class="flex items-center gap-2 mb-3 flex-wrap">
                <span class="text-[9px] font-black text-${panelColor}-600 dark:text-${panelColor}-400
                             bg-${panelColor}-50 dark:bg-${panelColor}-900/30
                             border border-${panelColor}-200 dark:border-${panelColor}-800
                             px-2 py-0.5 rounded uppercase tracking-widest">
                    ${selectedSourceNorm}
                </span>
                <span class="text-[9px] font-bold text-gray-400 uppercase tracking-wide">${aiKeycat}</span>
                ${match.country ? `<span class="text-[9px] text-gray-400 uppercase tracking-wide">🌐 ${match.country}</span>` : ''}
            </div>

            <h4 class="font-black text-lg md:text-[18px] text-slate-900 dark:text-white leading-snug mb-3 font-serif line-clamp-3">
                ${title}
            </h4>

            <div class="text-[12px] text-gray-700 dark:text-gray-300 leading-relaxed font-serif mb-4
                        flex-grow overflow-y-auto custom-scrollbar pr-2">
                ${desc}
            </div>

            <div class="bg-gray-50 border border-gray-200 dark:bg-slate-800/80 dark:border-slate-700
                        rounded-xl p-4 mt-auto shadow-sm">
                <div class="flex items-center gap-2 mb-2">
                    <i class="fas fa-robot text-${panelColor}-500 text-sm drop-shadow-sm"></i>
                    <h5 class="text-[10px] font-black text-gray-800 dark:text-gray-300 uppercase tracking-widest">
                        Yapay Zeka Analizi
                    </h5>
                </div>
                <div class="space-y-1.5 pt-2 border-t border-gray-200 dark:border-slate-700/50">
                    <div class="flex justify-between items-center text-xs">
                        <span class="font-bold text-gray-500 dark:text-gray-400 tracking-wide">Yayın Yaklaşımı:</span>
                        <span class="font-black text-slate-800 dark:text-gray-200 bg-white dark:bg-slate-900
                                     px-2 py-0.5 border border-gray-200 dark:border-slate-600
                                     rounded text-[10px] uppercase">${sentiment}</span>
                    </div>
                    <div class="flex justify-between items-center text-xs">
                        <span class="font-bold text-gray-500 dark:text-gray-400 tracking-wide">Ana Odak:</span>
                        <span class="font-bold text-slate-800 dark:text-gray-200 text-right line-clamp-1 max-w-[60%]">
                            ${aiKeycat}
                        </span>
                    </div>
                    ${articleLink ? `
                    <div class="pt-1 mt-1 border-t border-gray-100 dark:border-slate-700">
                        <a href="${articleLink}" target="_blank" rel="noopener noreferrer"
                           class="text-[10px] font-bold text-${panelColor}-600 hover:underline flex items-center gap-1">
                            <i class="fas fa-external-link-alt text-[8px]"></i> Orijinal Habere Git
                        </a>
                    </div>` : ''}
                </div>
            </div>
        </div>`;

    // Her iki panel tamamlandığında AI analizi tetikle
    if (typeof window._onComparisonPanelReady === 'function') window._onComparisonPanelReady();

    } catch (renderErr) {
        // DEFENSIVE: render hatası sessizce loglanır, panel'e hata mesajı yazılır
        console.error(`[Comparison] renderComparisonPanel(${panelIndex}) HATA:`, renderErr.message, renderErr);
        const errEl = document.getElementById(`compare-content-${panelIndex}`);
        if (errEl) {
            errEl.innerHTML = `<div class="flex flex-col items-center justify-center h-full text-orange-400 opacity-80 py-10 text-sm italic text-center">
                <i class="fas fa-exclamation-triangle text-3xl mb-3 opacity-60"></i>
                <span class="font-bold">Panel yüklenirken bir hata oluştu.</span>
                <span class="text-[10px] text-gray-400 mt-1">${renderErr.message}</span>
            </div>`;
        }
        // Hata olsa bile sayacı artır (bloklanmasın)
        if (typeof window._onComparisonPanelReady === 'function') window._onComparisonPanelReady();
    }
};




// ================================================================
// YAPAY ZEKA MEDYA ANALİZ MOTORU
// ================================================================
window._comparisonPanelsReady = 0;

window._onComparisonPanelReady = function() {
    window._comparisonPanelsReady = (window._comparisonPanelsReady || 0) + 1;
    if (window._comparisonPanelsReady >= 2) {
        window._comparisonPanelsReady = 0;
        setTimeout(function() { window.runComparisonAIAnalysis(); }, 400);
    }
};

// _origSetup2 sarmalama KALDIRILDI — setupDynamicComparisons artık kendi içinde sıfırlama yapıyor.

window.runComparisonAIAnalysis = async function() {
    var bodyEl = document.getElementById('comparison-ai-analysis-body');
    var barEl  = document.getElementById('comparison-ai-refresh-bar');
    var apiKey = window.OPENAI_API_KEY;
    if (!bodyEl) return;

    var p1 = document.getElementById('compare-content-1');
    var p2 = document.getElementById('compare-content-2');
    var s1 = document.getElementById('compare-source-1');
    var s2 = document.getElementById('compare-source-2');

    var textA = (p1 ? (p1.innerText || p1.textContent || '') : '').trim();
    var textB = (p2 ? (p2.innerText || p2.textContent || '') : '').trim();
    var nameA = (s1 && s1.options && s1.options[s1.selectedIndex]) ? s1.options[s1.selectedIndex].text : 'Kaynak A';
    var nameB = (s2 && s2.options && s2.options[s2.selectedIndex]) ? s2.options[s2.selectedIndex].text : 'Kaynak B';

    if (textA.length < 30 || textB.length < 30) {
        bodyEl.innerHTML = '<div style="padding:24px;text-align:center;color:#9ca3af;font-size:12px;font-style:italic;">Analiz icin her iki panelde yeterli icerik gerekiyor.</div>';
        return;
    }

    bodyEl.innerHTML = '<div style="padding:32px;text-align:center;"><i class="fas fa-robot" style="font-size:24px;color:#6366f1;"></i><p style="margin-top:12px;font-size:12px;font-weight:bold;color:#6366f1;">Medya analizi yapiliyor...</p></div>';
    if (barEl) barEl.classList.add('hidden');

    try {
        var activeLang = window.currentLang || localStorage.getItem('pref_lang') || 'tr';
        var outputLang = activeLang === 'en' ? 'English' : 'Turkish (Türkce)';
        var title = (window._comparisonCurrentArt && window._comparisonCurrentArt.title) ? window._comparisonCurrentArt.title : '';

        var sysMsg = 'Sen tarafsiz bir medya karsilastirma analiz motorusun. Yalnizca verilen metinlere dayanarak analiz yap. Tarafsiz kal. Cikti dili: ' + outputLang;
        var usrMsg = 'Haber konusu: ' + title + '\n\n=== KAYNAK A: ' + nameA + ' ===\n' + textA.slice(0, 700) + '\n\n=== KAYNAK B: ' + nameB + ' ===\n' + textB.slice(0, 700) + '\n\nSADECE bu formatta analiz yap:\n\nBASLIK KARSILASTIRMASI\n' + nameA + ': [dramatik/notr/yonlendirici - tek cumle]\n' + nameB + ': [dramatik/notr/yonlendirici - tek cumle]\n\nODAGIN FARKI\n' + nameA + ': [ne one cikariyor]\n' + nameB + ': [ne one cikariyor]\n\nDIL VE TON ANALIZI\n' + nameA + ': [tek cumle]\n' + nameB + ': [tek cumle]\n\nAKTOR SUNUMU\n' + nameA + ': [sorumlu/magdur/notr]\n' + nameB + ': [sorumlu/magdur/notr]\n\nEKSIK BILGILER\n' + nameA + ': [tek cumle]\n' + nameB + ': [tek cumle]\n\nDIL YOGUNLUGU SKORU\n' + nameA + ' -> duygusal dil: [dusuk/orta/yuksek] | yorum katma: [dusuk/orta/yuksek] | tarafsizlik: [dusuk/orta/yuksek]\n' + nameB + ' -> duygusal dil: [dusuk/orta/yuksek] | yorum katma: [dusuk/orta/yuksek] | tarafsizlik: [dusuk/orta/yuksek]\n\nGENEL OZET\n[2-3 cumle tarafsiz fark ozeti]';

        var analysisText = '';
        if (apiKey) {
            var res = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
                body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'system', content: sysMsg }, { role: 'user', content: usrMsg }], max_tokens: 900, temperature: 0.3 })
            });
            var data = await res.json();
            if (data && data.choices && data.choices[0] && data.choices[0].message) {
                analysisText = data.choices[0].message.content.trim();
            }
        }

        if (!analysisText) throw new Error('OpenAI yanit vermedi. API key eksik veya limit asildi.');
        bodyEl.innerHTML = window._renderAnalysisHTML(analysisText, nameA, nameB);
        if (barEl) barEl.classList.remove('hidden');

    } catch(err) {
        console.error('[ComparisonAI] Hata:', err.message);
        bodyEl.innerHTML = '<div style="padding:24px;text-align:center;color:#f97316;font-size:12px;"><i class="fas fa-exclamation-triangle" style="font-size:20px;opacity:0.6;display:block;margin-bottom:8px;"></i><strong>Analiz uretilemedi.</strong><br><span style="color:#9ca3af;font-size:11px;">' + err.message + '</span></div>';
    }
};

window._renderAnalysisHTML = function(rawText, nameA, nameB) {
    var ICONS = { 'BASLIK': 'fa-heading', 'HEADLINE': 'fa-heading', 'ODAK': 'fa-crosshairs', 'FOCUS': 'fa-crosshairs', 'DIL': 'fa-comment-dots', 'TON': 'fa-comment-dots', 'AKTOR': 'fa-user-tag', 'ACTOR': 'fa-user-tag', 'EKSIK': 'fa-eye-slash', 'MISSING': 'fa-eye-slash', 'YOGUNLUK': 'fa-sliders-h', 'SKOR': 'fa-sliders-h', 'SCORE': 'fa-sliders-h', 'GENEL': 'fa-balance-scale', 'OZET': 'fa-balance-scale', 'SUMMARY': 'fa-balance-scale', 'OVERALL': 'fa-balance-scale', 'GENERAL': 'fa-balance-scale' };
    var lines = rawText.split('\n').map(function(l){ return l.trim(); }).filter(Boolean);
    var html = '<div>';
    var sTitle = '', sIcon = 'fa-circle', sLines = [], isSpecial = false;

    function flush() {
        if (!sTitle) return;
        var bg = isSpecial ? '#eef2ff' : '#fff';
        var tc = isSpecial ? '#4338ca' : '#475569';
        html += '<div style="border-top:1px solid #e5e7eb;padding:14px 20px;background:' + bg + '">';
        html += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;"><i class="fas ' + sIcon + '" style="color:#818cf8;font-size:10px;"></i><span style="font-size:9px;font-weight:900;text-transform:uppercase;letter-spacing:0.1em;color:' + tc + '">' + sTitle + '</span></div>';
        html += '<div style="font-size:12px;line-height:1.65;color:#374151;">';
        for (var i = 0; i < sLines.length; i++) {
            var ln = sLines[i];
            var upLn = ln.toUpperCase();
            var isA = upLn.startsWith(nameA.toUpperCase());
            var isB = upLn.startsWith(nameB.toUpperCase());
            if (isA || isB) {
                var label = isA ? nameA : nameB;
                var clr  = isA ? '#2563eb' : '#dc2626';
                var bg2  = isA ? '#eff6ff' : '#fef2f2';
                var rest = ln.slice(label.length).replace(/^[\s:\u2014\-]+/, '').trim();
                html += '<div style="display:flex;gap:8px;align-items:flex-start;margin-bottom:5px;"><span style="flex-shrink:0;font-size:8px;font-weight:900;text-transform:uppercase;color:' + clr + ';background:' + bg2 + ';border:1px solid ' + clr + '44;padding:1px 5px;border-radius:4px;margin-top:2px;">' + label + '</span><span>' + rest + '</span></div>';
            } else if (ln.indexOf('->') >= 0 || ln.indexOf('|') >= 0) {
                var parts = ln.split(/->|\|/).map(function(p){ return p.trim(); }).filter(Boolean);
                var who = parts[0] || '';
                var isWA = who.toUpperCase().indexOf(nameA.toUpperCase()) >= 0;
                var wClr = isWA ? '#2563eb' : '#dc2626';
                var badges = parts.slice(1).map(function(p) {
                    var v = p.toLowerCase();
                    var bc = (v.indexOf('yuksek') >= 0 || v.indexOf('high') >= 0) ? 'background:#fee2e2;color:#b91c1c' : (v.indexOf('orta') >= 0 || v.indexOf('medium') >= 0) ? 'background:#fef3c7;color:#b45309' : 'background:#dcfce7;color:#15803d';
                    return '<span style="font-size:9px;font-weight:700;padding:2px 7px;border-radius:999px;' + bc + '">' + p + '</span>';
                }).join('');
                html += '<div style="display:flex;flex-wrap:wrap;align-items:center;gap:5px;padding:3px 0;"><span style="font-size:10px;font-weight:700;color:' + wClr + ';min-width:55px;">' + who + '</span>' + badges + '</div>';
            } else if (isSpecial) {
                html += '<p style="font-style:italic;font-weight:500;color:#4338ca;">' + ln + '</p>';
            } else {
                html += '<p style="margin:2px 0;">' + ln + '</p>';
            }
        }
        html += '</div></div>';
        sLines = [];
    }

    for (var j = 0; j < lines.length; j++) {
        var line = lines[j];
        var up = line.toUpperCase().replace(/[^A-Z\s]/g, '');
        var icon = null;
        for (var k in ICONS) { if (up.indexOf(k) >= 0) { icon = ICONS[k]; break; } }
        var isHeader = icon && line.length < 65 && (line === line.toUpperCase() || line.slice(-1) === ':');
        if (isHeader) {
            flush();
            sTitle = line.replace(/:$/, '').trim();
            sIcon  = icon;
            isSpecial = up.indexOf('OZET') >= 0 || up.indexOf('GENEL') >= 0 || up.indexOf('SUMMARY') >= 0 || up.indexOf('OVERALL') >= 0 || up.indexOf('GENERAL') >= 0;
        } else {
            sLines.push(line);
        }
    }
    flush();
    html += '</div>';
    return html;
};

// ================================================================
// ENHANCED COMPARISON UX OVERRIDES
// ================================================================
function getComparisonStateHTML(opts) {
    const icon = escapeHtml((opts && opts.icon) || 'fa-circle-info');
    const title = escapeHtml((opts && opts.title) || '');
    const detail = escapeHtml((opts && opts.detail) || '');
    const tone = escapeHtml((opts && opts.tone) || 'neutral');

    return `
        <div class="comparison-state comparison-state--${tone}">
            <div class="comparison-state__icon"><i class="fas ${icon}"></i></div>
            <div class="comparison-state__content">
                ${title ? `<p class="comparison-state__title">${title}</p>` : ''}
                ${detail ? `<p class="comparison-state__detail">${detail}</p>` : ''}
            </div>
        </div>
    `;
}

function formatComparisonParagraphs(text) {
    const paragraphs = String(text || '')
        .replace(/\r\n/g, '\n')
        .split(/\n+/)
        .map(part => part.trim())
        .filter(Boolean);

    if (paragraphs.length === 0) {
        return `<p>${escapeHtml('Bu kaynak için özet metin bulunamadı.')}</p>`;
    }

    return paragraphs
        .slice(0, 4)
        .map(part => `<p>${escapeHtml(part)}</p>`)
        .join('');
}

function getComparisonMetricTone(value) {
    const normalized = String(value || '').toLowerCase();
    if (normalized.includes('yuksek') || normalized.includes('high')) return 'high';
    if (normalized.includes('orta') || normalized.includes('medium')) return 'mid';
    return 'low';
}

window.setupDynamicComparisons = function(currentArt, allNews) {
    window._comparisonPanelsReady = 0;

    const aiBody = document.getElementById('comparison-ai-analysis-body');
    const aiBar = document.getElementById('comparison-ai-refresh-bar');

    if (aiBody) {
        aiBody.innerHTML = getComparisonStateHTML({
            icon: 'fa-balance-scale',
            title: 'Tarafsız analiz burada görünecek',
            detail: 'İki kaynak seçildiğinde yapay zeka, başlık, vurgu ve ton farklarını geniş rapor alanında özetler.',
            tone: 'neutral'
        });
    }

    if (aiBar) aiBar.classList.add('hidden');

    const mergedNews = [
        ...(Array.isArray(allNews) ? allNews : []),
        ...(Array.isArray(AppState.articles) ? AppState.articles : []),
        ...(Array.isArray(window._globalNewsData) ? window._globalNewsData : [])
    ];

    const seenIds = new Set();
    const dedupedNews = [];
    for (const article of mergedNews) {
        if (!article || !article.id) continue;
        const key = String(article.id);
        if (!seenIds.has(key)) {
            seenIds.add(key);
            dedupedNews.push(article);
        }
    }

    try {
        const select1 = document.getElementById('compare-source-1');
        const select2 = document.getElementById('compare-source-2');
        const content1 = document.getElementById('compare-content-1');
        const content2 = document.getElementById('compare-content-2');

        if (!select1 || !select2 || !content1 || !content2) return;

        content1.dataset.analysisText = '';
        content2.dataset.analysisText = '';

        if (!currentArt || typeof currentArt !== 'object') {
            const emptyMessage = getComparisonStateHTML({
                icon: 'fa-info-circle',
                title: 'Haber verisi bekleniyor',
                detail: 'Karşılaştırma kartları için önce ana haber yüklenmeli.',
                tone: 'neutral'
            });
            content1.innerHTML = emptyMessage;
            content2.innerHTML = emptyMessage;
            return;
        }

        window._comparisonCurrentArt = currentArt;
        window._comparisonAllNews = dedupedNews;

        const currentSourceNorm = formatSourceName(currentArt.source || '');
        const uniqueSourceMap = new Map();

        for (const article of dedupedNews) {
            if (!article || typeof article !== 'object') continue;
            const norm = formatSourceName(article.source || '');
            if (norm && norm !== currentSourceNorm && !uniqueSourceMap.has(norm)) {
                uniqueSourceMap.set(norm, norm);
            }
        }

        const sources = [...uniqueSourceMap.keys()].sort();
        const loadingState = getComparisonStateHTML({
            icon: 'fa-satellite-dish fa-spin',
            title: 'Kaynaklar hazırlanıyor',
            detail: 'Benzer yayınları tarayıp en uygun iki kaynağı seçiyoruz.',
            tone: 'loading'
        });

        content1.innerHTML = loadingState;
        content2.innerHTML = loadingState;

        select1.innerHTML = '';
        select2.innerHTML = '';

        if (!sources.length) {
            select1.innerHTML = '<option value="" disabled selected>Kaynak bulunamadı</option>';
            select2.innerHTML = '<option value="" disabled selected>Kaynak bulunamadı</option>';

            const noSourceState = getComparisonStateHTML({
                icon: 'fa-satellite-dish',
                title: 'Karşılaştırılacak başka kaynak yok',
                detail: 'Bu haber için sistemde eşleşen ikinci bir yayın bulunamadı.',
                tone: 'neutral'
            });

            content1.innerHTML = noSourceState;
            content2.innerHTML = noSourceState;
            return;
        }

        const placeholderA = new Option('— Kaynak A seçin —', '');
        placeholderA.disabled = true;
        placeholderA.selected = true;
        select1.appendChild(placeholderA);

        const placeholderB = new Option('— Kaynak B seçin —', '');
        placeholderB.disabled = true;
        placeholderB.selected = true;
        select2.appendChild(placeholderB);

        sources.forEach(sourceName => {
            select1.appendChild(new Option(sourceName, sourceName));
            select2.appendChild(new Option(sourceName, sourceName));
        });

        const rankedSources = sources
            .map(sourceName => {
                let score = -1;
                try {
                    const match = matchArticleBySource(sourceName, currentArt, dedupedNews);
                    if (match) {
                        score = (match.ai_category === currentArt.ai_category ? 100 : 0) + (match._score || 0);
                    }
                } catch (err) {
                    console.warn('[Comparison] matchArticleBySource error:', err.message);
                }
                return { sourceName, score };
            })
            .sort((a, b) => b.score - a.score);

        const sourceA = (rankedSources[0] && rankedSources[0].sourceName) ? rankedSources[0].sourceName : sources[0];
        const sourceB = (rankedSources[1] && rankedSources[1].sourceName) ? rankedSources[1].sourceName : (sources[1] || sources[0]);

        select1.value = sourceA;
        select2.value = sourceB;

        window.renderComparisonPanel(1, sourceA);
        window.renderComparisonPanel(2, sourceB);
    } catch (err) {
        console.error('[Comparison] setupDynamicComparisons error:', err.message, err);
    }
};

setupDynamicComparisons = window.setupDynamicComparisons;

window.renderComparisonPanel = async function(panelIndex, selectedSourceNorm) {
    const contentEl = document.getElementById(`compare-content-${panelIndex}`);
    if (!contentEl) return;

    contentEl.dataset.analysisText = '';

    const currentArt = window._comparisonCurrentArt;
    const allNews = window._comparisonAllNews;

    contentEl.innerHTML = getComparisonStateHTML({
        icon: 'fa-circle-notch fa-spin',
        title: `${selectedSourceNorm || 'Kaynak'} hazırlanıyor`,
        detail: 'Benzer haber eşleştiriliyor ve okunabilir kart düzeni kuruluyor.',
        tone: 'loading'
    });

    if (!selectedSourceNorm || !currentArt) {
        contentEl.innerHTML = getComparisonStateHTML({
            icon: 'fa-hand-pointer',
            title: 'Kaynak seçimi bekleniyor',
            detail: 'Yukarıdaki açılır listeden bir yayın seçildiğinde bu kart otomatik dolar.',
            tone: 'neutral'
        });
        return;
    }

    try {
        const match = matchArticleBySource(selectedSourceNorm, currentArt, allNews);

        if (!match) {
            contentEl.innerHTML = getComparisonStateHTML({
                icon: 'fa-newspaper',
                title: selectedSourceNorm,
                detail: 'Bu kaynak bu konu için henüz eşleşen bir haber yayınlamamış görünüyor.',
                tone: 'neutral'
            });

            if (typeof window._onComparisonPanelReady === 'function') window._onComparisonPanelReady();
            return;
        }

        const targetLang = (typeof window.currentLang !== 'undefined')
            ? window.currentLang
            : (localStorage.getItem('pref_lang') || 'tr');

        let title = match.title || 'Adsız Haber';
        let desc = match.description || match.ai_summary || 'Bu kaynak konuyu okumak için orijinal habere gidin.';
        let sentiment = match.sentiment || 'Neutral';
        let aiKeycat = match.ai_category || 'Genel';

        if (targetLang && typeof translateTextFree === 'function') {
            const sentimentMap = {
                Positive: targetLang === 'en' ? 'Positive Approach' : 'Pozitif Yaklaşım',
                Negative: targetLang === 'en' ? 'Critical / Negative' : 'Eleştirel / Negatif',
                Urgent: targetLang === 'en' ? 'Urgent & Breaking' : 'Sıcak & Acil',
                Neutral: targetLang === 'en' ? 'Neutral Coverage' : 'Tarafsız İzleme'
            };

            [title, desc] = await Promise.all([
                translateTextFree(title, targetLang),
                translateTextFree(desc, targetLang)
            ]);

            sentiment = sentimentMap[match.sentiment] || sentiment;
        }

        const panelTone = panelIndex === 1 ? 'blue' : 'red';
        const safeSource = escapeHtml(selectedSourceNorm);
        const safeCategory = escapeHtml(aiKeycat);
        const safeSentiment = escapeHtml(sentiment);
        const safeTitle = escapeHtml(title);
        const safeCountry = escapeHtml(match.country || '');
        const articleLink = match.url || match.link || '';
        const safeLink = escapeHtml(articleLink);

        contentEl.dataset.analysisText = [title, desc].filter(Boolean).join('\n\n');

        contentEl.innerHTML = `
            <div class="comparison-source-result animate-fade-in">
                <div class="comparison-source-result__header">
                    <div class="comparison-source-result__meta">
                        <span class="comparison-source-result__chip comparison-source-result__chip--${panelTone}">${safeSource}</span>
                        <span class="comparison-source-result__chip">${safeCategory}</span>
                        ${safeCountry ? `<span class="comparison-source-result__chip"><i class="fas fa-globe"></i>${safeCountry}</span>` : ''}
                    </div>
                    <p class="comparison-source-result__label">Bu kartta önce anlatı akışını, sonra kısa okuma özetini görürsünüz.</p>
                </div>

                <h4 class="comparison-source-result__title">${safeTitle}</h4>

                <div class="comparison-source-result__excerpt custom-scrollbar">
                    ${formatComparisonParagraphs(desc)}
                </div>

                <div class="comparison-source-result__insight">
                    <div class="comparison-source-result__insight-header">
                        <div>
                            <span class="comparison-source-result__insight-kicker"><i class="fas fa-robot"></i> Hızlı okuma özeti</span>
                            <p class="comparison-source-result__insight-copy">Uzun paragrafa dönmeden önce bu iki göstergeye bakarak çerçeveyi yakalayabilirsiniz.</p>
                        </div>
                        <span class="comparison-source-result__pill comparison-source-result__pill--${panelTone}">${safeSentiment}</span>
                    </div>

                    <div class="comparison-source-result__insight-grid">
                        <div class="comparison-source-result__mini-card">
                            <span class="comparison-source-result__mini-label">Yayın yaklaşımı</span>
                            <strong class="comparison-source-result__mini-value">${safeSentiment}</strong>
                        </div>
                        <div class="comparison-source-result__mini-card">
                            <span class="comparison-source-result__mini-label">Ana odak</span>
                            <strong class="comparison-source-result__mini-value">${safeCategory}</strong>
                        </div>
                    </div>

                    ${articleLink ? `
                        <a href="${safeLink}" target="_blank" rel="noopener noreferrer" class="comparison-source-result__link">
                            <i class="fas fa-external-link-alt"></i> Orijinal habere git
                        </a>
                    ` : ''}
                </div>
            </div>
        `;

        if (typeof window._onComparisonPanelReady === 'function') window._onComparisonPanelReady();
    } catch (renderErr) {
        console.error(`[Comparison] renderComparisonPanel(${panelIndex}) error:`, renderErr.message, renderErr);
        contentEl.dataset.analysisText = '';
        contentEl.innerHTML = getComparisonStateHTML({
            icon: 'fa-exclamation-triangle',
            title: 'Panel yüklenemedi',
            detail: renderErr.message || 'Karşılaştırma kartı oluşturulurken beklenmeyen bir sorun oluştu.',
            tone: 'error'
        });

        if (typeof window._onComparisonPanelReady === 'function') window._onComparisonPanelReady();
    }
};

renderComparisonPanel = window.renderComparisonPanel;

window.runComparisonAIAnalysis = async function() {
    var bodyEl = document.getElementById('comparison-ai-analysis-body');
    var barEl = document.getElementById('comparison-ai-refresh-bar');
    var apiKey = window.OPENAI_API_KEY;
    if (!bodyEl) return;

    var p1 = document.getElementById('compare-content-1');
    var p2 = document.getElementById('compare-content-2');
    var s1 = document.getElementById('compare-source-1');
    var s2 = document.getElementById('compare-source-2');

    var textA = (p1 ? (p1.dataset.analysisText || p1.innerText || p1.textContent || '') : '').trim();
    var textB = (p2 ? (p2.dataset.analysisText || p2.innerText || p2.textContent || '') : '').trim();
    var nameA = (s1 && s1.options && s1.options[s1.selectedIndex]) ? s1.options[s1.selectedIndex].text : 'Kaynak A';
    var nameB = (s2 && s2.options && s2.options[s2.selectedIndex]) ? s2.options[s2.selectedIndex].text : 'Kaynak B';

    if (barEl) barEl.classList.add('hidden');

    if (textA.length < 30 || textB.length < 30) {
        bodyEl.innerHTML = getComparisonStateHTML({
            icon: 'fa-align-left',
            title: 'Analiz için daha fazla içerik gerekiyor',
            detail: 'İki panelde de yeterli haber metni olduğunda geniş karşılaştırma raporu oluşturulacak.',
            tone: 'neutral'
        });
        return;
    }

    bodyEl.innerHTML = getComparisonStateHTML({
        icon: 'fa-robot fa-spin',
        title: 'Medya analizi hazırlanıyor',
        detail: 'Başlık dili, ton ve vurgu farkları tek raporda derleniyor.',
        tone: 'loading'
    });

    try {
        var activeLang = window.currentLang || localStorage.getItem('pref_lang') || 'tr';
        var outputLang = activeLang === 'en' ? 'English' : 'Turkish (Türkçe)';
        var title = (window._comparisonCurrentArt && window._comparisonCurrentArt.title) ? window._comparisonCurrentArt.title : '';

        var sysMsg = 'Sen tarafsiz bir medya karsilastirma analiz motorusun. Yalnizca verilen metinlere dayanarak analiz yap. Tarafsiz kal. Cikti dili: ' + outputLang;
        var usrMsg = 'Haber konusu: ' + title + '\n\n=== KAYNAK A: ' + nameA + ' ===\n' + textA.slice(0, 700) + '\n\n=== KAYNAK B: ' + nameB + ' ===\n' + textB.slice(0, 700) + '\n\nSADECE bu formatta analiz yap:\n\nBASLIK KARSILASTIRMASI\n' + nameA + ': [dramatik/notr/yonlendirici - tek cumle]\n' + nameB + ': [dramatik/notr/yonlendirici - tek cumle]\n\nODAGIN FARKI\n' + nameA + ': [ne one cikariyor]\n' + nameB + ': [ne one cikariyor]\n\nDIL VE TON ANALIZI\n' + nameA + ': [tek cumle]\n' + nameB + ': [tek cumle]\n\nAKTOR SUNUMU\n' + nameA + ': [sorumlu/magdur/notr]\n' + nameB + ': [sorumlu/magdur/notr]\n\nEKSIK BILGILER\n' + nameA + ': [tek cumle]\n' + nameB + ': [tek cumle]\n\nDIL YOGUNLUGU SKORU\n' + nameA + ' -> duygusal dil: [dusuk/orta/yuksek] | yorum katma: [dusuk/orta/yuksek] | tarafsizlik: [dusuk/orta/yuksek]\n' + nameB + ' -> duygusal dil: [dusuk/orta/yuksek] | yorum katma: [dusuk/orta/yuksek] | tarafsizlik: [dusuk/orta/yuksek]\n\nGENEL OZET\n[2-3 cumle tarafsiz fark ozeti]';

        var analysisText = '';
        if (apiKey) {
            var res = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: 'Bearer ' + apiKey
                },
                body: JSON.stringify({
                    model: 'gpt-4o-mini',
                    messages: [
                        { role: 'system', content: sysMsg },
                        { role: 'user', content: usrMsg }
                    ],
                    max_tokens: 900,
                    temperature: 0.3
                })
            });

            var data = await res.json();
            if (data && data.choices && data.choices[0] && data.choices[0].message) {
                analysisText = data.choices[0].message.content.trim();
            }
        }

        if (!analysisText) throw new Error('OpenAI yanıt vermedi. API anahtarı eksik olabilir ya da limit dolmuş olabilir.');

        bodyEl.innerHTML = window._renderAnalysisHTML(analysisText, nameA, nameB);
        if (barEl) barEl.classList.remove('hidden');
    } catch (err) {
        console.error('[ComparisonAI] Error:', err.message);
        bodyEl.innerHTML = getComparisonStateHTML({
            icon: 'fa-exclamation-triangle',
            title: 'Analiz üretilemedi',
            detail: err.message || 'Yapay zeka raporu hazırlanırken bir hata oluştu.',
            tone: 'error'
        });
    }
};

runComparisonAIAnalysis = window.runComparisonAIAnalysis;

window._renderAnalysisHTML = function(rawText, nameA, nameB) {
    const icons = {
        BASLIK: 'fa-heading',
        HEADLINE: 'fa-heading',
        ODAK: 'fa-crosshairs',
        FOCUS: 'fa-crosshairs',
        DIL: 'fa-comment-dots',
        TON: 'fa-comment-dots',
        AKTOR: 'fa-user-tag',
        ACTOR: 'fa-user-tag',
        EKSIK: 'fa-eye-slash',
        MISSING: 'fa-eye-slash',
        YOGUNLUK: 'fa-sliders-h',
        SKOR: 'fa-sliders-h',
        SCORE: 'fa-sliders-h',
        GENEL: 'fa-balance-scale',
        OZET: 'fa-balance-scale',
        SUMMARY: 'fa-balance-scale',
        OVERALL: 'fa-balance-scale',
        GENERAL: 'fa-balance-scale'
    };

    const lines = String(rawText || '')
        .split('\n')
        .map(line => line.trim())
        .filter(Boolean);

    const sections = [];
    let current = null;

    function pushSection() {
        if (!current) return;
        if (!current.lines.length && !current.title) return;
        sections.push(current);
    }

    lines.forEach(line => {
        const normalized = line.toUpperCase().replace(/[^A-Z\s]/g, '');
        let icon = null;
        Object.keys(icons).some(key => {
            if (normalized.indexOf(key) >= 0) {
                icon = icons[key];
                return true;
            }
            return false;
        });

        const isHeader = Boolean(icon) && line.length < 65 && (line === line.toUpperCase() || line.endsWith(':'));
        if (isHeader) {
            pushSection();
            current = {
                title: line.replace(/:$/, '').trim(),
                icon,
                lines: [],
                special: normalized.indexOf('OZET') >= 0 || normalized.indexOf('GENEL') >= 0 || normalized.indexOf('SUMMARY') >= 0 || normalized.indexOf('OVERALL') >= 0 || normalized.indexOf('GENERAL') >= 0
            };
            return;
        }

        if (!current) {
            current = {
                title: 'GENEL OZET',
                icon: 'fa-balance-scale',
                lines: [],
                special: true
            };
        }
        current.lines.push(line);
    });

    pushSection();

    const summarySection = sections.find(section => section.special) || sections[0] || {
        title: 'GENEL OZET',
        icon: 'fa-balance-scale',
        lines: ['İki kaynak aynı olayı farklı vurgu merkezleriyle aktarıyor.'],
        special: true
    };

    const eventTitle = (window._comparisonCurrentArt && window._comparisonCurrentArt.title)
        ? window._comparisonCurrentArt.title
        : 'Aynı olayın iki farklı anlatısı';

    const summaryText = summarySection.lines.length
        ? summarySection.lines.join(' ')
        : 'İki kaynak aynı olayı farklı vurgu merkezleriyle aktarıyor.';

    const visibleSections = sections.length
        ? (sections.length > 1 ? sections.filter(section => section !== summarySection) : sections)
        : [summarySection];

    function renderMetricRow(line) {
        const parts = line.split(/->|\|/).map(part => part.trim()).filter(Boolean);
        const who = parts.shift() || 'METRIK';
        const isA = who.toUpperCase().indexOf(String(nameA || '').toUpperCase()) >= 0;
        const sourceClass = isA ? 'comparison-ai-report__source comparison-ai-report__source--a' : 'comparison-ai-report__source comparison-ai-report__source--b';
        const pills = parts.map(part => {
            const tone = getComparisonMetricTone(part);
            return `<span class="comparison-ai-report__metric-pill comparison-ai-report__metric-pill--${tone}">${escapeHtml(part)}</span>`;
        }).join('');

        return `
            <div class="comparison-ai-report__metric-row">
                <span class="${sourceClass}">${escapeHtml(who)}</span>
                <div class="comparison-ai-report__metric-pills">${pills}</div>
            </div>
        `;
    }

    function renderSourceRow(line) {
        const upper = line.toUpperCase();
        const isA = upper.startsWith(String(nameA || '').toUpperCase());
        const label = isA ? nameA : nameB;
        const sourceClass = isA ? 'comparison-ai-report__source comparison-ai-report__source--a' : 'comparison-ai-report__source comparison-ai-report__source--b';
        const rowClass = isA ? 'comparison-ai-report__row comparison-ai-report__row--a' : 'comparison-ai-report__row comparison-ai-report__row--b';
        const stripped = line.slice(label.length).replace(/^[\s:\-—]+/, '').trim();

        return `
            <div class="${rowClass}">
                <span class="${sourceClass}">${escapeHtml(label)}</span>
                <div class="comparison-ai-report__text">${escapeHtml(stripped || line)}</div>
            </div>
        `;
    }

    function renderSection(section) {
        const body = section.lines.map(line => {
            const upper = line.toUpperCase();
            if (upper.startsWith(String(nameA || '').toUpperCase()) || upper.startsWith(String(nameB || '').toUpperCase())) {
                return renderSourceRow(line);
            }
            if (line.indexOf('->') >= 0 || line.indexOf('|') >= 0) {
                return renderMetricRow(line);
            }
            return `<p class="comparison-ai-report__note">${escapeHtml(line)}</p>`;
        }).join('');

        const sectionClass = section.special
            ? 'comparison-ai-report__section comparison-ai-report__section--highlight'
            : 'comparison-ai-report__section';

        return `
            <section class="${sectionClass}">
                <div class="comparison-ai-report__section-head">
                    <span class="comparison-ai-report__section-icon"><i class="fas ${escapeHtml(section.icon || 'fa-circle')}"></i></span>
                    <span class="comparison-ai-report__section-title">${escapeHtml(section.title || 'ANALIZ')}</span>
                </div>
                <div class="comparison-ai-report__section-body">
                    ${body || `<p class="comparison-ai-report__note">${escapeHtml('Bu bölüm için ek veri üretilemedi.')}</p>`}
                </div>
            </section>
        `;
    }

    return `
        <div class="comparison-ai-report">
            <div class="comparison-ai-report__hero">
                <div>
                    <span class="comparison-ai-report__kicker"><i class="fas fa-bolt"></i> Hızlı okuma özeti</span>
                    <h5 class="comparison-ai-report__title">${escapeHtml(eventTitle)}</h5>
                    <p class="comparison-ai-report__summary">${escapeHtml(summaryText)}</p>
                </div>
                <div class="comparison-ai-report__chips">
                    <span class="comparison-ai-report__chip comparison-ai-report__chip--a">${escapeHtml(nameA || 'Kaynak A')}</span>
                    <span class="comparison-ai-report__chip comparison-ai-report__chip--b">${escapeHtml(nameB || 'Kaynak B')}</span>
                </div>
            </div>
            <div class="comparison-ai-report__sections">
                ${visibleSections.map(renderSection).join('')}
            </div>
        </div>
    `;
};
