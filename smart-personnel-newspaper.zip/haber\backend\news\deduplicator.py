# backend/news/deduplicator.py
import re
from typing import List, Set
from .models import GlobalNewsItem

def get_word_set(text: str) -> Set[str]:
    """
    Metni temizleyerek kelime kümesine çevirir.
    """
    if not text:
        return set()
    clean_text = re.sub(r'[^\w\s]', '', text.lower())
    words = clean_text.split()
    return set(words)

def calculate_jaccard_similarity(text1: str, text2: str) -> float:
    """
    İki metin arasındaki Jaccard Benzerlik İndeksi'ni hesaplar.
    """
    set1 = get_word_set(text1)
    set2 = get_word_set(text2)
    
    if not set1 or not set2:
        return 0.0
        
    intersection = set1.intersection(set2)
    union = set1.union(set2)
    
    return len(intersection) / len(union) if len(union) > 0 else 0.0

def filter_duplicates(new_items: List[GlobalNewsItem], similarity_threshold=0.75) -> List[GlobalNewsItem]:
    """
    Kopya haberleri (URL veya Benzer Başlık) eler.
    """
    unique_items = []
    seen_urls = set()
    seen_titles = []
    
    # pub_date DESC sıralı geldiğini varsayıyoruz (aggregator tarafından)
    for item in new_items:
        # 1. URL Kontrolü (O(1))
        if item.link in seen_urls:
            continue
            
        # 2. Başlık Benzerliği Kontrolü (Fuzzy)
        is_duplicate = False
        for seen_title in seen_titles:
            sim = calculate_jaccard_similarity(item.title, seen_title)
            if sim > similarity_threshold:
                is_duplicate = True
                break
        
        if not is_duplicate:
            unique_items.append(item)
            seen_urls.add(item.link)
            seen_titles.append(item.title)
    
    return unique_items
