from __future__ import annotations

import argparse
import json

from comparison_feed_service import comparison_feed_service


def main() -> None:
    parser = argparse.ArgumentParser(description="Build comparison-ready seed pool from real news sources.")
    parser.add_argument("--target", type=int, default=30, help="Target number of comparison-ready feed items.")
    parser.add_argument("--language", type=str, default="en", help="Language hint for external providers.")
    args = parser.parse_args()

    result = comparison_feed_service.rebuild_seed_pool(
        target_count=args.target,
        language=args.language,
        run_type="cli_seed",
        mark_new=False,
    )
    payload = comparison_feed_service.get_feed(limit=args.target)
    print(json.dumps({"seedResult": result, "feedCount": payload.get("count", 0)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
