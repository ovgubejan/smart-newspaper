from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, NewsArticle
from comparison_schema import ensure_comparison_schema

import os
from pathlib import Path
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_SQLITE_PATH = BASE_DIR / "news.db"

def _resolve_database_url() -> str:
    raw_url = os.getenv("DATABASE_URL", "").strip()
    if not raw_url:
        return f"sqlite:///{DEFAULT_SQLITE_PATH.as_posix()}"

    if raw_url.startswith("sqlite:///./"):
        relative_path = raw_url.removeprefix("sqlite:///./")
        return f"sqlite:///{(BASE_DIR / relative_path).as_posix()}"

    if raw_url.startswith("sqlite:///") and not raw_url.startswith("sqlite:////"):
        sqlite_path = raw_url.removeprefix("sqlite:///")
        if sqlite_path and not Path(sqlite_path).is_absolute():
            return f"sqlite:///{(BASE_DIR / sqlite_path).as_posix()}"

    return raw_url


DATABASE_URL = _resolve_database_url()

# PostgreSQL eklendiğinde "postgresql://kullanici:sifre@localhost:5432/haber" yapılacak.
engine = create_engine(DATABASE_URL, echo=False)
Base.metadata.create_all(engine)
ensure_comparison_schema(engine, Base)

SessionLocal = sessionmaker(bind=engine)

class DatabaseORMConnection:
    def __init__(self):
        self.session = SessionLocal()

    def get_all_dtos(self):
        """Deduplicator'ın okuması için veritabanındaki kayıtları DTO listesi gibi döndürür 
           (Aslında veriler O(1) hızınca veritabanından SQL ile url_hash ile check edilmelidir ancak 
            şimdilik uyumluluk açısından belleği veriyoruz)"""
        return self.session.query(NewsArticle).all()

    def add_dto(self, dto):
        """Fetcher veriyi indirdiğinde IO Bound olan ilk kaydı açar. (Status: NLP Bekleniyor)"""
        new_record = NewsArticle(
            url_hash=dto.url_hash,
            title=dto.title,
            url=dto.url,
            source=dto.source,
            content_text=dto.description,
            language=dto.language,
            is_nlp_processed=False # Yeni girenler false olur
        )
        self.session.add(new_record)
        self.session.commit()
        print(f"[{new_record.id}] DB'YE KAYDEDİLDİ (Ham Metin) - NLP Kuyruğuna Gönderiliyor...")
        return new_record.id
        
    def update_article_with_nlp(self, article_id: str, category: str, tags: list, summary: str, sentiment, sentiment_score: float = 0.0):
        """NLP Pipeline sonucu çıktıyı (Summarization, Tags, Sentiment Score) SQL veritabanına yazar."""
        article = self.session.query(NewsArticle).filter_by(id=article_id).first()
        if article:
            article.ai_category = category
            article.ai_tags = tags
            article.ai_summary = summary
            article.ai_sentiment = sentiment
            article.sentiment_score = sentiment_score
            article.is_nlp_processed = True
            
            # Admin Overrides Kontrol (Senaryo Gereği Sadece Okuma Logu)
            if article.is_overridden:
                print(f"[UYARI] Yoneticiler {article.title} kararlarini gecersiz kilmis. Orjinal etiketler: {article.manual_tags}")
                
            self.session.commit()
            print(f"[{article_id}] YAPAY ZEKA GUNCELLEMESİ BASARILI. Duygu: {sentiment.value} (Score: {sentiment_score}), Kategori: {category}")
            return True
        return False
        
    def add_article_entities(self, article_id: str, entities_extracted: list):
        """NER modelinden dönen varlık verisini kaydeder."""
        from models import Entity, ArticleEntity, EntityTypeEnum
        
        for ent_data in entities_extracted:
            name = ent_data.get("name")
            e_type_str = ent_data.get("type", "ORGANIZATION")
            
            try:
                e_type = EntityTypeEnum[e_type_str]
            except KeyError:
                e_type = EntityTypeEnum.ORGANIZATION
                
            entity_record = self.session.query(Entity).filter_by(name=name, entity_type=e_type).first()
            if not entity_record:
                entity_record = Entity(name=name, entity_type=e_type)
                self.session.add(entity_record)
                self.session.flush() 
                
            link_record = self.session.query(ArticleEntity).filter_by(article_id=article_id, entity_id=entity_record.id).first()
            if link_record:
                link_record.count += 1
            else:
                link_record = ArticleEntity(article_id=article_id, entity_id=entity_record.id, count=1)
                self.session.add(link_record)
                
        self.session.commit()
        return len(entities_extracted)
        
    def get_article(self, article_id: str) -> NewsArticle:
        return self.session.query(NewsArticle).filter_by(id=article_id).first()

db = DatabaseORMConnection()
