from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time

opt = Options()
opt.add_argument('--headless')
opt.set_capability('goog:loggingPrefs', {'browser': 'ALL'})
driver = webdriver.Chrome(options=opt)
driver.get('http://127.0.0.1:8000')
time.sleep(3)
for entry in driver.get_log('browser'):
    print(entry['level'], entry['message'])
driver.quit()
