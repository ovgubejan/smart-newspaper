// js/auth.js — GlobalNews Auth & Preferences System

const Auth = {
    STORAGE_KEYS: {
        USERS: 'gn_users',
        SESSION: 'gn_session',
    },

    // Tüm kayıtlı kullanıcıları getir
    getUsers() {
        return JSON.parse(localStorage.getItem(this.STORAGE_KEYS.USERS) || '[]');
    },

    // Aktif oturumu getir
    getSession() {
        return JSON.parse(localStorage.getItem(this.STORAGE_KEYS.SESSION) || 'null');
    },

    // Oturumu güncelle/kaydet
    saveSession(user) {
        localStorage.setItem(this.STORAGE_KEYS.SESSION, JSON.stringify(user));
    },

    // Çıkış yap
    logout() {
        localStorage.removeItem(this.STORAGE_KEYS.SESSION);
        renderHeader();
        // Haber akışını sıfırla
        AppState.userPrefs = [];
        AppState.notify();
    },

    // Kayıt ol
    register({ firstName, lastName, email, password }) {
        const users = this.getUsers();
        if (users.find(u => u.email === email)) {
            return { success: false, error: 'Bu e-posta adresi zaten kayıtlı.' };
        }
        const newUser = {
            id: 'user_' + Date.now(),
            firstName,
            lastName,
            email,
            password, // gerçek uygulamada hash'lenmeli
            selectedTopics: [],
            isFirstLogin: true,
            createdAt: new Date().toISOString()
        };
        users.push(newUser);
        localStorage.setItem(this.STORAGE_KEYS.USERS, JSON.stringify(users));
        this.saveSession(newUser);
        return { success: true, user: newUser };
    },

    // Giriş yap
    login({ email, password }) {
        const users = this.getUsers();
        const user = users.find(u => u.email === email && u.password === password);
        if (!user) {
            return { success: false, error: 'E-posta veya şifre hatalı.' };
        }
        this.saveSession(user);
        return { success: true, user };
    },

    // Kullanıcı bilgilerini güncelle
    updateUser(updatedData) {
        const session = this.getSession();
        if (!session) return;
        const users = this.getUsers();
        const idx = users.findIndex(u => u.id === session.id);
        if (idx !== -1) {
            users[idx] = { ...users[idx], ...updatedData };
            localStorage.setItem(this.STORAGE_KEYS.USERS, JSON.stringify(users));
            this.saveSession(users[idx]);
        }
        return users[idx];
    },

    // Tercihleri kaydet
    savePreferences(topics) {
        const session = this.getSession();
        if (session) {
            const updated = this.updateUser({ selectedTopics: topics, isFirstLogin: false });
            if (!updated) return;
        } else {
            // Misafir (Guest) Kullanıcı için localStorage'a kaydet
            localStorage.setItem('gn_guest_prefs', JSON.stringify(topics));
        }
        
        // Haber akışını güncelle
        AppState.userPrefs = topics;
        AppState.notify();
        
        // Nav'ı tercihlere göre güncelle
        if (typeof updateNavForPreferences === 'function') {
            updateNavForPreferences(topics);
        }
    }
};

// ----------------------------------------------------------------
// UI RENDER
// ----------------------------------------------------------------

function renderHeader() {
    const session = Auth.getSession();
    const authArea = document.getElementById('auth-area');
    if (!authArea) return;

    if (session) {
        const initials = (session.firstName[0] + session.lastName[0]).toUpperCase();
        authArea.innerHTML = `
            <div class="relative" id="profile-dropdown-wrapper">
                <button id="profile-btn" onclick="toggleProfileDropdown()"
                    class="flex items-center space-x-2 px-3 py-1.5 rounded-full bg-darkBlue text-white text-sm font-semibold hover:bg-slate-700 transition dark:bg-brandRed dark:hover:bg-red-700 focus:outline-none">
                    <span class="w-7 h-7 rounded-full bg-brandRed dark:bg-white dark:text-brandRed flex items-center justify-center font-black text-xs">${initials}</span>
                    <span class="hidden sm:inline">${session.firstName}</span>
                    <i class="fas fa-chevron-down text-xs opacity-70"></i>
                </button>
                <div id="profile-dropdown" class="hidden absolute right-0 top-full mt-2 w-52 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-gray-100 dark:border-slate-700 overflow-hidden z-50">
                    <div class="px-4 py-3 border-b border-gray-100 dark:border-slate-700">
                        <p class="text-sm font-bold text-darkBlue dark:text-white">${session.firstName} ${session.lastName}</p>
                        <p class="text-xs text-gray-500 dark:text-gray-400 truncate">${session.email}</p>
                    </div>
                    <button onclick="openProfileModal()" class="w-full text-left px-4 py-3 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-slate-700 transition flex items-center space-x-2">
                        <i class="fas fa-user text-brandRed w-4"></i><span>Profil Bilgileri</span>
                    </button>
                    <button onclick="openPreferencesModal(true)" class="w-full text-left px-4 py-3 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-slate-700 transition flex items-center space-x-2">
                        <i class="fas fa-sliders-h text-brandRed w-4"></i><span>Tercihlerim</span>
                    </button>
                    <div class="border-t border-gray-100 dark:border-slate-700">
                        <button onclick="Auth.logout()" class="w-full text-left px-4 py-3 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition flex items-center space-x-2">
                            <i class="fas fa-sign-out-alt w-4"></i><span>Çıkış Yap</span>
                        </button>
                    </div>
                </div>
            </div>
        `;
    } else {
        authArea.innerHTML = `
            <button onclick="openSignupModal()"
                class="hidden sm:inline-block px-5 py-2 text-sm font-semibold rounded-full bg-darkBlue text-white hover:bg-slate-700 transition dark:bg-brandRed dark:hover:bg-red-700">
                Sign Up
            </button>
            <button onclick="openSigninModal()"
                class="text-sm font-semibold text-darkBlue dark:text-gray-200 hover:text-brandRed dark:hover:text-brandRed transition hidden md:block">
                Sign In
            </button>
        `;
    }
}

window.toggleProfileDropdown = function() {
    const dd = document.getElementById('profile-dropdown');
    if (dd) dd.classList.toggle('hidden');
}

// Dışarı tıklayınca dropdown kapat
document.addEventListener('click', (e) => {
    const wrapper = document.getElementById('profile-dropdown-wrapper');
    if (wrapper && !wrapper.contains(e.target)) {
        const dd = document.getElementById('profile-dropdown');
        if (dd) dd.classList.add('hidden');
    }
});

// ----------------------------------------------------------------
// MODAL AÇMA / KAPAMA
// ----------------------------------------------------------------

function openModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        document.body.style.overflow = '';
    }
}

window.openSignupModal = function() { openModal('signup-modal'); }
window.openSigninModal = function() { openModal('signin-modal'); }

window.openPreferencesModal = function(fromProfile = false) {
    // Mevcut tercihleri işaretle
    const session = Auth.getSession();
    let selected = [];
    if (session && session.selectedTopics) {
        selected = session.selectedTopics;
    } else {
        try { selected = JSON.parse(localStorage.getItem('gn_guest_prefs')) || []; } catch(e) {}
    }
    
    document.querySelectorAll('.pref-card').forEach(card => {
        const topic = card.getAttribute('data-topic');
        if (selected.includes(topic)) {
            card.classList.add('selected');
        } else {
            card.classList.remove('selected');
        }
    });
    const prefTitle = document.getElementById('pref-modal-title');
    if (prefTitle) {
        prefTitle.textContent = fromProfile ? 'Tercihlerimi Güncelle' : 'Hoş Geldin! Konularını Seç';
    }
    const prefSkip = document.getElementById('pref-skip-btn');
    if (prefSkip) prefSkip.style.display = fromProfile ? 'none' : 'block';
    openModal('preferences-modal');
}

window.openProfileModal = function() {
    const dropdown = document.getElementById('profile-dropdown');
    if (dropdown) dropdown.classList.add('hidden');
    const session = Auth.getSession();
    if (!session) return;
    document.getElementById('profile-first-name').value = session.firstName;
    document.getElementById('profile-last-name').value = session.lastName;
    document.getElementById('profile-email').value = session.email;
    openModal('profile-modal');
    // Grafik render (profil modalı açıldığında)
    setTimeout(() => {
        if (typeof renderProfileChart === 'function') renderProfileChart();
    }, 200);
}

// ----------------------------------------------------------------
// ŞIFRE TOGGLE
// ----------------------------------------------------------------

function togglePasswordVisibility(inputId, btnId) {
    const input = document.getElementById(inputId);
    const icon = document.querySelector(`#${btnId} i`);
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// ----------------------------------------------------------------
// FORM HANDLERS
// ----------------------------------------------------------------

function handleSignup(e) {
    e.preventDefault();
    const firstName = document.getElementById('signup-firstname').value.trim();
    const lastName  = document.getElementById('signup-lastname').value.trim();
    const email     = document.getElementById('signup-email').value.trim();
    const password  = document.getElementById('signup-password').value;
    const confirm   = document.getElementById('signup-confirm').value;
    const errorEl   = document.getElementById('signup-error');

    errorEl.textContent = '';
    errorEl.style.display = 'none';

    if (!firstName || !lastName || !email || !password) {
        showFormError(errorEl, 'Lütfen tüm alanları doldurun.');
        return;
    }
    if (password.length < 6) {
        showFormError(errorEl, 'Şifre en az 6 karakter olmalıdır.');
        return;
    }
    if (password !== confirm) {
        showFormError(errorEl, 'Şifreler eşleşmiyor.');
        return;
    }

    const result = Auth.register({ firstName, lastName, email, password });
    if (!result.success) {
        showFormError(errorEl, result.error);
        return;
    }

    closeModal('signup-modal');
    renderHeader();
    // Yeni kullanıcı → Preferences (nav sonra kaydedince güncellenecek)
    openPreferencesModal(false);
}

function handleSignin(e) {
    e.preventDefault();
    const email    = document.getElementById('signin-email').value.trim();
    const password = document.getElementById('signin-password').value;
    const errorEl  = document.getElementById('signin-error');

    errorEl.textContent = '';
    errorEl.style.display = 'none';

    const result = Auth.login({ email, password });
    if (!result.success) {
        showFormError(errorEl, result.error);
        return;
    }

    closeModal('signin-modal');
    renderHeader();

    // Kullanıcı tercihlerini yükle
    const prefs = result.user.selectedTopics || [];
    AppState.userPrefs = prefs;
    AppState.notify();

    // Nav'ı tercihlere göre güncelle
    if (typeof updateNavForPreferences === 'function') {
        updateNavForPreferences(prefs);
    }

    if (result.user.isFirstLogin) {
        openPreferencesModal(false);
    }
}

window.handlePreferencesSave = function() {
    const selected = [];
    document.querySelectorAll('.pref-card.selected').forEach(card => {
        selected.push(card.getAttribute('data-topic'));
    });
    Auth.savePreferences(selected);
    closeModal('preferences-modal');
    renderHeader();
}

function handleProfileSave(e) {
    e.preventDefault();
    const firstName = document.getElementById('profile-first-name').value.trim();
    const lastName  = document.getElementById('profile-last-name').value.trim();
    const email     = document.getElementById('profile-email').value.trim();
    const newPass   = document.getElementById('profile-new-password').value;
    const errorEl   = document.getElementById('profile-error');
    const successEl = document.getElementById('profile-success');

    errorEl.style.display = 'none';
    successEl.style.display = 'none';

    if (!firstName || !lastName || !email) {
        showFormError(errorEl, 'Ad, Soyad ve E-posta zorunludur.');
        return;
    }

    const updateData = { firstName, lastName, email };
    if (newPass) {
        if (newPass.length < 6) {
            showFormError(errorEl, 'Yeni şifre en az 6 karakter olmalıdır.');
            return;
        }
        updateData.password = newPass;
    }

    Auth.updateUser(updateData);
    renderHeader();
    successEl.textContent = 'Bilgileriniz güncellendi.';
    successEl.style.display = 'block';
    setTimeout(() => { successEl.style.display = 'none'; }, 2500);
}

function showFormError(el, msg) {
    el.textContent = msg;
    el.style.display = 'block';
}

// Preference kart toggle
window.togglePrefCard = function(card) {
    card.classList.toggle('selected');
}

// ----------------------------------------------------------------
// INIT
// ----------------------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
    renderHeader();

    // Oturumu kontrol et ve AppState.userPrefs'i besle
    const session = Auth.getSession();
    if (session && session.selectedTopics && session.selectedTopics.length > 0) {
        AppState.userPrefs = session.selectedTopics;
    } else {
        // Misafir Kullanıcı Tercihleri
        try {
            const guestPrefs = JSON.parse(localStorage.getItem('gn_guest_prefs'));
            if (guestPrefs && guestPrefs.length > 0) {
                AppState.userPrefs = guestPrefs;
            }
        } catch (e) {}
    }
});
