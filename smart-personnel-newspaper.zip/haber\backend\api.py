from fastapi import FastAPI, HTTPException, Depends, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
import uuid
import os

# Models and logic
from models import User, UserPreference, UserInteraction, NewsArticle, Category, UserInterest, Bookmark, UserStats, Badge, UserBadge
from news_dto import NewsDTO
from db import SessionLocal
from recommender import calculate_base_importance, adaptive_rank
from nlp_service import nlp_manager
from comparison_service import comparison_service, normalize_article
from comparison_feed_service import comparison_feed_service
import jwt
from vector_db import vector_db_manager
import asyncio
from news.aggregator import aggregator_instance
from news.cache_manager import news_cache
from osint_api import osint_router
from fastapi import WebSocket, WebSocketDisconnect
from ws_manager import ws_manager
JWT_SECRET = os.getenv("JWT_SECRET", "haber_super_secret_key_123")

try:
    from fastapi_cache import FastAPICache
    from fastapi_cache.backends.inmemory import InMemoryBackend
    from fastapi_cache.decorator import cache
except ImportError:
    class FastAPICache:  # type: ignore[override]
        @staticmethod
        def init(*args, **kwargs):
            return None

    class InMemoryBackend:  # type: ignore[override]
        pass

    def cache(*args, **kwargs):  # type: ignore[override]
        def decorator(func):
            return func
        return decorator

app = FastAPI(title="Smart Personnel Newspaper API", version="1.0.0")

app.include_router(osint_router)
FRONTEND_TEST_REPORT = {}

ENABLE_BACKGROUND_JOBS = os.getenv("ENABLE_BACKGROUND_JOBS", "0") == "1"

@app.on_event("startup")
async def startup():
    FastAPICache.init(InMemoryBackend(), prefix="fastapi-cache")
    asyncio.create_task(asyncio.to_thread(comparison_feed_service.ensure_seed_pool, 30, "en"))
    if not ENABLE_BACKGROUND_JOBS:
        print("[STARTUP] Background jobs disabled for local/dev startup.")
        return
    # 8 Saatlik Cron Job ve Gerçek Zamanlı WS Bildirimleri
    from news.scheduler import smart_scheduler
    asyncio.create_task(smart_scheduler.run_8_hour_cron())
    asyncio.create_task(smart_scheduler.simulate_realtime_critical_fetch())
    
    # Clustering (Kümeleme) periyodik arka plan servisi
    from nlp_clustering import clustering_engine
    async def run_clustering_periodically():
        while True:
            await asyncio.sleep(600) # Her 10 dakikada bir (Test amaçlı, normalde saatte bir)
            clustering_engine.run_clustering_cycle()
            
    asyncio.create_task(run_clustering_periodically())

# CORS - Frontend'den gelen isteklere izin ver
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Frontend dosyalarını aynı origin'den servis et
FRONTEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# JS, CSS ve diğer statik assets
app.mount("/js", StaticFiles(directory=os.path.join(FRONTEND_DIR, "js")), name="js")
app.mount("/css", StaticFiles(directory=os.path.join(FRONTEND_DIR, "css")), name="css")
app.mount("/images", StaticFiles(directory=os.path.join(FRONTEND_DIR, "images")), name="images")

@app.middleware("http")
async def disable_frontend_cache(request: Request, call_next):
    response = await call_next(request)
    if request.method == "GET" and (
        request.url.path == "/"
        or request.url.path.startswith("/js/")
        or request.url.path.startswith("/css/")
        or request.url.path.startswith("/images/")
    ):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response

@app.get("/")
def serve_index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

@app.post("/api/v1/frontend-test-report")
def save_frontend_test_report(payload: dict):
    global FRONTEND_TEST_REPORT
    FRONTEND_TEST_REPORT = {
        "received_at": datetime.utcnow().isoformat(),
        **payload
    }
    return {"ok": True}

@app.get("/api/v1/frontend-test-report")
def get_frontend_test_report():
    return FRONTEND_TEST_REPORT

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_current_user(authorization: str = Header(None), db_session = Depends(get_db)):
    """Güvenlik Kilidi: JWT Token Çözümleyici ve Giriş Serisi (Streak) Güncelleyici"""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Yetkilendirme gerekli. RAG sistemini kullanabilmek için JWT Session token gereklidir.")
    
    token = authorization.split(" ")[1]
    
    # --- MOCK AUTH DESTEĞİ (Frontend JS auth bağdaştırıcısı) ---
    if token.startswith("user_") or token == "dummy-token-for-local":
        return {"user_id": token}
    # ---------------------------
    
    import jwt
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        user_id = payload.get("user_id")
        
        # --- STREAK GÜNCELLEMESİ ---
        from datetime import datetime as dt, timedelta
        if user_id:
            today = dt.utcnow().date()
            stats = db_session.query(UserStats).filter_by(user_id=user_id).first()
            if not stats:
                stats = UserStats(user_id=user_id, current_streak=1, longest_streak=1, last_login_date=today)
                db_session.add(stats)
                db_session.commit()
            elif stats.last_login_date != today:
                if stats.last_login_date == today - timedelta(days=1):
                    stats.current_streak += 1
                else:
                    stats.current_streak = 1
                    
                if stats.current_streak > stats.longest_streak:
                    stats.longest_streak = stats.current_streak
                    
                stats.last_login_date = today
                db_session.commit()
        # ---------------------------
        
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Oturum süresi doldu. Lütfen tekrar giriş yapın.")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Geçersiz yetki tokeni. Sahte Token uyarısı.")

# --- Pydantic Request Models ---
class OnboardRequest(BaseModel):
    username: str
    selected_topics: List[str]

class InteractionRequest(BaseModel):
    user_id: str
    article_id: str
    interaction_type: str  # 'like', 'dislike', 'view'
    time_spent_seconds: int = 0
    scroll_depth_percent: int = 0


class ForceAggregateRequest(BaseModel):
    category: Optional[str] = None
    keywords: List[str] = Field(default_factory=list)
    language: str = "en"
    limit: int = 10


class EventExtractRequest(BaseModel):
    article: Dict[str, Any]


class EventMatchRequest(BaseModel):
    articles: List[Dict[str, Any]]


class ComparisonRebuildRequest(BaseModel):
    target_count: int = 30
    language: str = "en"

# --- Endpoints ---

@app.websocket("/api/v1/ws/critical-news")
async def websocket_critical_news(websocket: WebSocket):
    """Anlık Kritik Haber Yayın WebSocket Ucu"""
    await ws_manager.connect(websocket)
    try:
        while True:
            # Client'tan gelen anlık ping'leri dinle
            data = await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        
@app.get("/api/v1/clusters")
def get_clusters(db_session = Depends(get_db)):
    """(FR) Yapay Zeka Karşılaştırmalı Özetlenmiş Konu Kümeleri"""
    from models import TopicCluster, ArticleClusterLink
    # En güncel TopicCluster'lari al
    clusters = db_session.query(TopicCluster).filter_by(is_active=True).order_by(TopicCluster.created_at.desc()).limit(10).all()
    results = []
    for c in clusters:
        links = db_session.query(ArticleClusterLink).filter_by(cluster_id=c.id).all()
        # Haberin Orijinal Listesi
        arts = []
        for l in links:
            art = db_session.query(NewsArticle).filter_by(id=l.article_id).first()
            if art:
                arts.append({"title": art.title, "source": art.source, "url": art.url})
        results.append({
            "id": c.id,
            "topic_name": c.topic_name,
            "ai_summary": c.ai_summary,
            "articles": arts,
            "created_at": c.created_at
        })
    return {"count": len(results), "clusters": results}

@app.get("/api/v1/clusters/article/{article_id}")
def get_article_cluster(article_id: str, db_session = Depends(get_db)):
    """(FR) Bir makalenin bulunduğu Küme'yi ve diğer kaynaklardaki varyantlarını döner"""
    from models import TopicCluster, ArticleClusterLink
    # Makalenin içinde bulunduğu linki bul
    link = db_session.query(ArticleClusterLink).filter_by(article_id=article_id).first()
    if not link:
        return {"cluster": None}
        
    c = db_session.query(TopicCluster).filter_by(id=link.cluster_id).first()
    if not c:
        return {"cluster": None}
        
    # Kümedeki diğer makaleleri bul
    all_links = db_session.query(ArticleClusterLink).filter_by(cluster_id=c.id).all()
    arts = []
    for l in all_links:
        art = db_session.query(NewsArticle).filter_by(id=l.article_id).first()
        if art:
            arts.append({"id": art.id, "title": art.title, "source": art.source, "url": art.url})
            
    return {
        "cluster": {
            "id": c.id,
            "topic_name": c.topic_name,
            "ai_summary": c.ai_summary,
            "articles": arts
        }
    }

@app.get("/api/v1/news")
def get_global_news(
    limit: int = 200,
    category: Optional[str] = None,
    source: Optional[str] = None,
    keyword: Optional[str] = None,
    lang: str = "en",
    force_refresh: bool = False,
):
    """
    100+ global kaynaktan toplanan ve 5 dakikada bir yenilenen 
    en güncel haberleri döndürür.
    """
    if category or source or keyword or force_refresh:
        filtered = comparison_service.filter_news(
            category=category,
            source=source,
            keyword=keyword,
            language=lang,
            limit=limit,
            force_refresh=force_refresh,
        )
        return {
            "count": len(filtered),
            "last_updated": datetime.utcnow().isoformat(),
            "news": filtered
        }

    cache_items = news_cache.get_news(limit=limit)
    if not cache_items:
        filtered = comparison_service.filter_news(
            category=None,
            source=None,
            keyword=None,
            language=lang,
            limit=limit,
            force_refresh=True,
        )
        return {
            "count": len(filtered),
            "last_updated": datetime.utcnow().isoformat(),
            "news": filtered
        }

    articles = [normalize_article(item, provider="news_cache", source_type="cache") for item in cache_items]
    return {
        "count": len(articles),
        "last_updated": news_cache.last_updated,
        "news": articles
    }


@app.get("/api/v1/news/search")
def search_news(q: str, limit: int = 40, lang: str = "en"):
    news = comparison_service.filter_news(keyword=q, language=lang, limit=limit, force_refresh=True)
    return {
        "count": len(news),
        "query": q,
        "news": news,
    }


@app.get("/api/v1/news/by-source")
def get_news_by_source(source: str, limit: int = 40, lang: str = "en"):
    news = comparison_service.filter_news(source=source, language=lang, limit=limit)
    return {
        "count": len(news),
        "source": source,
        "news": news,
    }


@app.get("/api/v1/news/by-category")
def get_news_by_category(category: str, limit: int = 40, lang: str = "en", force_refresh: bool = False):
    news = comparison_service.filter_news(category=category, language=lang, limit=limit, force_refresh=force_refresh)
    return {
        "count": len(news),
        "category": category,
        "news": news,
    }


@app.get("/api/v1/comparison-feed")
def get_comparison_feed(
    category: Optional[str] = None,
    limit: int = 30,
    lang: str = "en",
    keyword: Optional[str] = None,
    force_refresh: bool = False,
):
    if force_refresh:
        comparison_feed_service.ensure_seed_pool(target_count=max(30, limit), language=lang)
    payload = comparison_feed_service.get_feed(limit=limit)
    if payload.get("count", 0) == 0:
        comparison_feed_service.ensure_seed_pool(target_count=max(30, limit), language=lang)
        payload = comparison_feed_service.get_feed(limit=limit)
    return payload


@app.post("/api/v1/force-aggregate")
def force_aggregate(req: ForceAggregateRequest):
    scan_result = comparison_feed_service.scan_latest(limit=max(10, req.limit), language=req.language)
    payload = comparison_feed_service.get_feed(limit=max(30, req.limit))
    payload["scanResult"] = scan_result
    return payload


@app.post("/api/v1/events/extract")
def extract_event(req: EventExtractRequest):
    return comparison_service.extract_event(req.article)


@app.post("/api/v1/events/match")
def match_events(req: EventMatchRequest):
    return comparison_service.match_events(req.articles)


@app.get("/api/v1/events/{event_id}/articles")
def get_event_articles(event_id: str):
    return comparison_feed_service.get_event_articles(event_id)


@app.get("/api/v1/events/{event_id}/comparison")
def get_event_comparison(event_id: str):
    return comparison_feed_service.get_event_comparison(event_id)


@app.post("/api/v1/comparison/rebuild")
def rebuild_comparison_feed(req: ComparisonRebuildRequest):
    result = comparison_feed_service.rebuild_seed_pool(
        target_count=req.target_count,
        language=req.language,
        run_type="manual_rebuild",
        mark_new=False,
        reset_existing=True,
    )
    payload = comparison_feed_service.get_feed(limit=req.target_count)
    payload["rebuildResult"] = result
    return payload


@app.post("/api/v1/comparison/scan-latest")
def scan_latest_comparisons(req: ForceAggregateRequest):
    scan_result = comparison_feed_service.scan_latest(limit=max(10, req.limit), language=req.language)
    payload = comparison_feed_service.get_feed(limit=max(30, req.limit))
    payload["scanResult"] = scan_result
    return payload


@app.post("/api/v1/comparison/ingest")
def ingest_comparisons(req: ForceAggregateRequest):
    scan_result = comparison_feed_service.scan_latest(limit=max(10, req.limit), language=req.language)
    payload = comparison_feed_service.get_feed(limit=max(30, req.limit))
    payload["ingestResult"] = scan_result
    return payload


class ChatRequest(BaseModel):
    article_id: str
    user_question: str

@app.post("/api/v1/chat/article")
def chat_with_article(req: ChatRequest):
    """
    Haberle sohbet - RAG tabanlı AI Chat.
    ChromaDB'den ilgili içerikleri çekip kullanıcıya cevap verir.
    """
    try:
        # 1. ChromaDB'de ilgili haberleri ara
        results = vector_db_manager.query(req.user_question, n_results=3)
        
        if results and results.get("documents") and results["documents"][0]:
            context_docs = results["documents"][0]
            context = "\n\n".join(context_docs[:3])
        else:
            context = "Bu konuda yeterli bilgi bulunamadı."
        
        # 2. Basit cevap oluştur (OpenAI olmadan, context-based)
        answer = f"📰 İlgili haberlere dayanarak:\n\n{context[:500]}\n\n💡 Bu bilgi, 100+ küresel kaynaktan toplanan haberlerden derlenmiştir."
        
        return {"answer": answer, "sources": len(context_docs) if results and results.get("documents") else 0}
    except Exception as e:
        return {"answer": f"Şu an yanıt oluşturulamıyor: {str(e)}", "sources": 0}

class OnboardRequestV2(BaseModel):
    username: str
    category_ids: List[int]

@app.post("/api/v1/auth/onboarding")
def user_onboarding_jwt(req: OnboardRequestV2, db_session = Depends(get_db)):
    """(Cold Start Çözümü) - Yeni Kullanıcı İlgi Alanı Kaydı ve JWT"""
    # 1. Kullanıcıyı bul veya yarat
    user = db_session.query(User).filter_by(username=req.username).first()
    if not user:
        user = User(id=str(uuid.uuid4()), username=req.username)
        db_session.add(user)
        db_session.commit()
    
    # 2. Eski ilgi alanlarını silip yenilerini ekle (Many-to-Many updates)
    db_session.query(UserInterest).filter_by(user_id=user.id).delete()
    
    categories = db_session.query(Category).filter(Category.id.in_(req.category_ids)).all()
    cat_names = []
    for cat in categories:
        cat_names.append(cat.name)
        db_session.add(UserInterest(id=str(uuid.uuid4()), user_id=user.id, category_id=cat.id))
        
    db_session.commit()
    
    # 3. Son derece hafif JWT Token'ı üret
    import time
    payload = {
        "user_id": user.id,
        "username": user.username,
        "categories": cat_names,  # Sadece isimler (Hafif text payload)
        "exp": int(time.time()) + (7 * 24 * 3600) # 7 Günlük geçerlilik
    }
    
    token = jwt.encode(payload, JWT_SECRET, algorithm="HS256")
    
    return {
        "message": "User onboarded successfully", 
        "token": token,
        "user": {"id": user.id, "username": user.username, "interests": cat_names}
    }

class LikeToggleRequest(BaseModel):
    article_id: str

@app.post("/api/v1/interactions/like")
def toggle_like(req: LikeToggleRequest, current_user: dict = Depends(get_current_user), db_session = Depends(get_db)):
    """Beğeni Ekle veya Geri Al (Toggle). Kullanıcı girişi ZORUNLUDUR."""
    user_id = current_user.get("user_id")
    
    existing = db_session.query(UserInteraction).filter_by(
        user_id=user_id,
        article_id=req.article_id,
        interaction_type='like'
    ).first()
    
    if existing:
        db_session.delete(existing)
        db_session.commit()
        return {"status": "unliked", "message": "Beğeni geri alındı."}
    else:
        new_like = UserInteraction(
            id=str(uuid.uuid4()),
            user_id=user_id,
            article_id=req.article_id,
            interaction_type='like',
            timestamp=datetime.utcnow()
        )
        db_session.add(new_like)
        db_session.commit()
        return {"status": "liked", "message": "Haber beğenildi."}

@app.post("/api/v1/interactions")
def save_interaction(req: InteractionRequest, db_session = Depends(get_db)):
    """Etkileşim (Geri Bildirim) Takibi"""
    log = UserInteraction(
        id=str(uuid.uuid4()),
        user_id=req.user_id,
        article_id=req.article_id,
        interaction_type=req.interaction_type,
        time_spent_seconds=req.time_spent_seconds,
        scroll_depth_percent=req.scroll_depth_percent,
        timestamp=datetime.utcnow()
    )
    db_session.add(log)
    
    # Okunan haber istatistiğini artır
    if req.interaction_type in ['view', 'READ_TIME']:
        stats = db_session.query(UserStats).filter_by(user_id=req.user_id).first()
        if stats:
            stats.total_articles_read += 1
            
            # --- BAŞARI (BADGE) TETİKLEYİCİSİ ---
            badge_name_to_award = None
            if stats.total_articles_read == 10:
                badge_name_to_award = "Haber Canavarı"
            elif stats.total_articles_read == 50:
                badge_name_to_award = "Bilgi Kurdu"
                
            if badge_name_to_award:
                # Rozet sistemde var mı kontrol et, yoksa yarat
                badge = db_session.query(Badge).filter_by(name=badge_name_to_award).first()
                if not badge:
                    badge = Badge(name=badge_name_to_award, description=f"Sistem üzerinden {stats.total_articles_read} haber okunarak kazanıldı.")
                    db_session.add(badge)
                    db_session.flush() # ID'yi al
                
                # Kullanıcıda zaten var mı?
                existing_ub = db_session.query(UserBadge).filter_by(user_id=req.user_id, badge_id=badge.id).first()
                if not existing_ub:
                    new_ub = UserBadge(id=str(uuid.uuid4()), user_id=req.user_id, badge_id=badge.id)
                    db_session.add(new_ub)
            # ------------------------------------
            
    db_session.commit()
    return {"message": "Interaction saved successfully."}

@app.get("/api/v1/recommend/{user_id}")
@cache(expire=900)
def get_recommendations(user_id: str, category: str = "Technology", db_session = Depends(get_db)):
    """(FR-4.1) & (NFR-3) Adaptive Recommendation Engine — Gerçek NewsAPI + Adaptif Sıralama"""
    try:
        # 1. Kullanıcı tercihleri (Explicit Bias) - 3NF Tablosundan Çek
        user_interests = db_session.query(UserInterest).filter_by(user_id=user_id).all()
        baseline_topics = []
        
        if user_interests:
            for ui in user_interests:
                cat = db_session.query(Category).filter_by(id=ui.category_id).first()
                if cat:
                    baseline_topics.append(cat.name)
        else:
            # Geriye dönük uyumluluk (Legacy)
            pref = db_session.query(UserPreference).filter_by(user_id=user_id).first()
            baseline_topics = pref.selected_topics if pref else ["Technology"]
            
        # 2. Telemetri Logları (Implicit Bias & Likes)
        logs = db_session.query(UserInteraction).filter_by(user_id=user_id).order_by(UserInteraction.timestamp.desc()).all()
        
        # Likes tablosunu ayrıştır ve kategorileri önceliklendir (Recommendation Engine Enhacement)
        user_likes = [l for l in logs if l.interaction_type == 'like']
        if user_likes:
            for like in user_likes:
                liked_art = db_session.query(NewsArticle).filter_by(id=like.article_id).first()
                if liked_art and liked_art.ai_category:
                    baseline_topics.append(liked_art.ai_category)
        
        # Benzersiz baseline topic'ler
        baseline_topics = list(set(baseline_topics))
        
        # --- COLD START KONTROLÜ ---
        if not logs or len(logs) == 0:
            print(f"[COLD-START] Kullanici {user_id} icin gecmis yok. Hizli baslangic yapiliyor...")
            # Sadece seçili ilgileri değil, DB'den genel bir karışım getir ki sekmeler boş kalmasın (Fast Load)
            cold_articles = db_session.query(NewsArticle).order_by(NewsArticle.published_at.desc()).all()
            
            if len(cold_articles) > 0:
                final_ranking = []
                for art in cold_articles:
                    sentiment_val = art.ai_sentiment.value if hasattr(art.ai_sentiment, 'value') else "Neutral"
                    # UserPrefs'e dahil olan kategorilere bir tık puan avantajı sağla
                    base_score = calculate_base_importance(art.source, len(art.ai_tags or []), sentiment_val)
                    if art.ai_category in baseline_topics:
                        base_score *= 1.5
                        
                    final_ranking.append({
                        "id": art.id, "title": art.title, "source": art.source, "url": art.url,
                        "ai_category": art.ai_category or "General", "ai_summary": art.ai_summary or "",
                        "base_importance": base_score, "sentiment": sentiment_val, "is_event": False,
                        "description": art.content_text or "", "is_cold_start": True
                    })
                final_ranking.sort(key=lambda x: x["base_importance"], reverse=True)
                return {"user": user_id, "recommendations": final_ranking, "is_cold_start": True}
        # --- COLD START BİTİŞ ---

        # 2.5 GERİ BİLDİRİM DÖNGÜSÜ & CHROMADB DESTEĞİ
        interaction_dicts = []
        boost_ids = set()
        penalize_ids = set()
        
        # Sadece en güncel (latest) etkileşimleri sınırlı olarak işleyelim
        positive_logs = [l for l in logs if l.interaction_type == 'like' or l.time_spent_seconds > 30][:3]
        negative_logs = [l for l in logs if l.interaction_type == 'dislike'][:3]
        
        for pos in positive_logs:
            res = vector_db_manager.find_similar_articles(pos.article_id, top_k=3)
            if "similar_ids" in res:
                boost_ids.update(res["similar_ids"])
                
        for neg in negative_logs:
            res = vector_db_manager.find_similar_articles(neg.article_id, top_k=3)
            if "similar_ids" in res:
                penalize_ids.update(res["similar_ids"])

        for l in logs:
            linked_art = db_session.query(NewsArticle).filter_by(id=l.article_id).first()
            interaction_dicts.append({
                "timestamp": l.timestamp,
                "interaction_type": l.interaction_type,
                "reading_duration": l.time_spent_seconds,
                "article_category": linked_art.ai_category if linked_art else "General"
            })
            
        # 3. NewsAPI'den GERÇEK Haberler Çek + DB Makaleleri Birleştir
        from newsapi_client import fetch_top_headlines
        from rss_client import fetch_trt_news, fetch_all_hurriyet_news, TRT_URL_MAP
        from concurrent.futures import ThreadPoolExecutor

        all_dicts = []
        
        # Parallel Fetching (International + National News)
        categories = ["Technology", "Politics", "Economy", "Sports", "Health"]
        
        def fetch_api_task(cat):
            try:
                live_articles = fetch_top_headlines(cat, page_size=5)
                results = []
                for i, dto in enumerate(live_articles):
                    article_hash = (dto.url_hash[:8] if dto.url_hash else str(uuid.uuid4())[:8])
                    summary_input = (dto.description or "") + " " + (dto.title or "")
                    
                    # AI ile kategoriyi doğrula (Hava durumu vb. hataları önlemek için)
                    ai_cat = nlp_manager.classify_text(summary_input)
                    
                    results.append({
                        "id": f"live_{cat}_{i}_{article_hash}",
                        "title": dto.title,
                        "url": dto.url,
                        "source": dto.source or "NewsAPI",
                        "ai_category": ai_cat,
                        "ai_summary": nlp_manager.summarize_bullets(summary_input),
                        "base_importance": calculate_base_importance(dto.source or "Default", 3, "Neutral"),
                        "sentiment": "Neutral",
                        "is_event": False,
                        "image_url": dto.image_url,
                        "description": dto.description or ""
                    })
                return results
            except Exception as e_cat:
                print(f"[NEWS_API] {cat} kategorisinde hata: {e_cat}")
                return []

        def fetch_rss_task():
            """TRT + Hürriyet Haberlerini paralel çek ve birleştir"""
            try:
                trt_articles = fetch_trt_news()
                hurriyet_articles = fetch_all_hurriyet_news()
                
                results = []
                # TRT İşleme
                for i, dto in enumerate(trt_articles):
                    summary_input = (dto.description or "") + " " + (dto.title or "")
                    ai_cat = nlp_manager.classify_text(summary_input)
                    article_hash = (dto.url_hash[:8] if dto.url_hash else str(uuid.uuid4())[:12])
                    results.append({
                        "id": f"trt_news_{i}_{article_hash}",
                        "title": dto.title,
                        "url": dto.url,
                        "source": "TRT Haber",
                        "ai_category": ai_cat,
                        "ai_summary": nlp_manager.summarize_bullets(summary_input),
                        "base_importance": 0.8, "sentiment": "Neutral", "is_event": False,
                        "image_url": dto.image_url,
                        "description": dto.description or ""
                    })
                
                # Hürriyet İşleme
                for i, dto in enumerate(hurriyet_articles):
                    summary_input = (dto.description or "") + " " + (dto.title or "")
                    ai_cat = nlp_manager.classify_text(summary_input)
                    article_hash = (dto.url_hash[:8] if dto.url_hash else str(uuid.uuid4())[:12])
                    results.append({
                        "id": f"hurri_news_{i}_{article_hash}",
                        "title": dto.title,
                        "url": dto.url,
                        "source": "Hürriyet",
                        "ai_category": ai_cat,
                        "ai_summary": nlp_manager.summarize_bullets(summary_input),
                        "base_importance": 0.75, "sentiment": "Neutral", "is_event": False,
                        "image_url": dto.image_url,
                        "description": dto.description or ""
                    })
                return results
            except Exception as e_rss:
                print(f"[RSS_TASK] RSS cekilirken hata: {e_rss}")
                return []

        # Run parallel threads (5 NewsAPI + 1 RSS Aggregator)
        with ThreadPoolExecutor(max_workers=10) as executor:
            # NewsAPI tasks
            api_futures = [executor.submit(fetch_api_task, cat) for cat in categories]
            # RSS task (TRT & Hürriyet)
            rss_future = executor.submit(fetch_rss_task)
            
            # Collect results
            for future in api_futures:
                all_dicts.extend(future.result())
            all_dicts.extend(rss_future.result())

        # DB'deki mevcut makaleler (Hala hızlı, yerelde)
        db_articles = db_session.query(NewsArticle).all()
        for art in db_articles:
            sentiment_val = art.ai_sentiment.value if art.ai_sentiment else "Neutral"
            base_score = calculate_base_importance(art.source, len(art.ai_tags or []), sentiment_val)
            
            # Geri Bildirim Vektör Ağını (Feedback Loop) Uygula
            if art.id in boost_ids:
                base_score *= 1.5
            if art.id in penalize_ids:
                base_score *= 0.2
                
            all_dicts.append({
                "id": art.id, "title": art.title, "source": art.source,
                "url": art.url,
                "ai_category": art.ai_category or "General",
                "ai_summary": art.ai_summary or "",
                "base_importance": base_score, "sentiment": sentiment_val, "is_event": False,
                "description": art.content_text or ""
            })

        # 4. Kurumsal Etkinlikleri ekle (Modül 6)
        from models import InstitutionalEvent
        now = datetime.utcnow()
        events = db_session.query(InstitutionalEvent).filter(InstitutionalEvent.start_time >= now).all()
        for evt in events:
            all_dicts.append({
                "id": evt.id, "title": f"[ETKİNLİK] {evt.title}",
                "url": "",
                "source": "Corporate Calendar", "ai_category": "Dashboard",
                "base_importance": 999.0 if evt.is_critical else 100.0,
                "sentiment": "Urgent" if evt.is_critical else "Neutral",
                "ai_summary": f"- Tarih: {evt.start_time}\n- {evt.description or 'Detay yok'}",
                "is_event": True,
                "description": evt.description or ""
            })
        
        # 5. Adaptif Sıralama (Decay Function)
        try:
            final_ranking = adaptive_rank(baseline_topics, interaction_dicts, all_dicts)
        except Exception as rank_err:
            print(f"[RANK] Fallback: {rank_err}")
            final_ranking = sorted(all_dicts, key=lambda x: x.get("base_importance", 0), reverse=True)
        
        return {"user": user_id, "recommendations": final_ranking}
    
    except Exception as e:
        import traceback
        err_msg = f"API Error: {str(e)}"
        print(f"[CRITICAL] {err_msg}")
        traceback.print_exc()
        return {"user": user_id, "error": err_msg, "recommendations": [
            {"id": "fallback1", "title": f"Service Error: {str(e)}", "ai_category": "System",
             "source": "System", "ai_summary": "- Lütfen backend loglarını kontrol edin.\n- Hata detayı yukarıda.", "sentiment": "Neutral", "is_event": False},
        ]}

# --- Benzer Haberler (Vector Search) Endpoint'i ---
@app.get("/api/v1/recommend/similar/{article_id}")
@cache(expire=900)
def get_similar_articles(article_id: str, db_session = Depends(get_db)):
    """ChromaDB üzerinden kosinüs mesafe metriğiyle benzer haberleri döndürür."""
    from vector_db import vector_db_manager
    results = vector_db_manager.find_similar_articles(article_id, top_k=5)
    
    if "error" in results:
        return {"error": results["error"], "recommendations": []}
        
    similar_ids = results.get("similar_ids", [])
    scores = results.get("scores", [])
    
    if not similar_ids:
        return {"recommendations": []}
        
    recommendations = []
    for i, sim_id in enumerate(similar_ids):
        art = db_session.query(NewsArticle).filter_by(id=sim_id).first()
        if art:
            recommendations.append({
                "id": art.id,
                "title": art.title,
                "source": art.source,
                "ai_category": art.ai_category or "General",
                "similarity_score": round(scores[i] * 100, 1) # Örn: 89.4%
            })
            
    return {"article_id": article_id, "recommendations": recommendations}

# --- Haber İçerik Çekme & OpenAI Özet Endpoint ---

class ArticleContentRequest(BaseModel):
    url: str
    title: Optional[str] = ""

@app.post("/api/v1/article/content")
def get_article_content(req: ArticleContentRequest):
    """
    Kaynak siteden haberin tam metnini çeker,
    OpenAI ChatGPT ile özetler ve her ikisini döndürür.
    """
    from scraper import scrape_article

    if not req.url or not req.url.startswith("http"):
        raise HTTPException(400, "Geçerli bir URL gerekli")

    # 1. İçeriği çek
    result = scrape_article(req.url)

    if result["error"] and not result["content"]:
        return {
            "content": "",
            "summary": "",
            "images": [],
            "error": result["error"]
        }

    content = result["content"]

    # 2. OpenAI/ChatGPT ile özetle
    summary_text = ""
    try:
        text_for_summary = content if len(content) > 100 else (req.title + ". " + content)
        summary_text = nlp_manager.summarize_bullets(text_for_summary)
    except Exception as e:
        print(f"[ARTICLE_CONTENT] OpenAI ozet hatasi: {e}")
        summary_text = ""

    return {
        "content": content,
        "summary": summary_text,
        "images": result.get("images", []),
        "error": None
    }


@app.post("/api/v1/translate")
def translate_content(req: dict):
    """Metni hedef dile çevirir."""
    text = req.get("text")
    target_lang = req.get("target_lang", "en")
    
    if not text:
        return {"text": ""}
        
    translated = nlp_manager.translate_text(text, target_lang)
    return {"text": translated}

# --- RAG: HABERLE SOHBET VE STREAK TAKİBİ ---

class GlobalChatRequest(BaseModel):
    user_question: str
    context_data: str

@app.post("/api/v1/chat/global")
def chat_with_global(req: GlobalChatRequest):
    """Genel asistan ile sohbet (Float Bot)."""
    try:
        answer = nlp_manager.chat_global(req.context_data, req.user_question)
        return {"answer": answer}
    except Exception as e:
        return {"answer": f"Şu an yanıt oluşturulamıyor: {str(e)}"}

class ArticleChatRequest(BaseModel):
    article_id: str
    user_question: str

@app.post("/api/v1/chat/article")
def chat_with_article_rag(req: ArticleChatRequest, current_user: dict = Depends(get_current_user), db_session = Depends(get_db)):
    """
    Kullanıcının Okuduğu Haberle RAG üzerinden Sohbet Etmesi
    """
    # 1. DB'den Haberi Bul (Bağlam / Context)
    article = db_session.query(NewsArticle).filter_by(id=req.article_id).first()
    if not article:
        raise HTTPException(status_code=404, detail="Veritabanında böyle bir haber bulunamadı.")
        
    context_text = article.content_text or article.ai_summary or article.description
    if not context_text:
         return {"answer": "Bu haber içeriği metin analizine uygun değil (boş)."}
         
    # 2. LLM RAG İsteği (NLP Modülü ile)
    answer = nlp_manager.chat_with_article(context_text, req.user_question)
    
    return {
        "user_id": current_user.get("user_id"),
        "article_id": req.article_id,
        "question": req.user_question,
        "answer": answer
    }

# --- DAHA SONRA OKU (BOOKMARKS) ---
class BookmarkToggleRequest(BaseModel):
    article_id: str

@app.post("/api/v1/bookmarks/toggle")
def toggle_bookmark(req: BookmarkToggleRequest, current_user: dict = Depends(get_current_user), db_session = Depends(get_db)):
    """Makaleyi Daha Sonra Oku listesine ekler veya çıkarır."""
    user_id = current_user.get("user_id")
    
    article = db_session.query(NewsArticle).filter_by(id=req.article_id).first()
    if not article:
        raise HTTPException(status_code=404, detail="Makale bulunamadı.")
        
    existing = db_session.query(Bookmark).filter_by(user_id=user_id, article_id=req.article_id).first()
    if existing:
        db_session.delete(existing)
        db_session.commit()
        return {"message": "Makale kaydedilenlerden çıkarıldı.", "status": "removed"}
    else:
        new_bookmark = Bookmark(id=str(uuid.uuid4()), user_id=user_id, article_id=req.article_id)
        db_session.add(new_bookmark)
        db_session.commit()
        return {"message": "Makale başarıyla kaydedildi.", "status": "added"}

@app.get("/api/v1/bookmarks")
def get_bookmarks(current_user: dict = Depends(get_current_user), db_session = Depends(get_db)):
    """Kullanıcının kaydettiği haberleri listeler."""
    user_id = current_user.get("user_id")
    
    bookmarks = db_session.query(Bookmark).filter_by(user_id=user_id).order_by(Bookmark.created_at.desc()).all()
    results = []
    for b in bookmarks:
        art = db_session.query(NewsArticle).filter_by(id=b.article_id).first()
        if art:
            results.append({
                "id": art.id,
                "title": art.title,
                "source": art.source,
                "url": art.url,
                "bookmarked_at": b.created_at
            })
    return {"user_id": user_id, "bookmarks": results}

# --- KULLANICI İSTATİSTİKLERİ ---
@app.get("/api/v1/user/stats")
def get_user_stats(current_user: dict = Depends(get_current_user), db_session = Depends(get_db)):
    """Kullanıcının okuma ve streak (giriş serisi) istatistiklerini döndürür"""
    user_id = current_user.get("user_id")
    stats = db_session.query(UserStats).filter_by(user_id=user_id).first()
    
    if not stats:
        return {
            "total_articles_read": 0,
            "current_streak": 0,
            "longest_streak": 0,
            "last_login_date": None,
            "badges": []
        }
        
    user_badges = db_session.query(UserBadge).filter_by(user_id=user_id).all()
    badges = []
    for ub in user_badges:
        bdg = db_session.query(Badge).filter_by(id=ub.badge_id).first()
        if bdg:
            badges.append({
                "name": bdg.name,
                "description": bdg.description,
                "awarded_at": ub.awarded_at
            })
            
    return {
        "total_articles_read": stats.total_articles_read,
        "current_streak": stats.current_streak,
        "longest_streak": stats.longest_streak,
        "last_login_date": stats.last_login_date,
        "badges": badges
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
