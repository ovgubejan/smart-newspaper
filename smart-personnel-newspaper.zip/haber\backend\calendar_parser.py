import urllib.request
from icalendar import Calendar
from datetime import datetime, timezone
import uuid
import re

# ORM and DB
from db import SessionLocal
from models import InstitutionalEvent, EventCategoryEnum

# Test amacı ile Mock ICS Server'ı simüle ediyoruz
MOCK_ICS_DATA = b"""BEGIN:VCALENDAR
VERSION:2.0
BEGIN:VEVENT
UID:evt-1001@mock-university
SUMMARY:Final Sinavlari Basliyor
DESCRIPTION:Tum bolumler icin donem sonu final sinavlari.
DTSTART;VALUE=DATE:20260405
DTEND;VALUE=DATE:20260415
END:VEVENT
BEGIN:VEVENT
UID:evt-1002@mock-university
SUMMARY:ACIL: CEO Aylik Kurumsal Toplanti
DESCRIPTION:Tum personelin katilimi zorunludur.
DTSTART:20260402T100000Z
DTEND:20260402T120000Z
END:VEVENT
END:VCALENDAR
"""

class CalendarParser:
    def __init__(self, use_mock=True):
        self.use_mock = use_mock

    def _determine_category(self, title: str, description: str) -> EventCategoryEnum:
        text = f"{title} {description}".lower()
        if re.search(r"exam|sinav|vize|final", text):
            return EventCategoryEnum.EXAM
        if re.search(r"meeting|toplanti|gorusme", text):
            return EventCategoryEnum.MEETING
        if re.search(r"deadline|son teslim", text):
            return EventCategoryEnum.DEADLINE
        if re.search(r"holiday|tatil|bayram", text):
            return EventCategoryEnum.HOLIDAY
        return EventCategoryEnum.OTHER

    def _is_critical(self, title: str, description: str) -> bool:
        text = f"{title} {description}".lower()
        # Eğer 'acil', 'zorunlu', 'urgent' varsa true
        return bool(re.search(r"acil|urgent|zorunlu|mandatory", text))

    def fetch_and_parse(self, url: str = None):
        """Dış iCal beslemesinden verileri DB'ye çeker"""
        ics_content = ""
        if self.use_mock or not url:
            ics_content = MOCK_ICS_DATA
        else:
            try:
                response = urllib.request.urlopen(url)
                ics_content = response.read()
            except Exception as e:
                print(f"Calendar fetch failed: {e}")
                return 0

        cal = Calendar.from_ical(ics_content)
        
        db = SessionLocal()
        inserted = 0
        try:
            for component in cal.walk():
                if component.name == "VEVENT":
                    uid = str(component.get('uid'))
                    
                    # Kopya kontrolü
                    existing = db.query(InstitutionalEvent).filter_by(source_uid=uid).first()
                    if existing:
                        continue
                        
                    title = str(component.get('summary', 'Untitled Event'))
                    desc = str(component.get('description', ''))
                    
                    # DTSTART and DTEND objects in icalendar
                    start = component.get('dtstart').dt
                    end = component.get('dtend')
                    end = end.dt if end else start

                    # Konum/Tür zekası
                    cat = self._determine_category(title, desc)
                    crit = self._is_critical(title, desc)
                    
                    event = InstitutionalEvent(
                        title=title,
                        description=desc,
                        start_time=start if isinstance(start, datetime) else datetime.combine(start, datetime.min.time()),
                        end_time=end if isinstance(end, datetime) else datetime.combine(end, datetime.min.time()),
                        category=cat,
                        is_critical=crit,
                        source_uid=uid
                    )
                    db.add(event)
                    inserted += 1
                    
            db.commit()
            print(f"=== SİSTEM DUYURUSU: Takvim basariyla ayristirildi. {inserted} yeni etkinlik eklendi ===")
            return inserted
        except Exception as e:
            db.rollback()
            print("Parser logic DB error: ", e)
        finally:
            db.close()
            
if __name__ == "__main__":
    # Test script run
    parser = CalendarParser(use_mock=True)
    parser.fetch_and_parse()
