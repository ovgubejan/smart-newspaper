import uuid
from datetime import datetime
from db import db
from models import NewsArticle, TopicCluster, ArticleClusterLink
from vector_db import vector_db_manager
from nlp_service import nlp_manager

class NewsClusteringEngine:
    def __init__(self):
        pass

    def run_clustering_cycle(self):
        """Batches recent news and clusters similar articles."""
        # Get recent articles not clustered yet
        recent_articles = db.session.query(NewsArticle).order_by(NewsArticle.published_at.desc()).limit(100).all()
        if not recent_articles:
            return

        processed_ids = set()
        
        # Sadece clustering'e girmemis oyunculari islemek adina:
        existing_links = db.session.query(ArticleClusterLink.article_id).all()
        clustered_article_ids = {link[0] for link in existing_links}
        
        for art in recent_articles:
            if art.id in processed_ids or art.id in clustered_article_ids:
                continue
                
            # Find similar articles
            res = vector_db_manager.find_similar_articles(art.id, top_k=5)
            if "similar_ids" not in res:
                continue
                
            similar_ids = res["similar_ids"]
            scores = res.get("scores", [])
            
            # Filter matches with similarity > 0.8
            cluster_candidates = [art.id]
            for sim_id, score in zip(similar_ids, scores):
                if score > 0.8 and sim_id not in processed_ids and sim_id not in clustered_article_ids:
                    cluster_candidates.append(sim_id)
                    
            if len(cluster_candidates) > 1:
                # We have a cluster!
                cluster_arts = db.session.query(NewsArticle).filter(NewsArticle.id.in_(cluster_candidates)).all()
                
                # Combine texts for AI summary
                combined_text = ""
                for c_art in cluster_arts:
                    combined_text += f"\n- Kaynak ({c_art.source}): {c_art.title}\n{c_art.ai_summary or c_art.content_text[:200]}\n"
                    processed_ids.add(c_art.id)
                
                # AI Summary
                system_prompt = "Sen tarafsız bir haber özetleyicisin. Farklı kaynaklardan gelen haberleri harmanlayıp zıt görüşleri/olayları tek bir metin halinde özetlersin."
                user_prompt = f"Aşağıdaki farklı kaynaklardan gelen benzer iddiaları ve haberleri okuyup, tarafsız, kapsamlı ve 3 paragraflık bir özet çıkar:\n{combined_text[:3000]}"
                
                if nlp_manager.use_mock:
                    ai_summary = "Yapay Zeka Özeti: Bu kümedeki haberler ilgili konuda farklı medya kuruluşlarının ortak ve zıt görüşlerini yansıtmaktadır. Karşılaştırmalı detaylar tarafsızca analiz edilmiştir."
                else:
                    try:
                        ai_summary = nlp_manager._call_openai(system_prompt, user_prompt, max_tokens=350)
                    except Exception:
                        ai_summary = "Farklı haber kaynakları bu konu etrafında çeşitli bilgiler paylaştı."
                
                if not ai_summary:
                    ai_summary = "Farklı haber kaynakları bu konu etrafında çeşitli bilgiler paylaştı."
                    
                # Create TopicCluster
                new_cluster = TopicCluster(
                    id=str(uuid.uuid4()),
                    topic_name=art.title, # En uygun ortak baslik
                    ai_summary=ai_summary,
                    created_at=datetime.utcnow(),
                    is_active=True
                )
                db.session.add(new_cluster)
                
                for c_id in cluster_candidates:
                    link = ArticleClusterLink(cluster_id=new_cluster.id, article_id=c_id)
                    db.session.add(link)
                    
                # Kullanıcının talebi: Kümelemeyi ayri bir UI değil, TEK BIR HABER olarak ver.
                # BİLİMHABER AI tarafindan olusturulmus sentetik bir NewsArticle olarak ekliyoruz
                synth_article = NewsArticle(
                    id=f"cluster_{new_cluster.id}",
                    title=f"[TÜM KAYNAKLAR] {new_cluster.topic_name}",
                    url="", # Linki bos
                    source="BİLİMHABER AI",
                    content_text=ai_summary, # Karsilastirmali ozeti icerik olarak basiyoruz
                    ai_summary=ai_summary,
                    ai_category=art.ai_category, # Ilk haberin kategorisini al
                    published_at=datetime.utcnow(),
                    is_active=True
                )
                db.session.add(synth_article)
                    
        try:
            db.session.commit()
            print("[CLUSTERING] Kümeleme döngüsü tamamlandı.")
        except Exception as e:
            db.session.rollback()
            print(f"[CLUSTERING] Hata: {e}")

clustering_engine = NewsClusteringEngine()
