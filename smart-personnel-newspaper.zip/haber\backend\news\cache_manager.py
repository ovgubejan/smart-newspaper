# backend/news/cache_manager.py
from typing import List, Optional
from datetime import datetime
from .models import GlobalNewsItem

class NewsCacheManager:
    """
    Haberleri bellekte (in-memory) tutan ve API üzerinden anında dönüş sağlayan
    Singleton cache katmanı.
    """
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(NewsCacheManager, cls).__new__(cls)
            cls._instance.news_articles = []
            cls._instance.last_updated = None
        return cls._instance

    def update_cache(self, news_list: List[GlobalNewsItem]):
        """
        Belleği yeni haberlerle günceller.
        """
        self.news_articles = news_list
        self.last_updated = datetime.utcnow()
        print(f"[CACHE] Haber önbelleği güncellendi. Toplam {len(news_list)} haber.")

    def get_news(self, limit: int = 200) -> List[GlobalNewsItem]:
        """
        Önbellekteki haberleri döndürür.
        """
        return self.news_articles[:limit]

# Singleton nesne
news_cache = NewsCacheManager()
