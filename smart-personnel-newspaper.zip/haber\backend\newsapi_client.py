# newsapi_client.py
"""
NewsAPI.org entegrasyonu - Gerçek haber verisi çekici
Kayıt: https://newsapi.org/register (ücretsiz, günde 100 istek)
"""
import requests
import os
from datetime import datetime
from news_dto import NewsDTO

# .env dosyasından key yükle
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

NEWS_API_KEY = os.environ.get("NEWS_API_KEY", "")
NEWS_API_BASE = "https://gnews.io/api/v4"

# Kategori → GNews topic map
CATEGORY_MAP = {
    "Technology": "technology",
    "Politics": "nation", # GNews'te 'nation' veya 'world', politika olarak kabul edilebilir
    "Economy": "business",
    "Sports": "sports",
    "Health": "health",
    "Science": "science",
    "World": "world",
}

# Basit Bellek İçi Önbellek (Caching) Mekanizması
_news_cache = {}
CACHE_TTL_SECONDS = 900 # 15 Dakika

def fetch_top_headlines(category: str = "technology", language: str = "en", page_size: int = 10, allow_mock: bool = True):
    """GNews API'den gerçek haberler çeker ve NewsDTO listesi döndürür (Önbellek destekli)"""
    # Önbellek kontrolü
    cache_key = f"{category}_{language}_{page_size}"
    if cache_key in _news_cache:
        cached_data, timestamp = _news_cache[cache_key]
        if (datetime.utcnow() - timestamp).total_seconds() < CACHE_TTL_SECONDS:
            print(f"[CACHE] {category} kategorisi bellekten getirildi.")
            return cached_data

    if not NEWS_API_KEY or NEWS_API_KEY == "buraya_api_keyinizi_yapistirin":
        print("[GNEWS_API] API Key bulunamadi, fallback davranisi devrede.")
        return _mock_news(category) if allow_mock else []
    
    api_category = CATEGORY_MAP.get(category, "technology")
    
    try:
        url = f"{NEWS_API_BASE}/top-headlines"
        params = {
            "topic": api_category,
            "lang": language,
            "max": page_size,
            "apikey": NEWS_API_KEY,
        }
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        
        if "errors" in data and len(data["errors"]) > 0:
            print(f"[GNEWS_API] Hata: {data['errors']}")
            return _mock_news(category) if allow_mock else []
        
        dtos = []
        for art in data.get("articles", []):
            if not art.get("title") or not art.get("url"):
                continue
            try:
                dto = NewsDTO(
                    title=art["title"],
                    url=art["url"],
                    description=art.get("description") or art.get("title", ""),
                    source=art.get("source", {}).get("name", "GNews"),
                    language=language,
                    published_at=art.get("publishedAt", ""),
                    image_url=art.get("image"),
                )
                dtos.append(dto)
            except Exception as e:
                print(f"[GNEWS_API] DTO parse hatasi: {e}")
                continue
        
        print(f"[GNEWS_API] ✅ {category} kategorisinden {len(dtos)} haber çekildi.")
        
        # Başarılı sonucu önbelleğe yaz
        _news_cache[cache_key] = (dtos, datetime.utcnow())
        
        return dtos
        
    except Exception as e:
        print(f"[GNEWS_API] Baglanti hatasi: {e}, fallback davranisi devrede.")
        return _mock_news(category) if allow_mock else []


def fetch_everything(query: str, language: str = "en", page_size: int = 5):
    """Belirli bir anahtar kelime için genel arama (GNews)"""
    if not NEWS_API_KEY or NEWS_API_KEY == "buraya_api_keyinizi_yapistirin":
        return []
    
    try:
        url = f"{NEWS_API_BASE}/search"
        params = {
            "q": query,
            "lang": language,
            "max": page_size,
            "apikey": NEWS_API_KEY,
        }
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        
        dtos = []
        for art in data.get("articles", []):
            if not art.get("title") or not art.get("url"):
                continue
            try:
                dto = NewsDTO(
                    title=art["title"],
                    url=art["url"],
                    description=art.get("description") or art.get("title", ""),
                    source=art.get("source", {}).get("name", "GNews"),
                    language=language,
                    published_at=art.get("publishedAt", ""),
                    image_url=art.get("image"),
                )
                dtos.append(dto)
            except Exception:
                continue
        return dtos
    except Exception as e:
        print(f"[GNEWS_API] Search hatasi: {e}")
        return []


def _mock_news(category: str):
    """API key yokken kullanılacak sahte veriler"""
    mock_data = {
        "Technology": [
            ("Apple launches AI-powered glasses with real-time translation", "https://example.com/1", "Apple's latest device promises to revolutionize how we interact with the world."),
            ("Quantum computing milestone: Scientists achieve 1000-qubit processor", "https://example.com/2", "A breakthrough that could reshape encryption and drug discovery."),
        ],
        "Politics":  [
            ("Senate votes on landmark infrastructure bill", "https://example.com/3", "The bill includes funding for roads, bridges, and broadband."),
        ],
        "Economy": [
            ("Fed holds interest rates steady amid inflation concerns", "https://example.com/4", "Markets rally as central bank signals cautious approach."),
        ],
        "Sports": [
            ("Champions League final set for record attendance", "https://example.com/5", "Ticket demand breaks all previous records for the prestigious tournament."),
        ],
        "Health": [
            ("New vaccine shows 95% efficacy against resistant flu strains", "https://example.com/6", "Researchers are hopeful this could mark the end of seasonal flu outbreaks."),
        ],
    }
    
    articles = mock_data.get(category, mock_data["Technology"])
    dtos = []
    for title, url, desc in articles:
        try:
            dto = NewsDTO(title=title, url=url, description=desc, source="MockFeed", language="en")
            dtos.append(dto)
        except Exception:
            pass
    return dtos


if __name__ == "__main__":
    # Test
    articles = fetch_top_headlines("Technology")
    for a in articles:
        print(f"  → {a.title[:60]}...")
