@echo off
chcp 65001 >nul
setlocal

echo.
echo ╔══════════════════════════════════════════════╗
echo ║  Smart Personnel Newspaper - Otomatik Kurulum ║
echo ╚══════════════════════════════════════════════╝
echo.

cd /d "%~dp0backend"

REM --- 1. Python Kontrolu ---
echo [1/5] Python kontrol ediliyor...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo [HATA] Python bulunamadi!
    echo        Lutfen Python 3.10+ yukleyin: https://www.python.org/downloads/
    echo        Kurulumda "Add Python to PATH" kutusunu isaretlemeyi unutmayin!
    echo.
    pause
    exit /b 1
)
for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do echo        Bulunan versiyon: %%v

REM --- 2. Sanal Ortam ---
echo [2/5] Sanal ortam olusturuluyor...
if not exist ".venv\Scripts\python.exe" (
    python -m venv .venv
    if errorlevel 1 (
        echo [HATA] Sanal ortam olusturulamadi!
        pause
        exit /b 1
    )
    echo        .venv olusturuldu.
) else (
    echo        .venv zaten mevcut, atlaniyor.
)

REM --- 3. .env Dosyasi ---
echo [3/5] Ortam degiskenleri hazirlaniyor...
if not exist ".env" (
    if exist ".env.example" (
        copy ".env.example" ".env" >nul
        echo        .env dosyasi olusturuldu.
        echo.
        echo  ╔═══════════════════════════════════════════════════════════╗
        echo  ║  UYARI: backend\.env dosyasina API anahtarlarinizi       ║
        echo  ║  girmeniz gerekiyor! En az NEWS_API_KEY zorunludur.      ║
        echo  ║  GNews ucretsiz hesap: https://gnews.io/dashboard       ║
        echo  ╚═══════════════════════════════════════════════════════════╝
        echo.
    ) else (
        echo        [UYARI] .env.example bulunamadi, .env manuel olusturulmali.
    )
) else (
    echo        .env zaten mevcut, atlaniyor.
)

REM --- 4. Bagimliliklar ---
echo [4/5] Python paketleri yukleniyor (bu biraz zaman alabilir)...
".venv\Scripts\pip.exe" install --upgrade pip --quiet >nul 2>&1
".venv\Scripts\pip.exe" install -r requirements.txt --quiet
if errorlevel 1 (
    echo        [UYARI] Bazi paketler yuklenemedi ama devam ediliyor...
) else (
    echo        Tum paketler basariyla yuklendi.
)

REM --- 5. Veritabani ---
echo [5/5] Veritabani hazirlaniyor...
".venv\Scripts\python.exe" -c "from db import engine; print('        Veritabani hazir: news.db')" 2>nul
if errorlevel 1 (
    echo        Veritabani ilk calistirmada otomatik olusacak.
)

echo.
echo ============================================
echo  KURULUM TAMAMLANDI!
echo ============================================
echo.
echo  Projeyi baslatmak icin:
echo    start_project.bat
echo.
echo  Veya manuel:
echo    cd backend
echo    .venv\Scripts\activate
echo    python -m uvicorn api:app --host 127.0.0.1 --port 8000 --reload
echo.
echo  Frontend: http://127.0.0.1:8000
echo  API Docs: http://127.0.0.1:8000/docs
echo.
pause
