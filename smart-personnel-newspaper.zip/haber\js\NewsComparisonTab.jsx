import React, { useEffect, useMemo, useState } from 'react';

const DEFAULT_API_BASE_URL = 'http://127.0.0.1:8000/api/v1';

function getApiBaseUrl() {
    if (typeof window !== 'undefined' && window.API_BASE_URL) {
        return window.API_BASE_URL;
    }
    return DEFAULT_API_BASE_URL;
}

function getCurrentLang() {
    if (typeof window !== 'undefined') {
        return window.currentLang || window.localStorage?.getItem('pref_lang') || 'tr';
    }
    return 'tr';
}

async function requestJson(url, options) {
    const response = await fetch(url, options);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
}

async function loadComparisonFeed({ forceRefresh = false, limit = 30 }) {
    const params = new URLSearchParams({
        limit: String(limit),
        lang: getCurrentLang(),
    });
    if (forceRefresh) params.set('force_refresh', 'true');
    return requestJson(`${getApiBaseUrl()}/comparison-feed?${params.toString()}`);
}

async function rebuildComparisonFeed({ targetCount = 30 }) {
    return requestJson(`${getApiBaseUrl()}/comparison/rebuild`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            target_count: targetCount,
            language: getCurrentLang(),
        })
    });
}

async function scanLatestComparisons({ limit = 20 }) {
    return requestJson(`${getApiBaseUrl()}/comparison/scan-latest`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            category: null,
            keywords: [],
            language: getCurrentLang(),
            limit,
        })
    });
}

function isPairNew(pair) {
    if (!pair?.isNew || !pair?.newUntil) return false;
    return new Date(pair.newUntil).getTime() > Date.now();
}

function ComparisonCard({ label, article }) {
    return (
        <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-3 flex items-center justify-between gap-3">
                <span className="rounded-full bg-slate-900 px-3 py-1 text-xs font-bold uppercase tracking-[0.18em] text-white">
                    Kaynak {label}
                </span>
                <span className="text-xs font-semibold text-slate-500">
                    {article?.publishedAt ? new Date(article?.publishedAt).toLocaleDateString('tr-TR') : ''}
                </span>
            </div>
            {article?.imageUrl ? (
                <img
                    src={article?.imageUrl}
                    alt={article?.title || `Kaynak ${label}`}
                    className="mb-4 h-48 w-full rounded-xl object-cover"
                />
            ) : null}
            <div className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-slate-500">
                {article?.source || `Kaynak ${label}`}
            </div>
            <h3 className="mb-3 text-xl font-black leading-tight text-slate-900">
                {article?.title || 'Baslik bulunamadi'}
            </h3>
            <p className="text-sm leading-6 text-slate-600">
                {article?.summary || article?.description || article?.ai_summary || 'Ozet bulunamadi.'}
            </p>
            {article?.url ? (
                <a href={article?.url} target="_blank" rel="noreferrer" className="mt-4 inline-flex text-sm font-bold text-sky-700">
                    Orijinal habere git
                </a>
            ) : null}
        </article>
    );
}

function AnalysisBlock({ analysis, pair }) {
    const sourceA = pair?.leftArticle?.source || 'Kaynak A';
    const sourceB = pair?.rightArticle?.source || 'Kaynak B';

    return (
        <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <h3 className="mb-5 text-lg font-black tracking-tight text-slate-900">Yapay Zeka Medya Analizi</h3>

            <div className="space-y-4 text-sm leading-6 text-slate-700">
                <div>
                    <p className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-indigo-700">BASLIK KARSILASTIRMASI</p>
                    <p><strong>{sourceA}:</strong> {analysis?.headlineComparison?.sourceA || 'Hazirlaniyor.'}</p>
                    <p><strong>{sourceB}:</strong> {analysis?.headlineComparison?.sourceB || 'Hazirlaniyor.'}</p>
                </div>
                <div>
                    <p className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-sky-700">HABERIN ODAK NOKTASI</p>
                    <p><strong>{sourceA}:</strong> {analysis?.focusComparison?.sourceA || 'Hazirlaniyor.'}</p>
                    <p><strong>{sourceB}:</strong> {analysis?.focusComparison?.sourceB || 'Hazirlaniyor.'}</p>
                </div>
                <div>
                    <p className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-violet-700">DIL VE TON FARKI</p>
                    <p><strong>{sourceA}:</strong> {analysis?.toneComparison?.sourceA || 'Hazirlaniyor.'}</p>
                    <p><strong>{sourceB}:</strong> {analysis?.toneComparison?.sourceB || 'Hazirlaniyor.'}</p>
                </div>
                <div>
                    <p className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-amber-700">AKTOR SUNUMU</p>
                    <p><strong>{sourceA}:</strong> {analysis?.actorPresentation?.sourceA || 'Hazirlaniyor.'}</p>
                    <p><strong>{sourceB}:</strong> {analysis?.actorPresentation?.sourceB || 'Hazirlaniyor.'}</p>
                </div>
                <div>
                    <p className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-slate-700">EKSIK VEYA AZ VURGULANAN BILGILER</p>
                    <p><strong>{sourceA}:</strong> {analysis?.missingOrUnderplayed?.sourceA || 'Hazirlaniyor.'}</p>
                    <p><strong>{sourceB}:</strong> {analysis?.missingOrUnderplayed?.sourceB || 'Hazirlaniyor.'}</p>
                </div>
                <div className="rounded-xl bg-emerald-50 p-4">
                    <p className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-emerald-700">GENEL KARSILASTIRMA OZETI</p>
                    <p>{analysis?.overallSummary || 'Analiz hazirlaniyor.'}</p>
                </div>
            </div>
        </section>
    );
}

export default function NewsComparisonTab() {
    const [pairs, setPairs] = useState([]);
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    const [isScanning, setIsScanning] = useState(false);
    const [statusMessage, setStatusMessage] = useState('Hazir comparison havuzu yukleniyor...');

    useEffect(() => {
        let isCancelled = false;

        async function bootstrap() {
            setIsLoading(true);
            setStatusMessage('Hazir comparison havuzu yukleniyor...');

            try {
                let feed = await loadComparisonFeed({ limit: 30 });
                let comparisons = Array.isArray(feed?.comparisons) ? feed.comparisons : [];

                if (comparisons.length === 0) {
                    setStatusMessage('Feed bos. Comparison database seed havuzu yeniden kuruluyor...');
                    feed = await rebuildComparisonFeed({ targetCount: 30 });
                    comparisons = Array.isArray(feed?.comparisons) ? feed.comparisons : [];
                }

                if (isCancelled) return;

                setPairs(comparisons);
                setSelectedIndex(0);
                setStatusMessage(comparisons.length > 0 ? '' : 'Hazir comparison feed olusturulamadi.');
            } catch (error) {
                if (!isCancelled) {
                    setPairs([]);
                    setStatusMessage(error?.message || 'Comparison feed alinamadi.');
                }
            } finally {
                if (!isCancelled) {
                    setIsLoading(false);
                }
            }
        }

        bootstrap();

        return () => {
            isCancelled = true;
        };
    }, []);

    const activePair = useMemo(() => pairs?.[selectedIndex] || null, [pairs, selectedIndex]);

    async function handleFetchNew() {
        if (isScanning) return;
        setIsScanning(true);
        setStatusMessage('Yeni comparison-ready olaylar taraniyor...');
        try {
            const payload = await scanLatestComparisons({ limit: 20 });
            const comparisons = Array.isArray(payload?.comparisons) ? payload.comparisons : [];
            setPairs(comparisons);
            setSelectedIndex(0);
            const inserted = Number(payload?.scanResult?.insertedCount || 0);
            setStatusMessage(
                inserted > 0
                    ? `${inserted} yeni comparison kaydi eklendi ve yesil badge ile isaretlendi.`
                    : 'Tarama tamamlandi. Yeni comparison-ready kayit bulunamadi.'
            );
        } catch (error) {
            setStatusMessage(error?.message || 'Yeni tarama basarisiz oldu.');
        } finally {
            setIsScanning(false);
        }
    }

    if (isLoading) {
        return (
            <section className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
                <div className="flex flex-col items-center justify-center gap-4 py-12 text-center">
                    <div className="h-12 w-12 animate-spin rounded-full border-4 border-slate-200 border-t-sky-600" />
                    <p className="text-base font-semibold text-slate-800">{statusMessage}</p>
                    <p className="text-sm text-slate-500">Ilk acilista once database icindeki hazir comparison havuzu kullanilir.</p>
                </div>
            </section>
        );
    }

    if (!pairs?.length) {
        return (
            <section className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
                <div className="flex flex-col items-center justify-center gap-4 py-12 text-center">
                    <div className="h-12 w-12 animate-pulse rounded-full bg-sky-100" />
                    <p className="text-base font-semibold text-slate-800">Hazir comparison havuzu olusturulamadi.</p>
                    <p className="text-sm text-slate-500">{statusMessage}</p>
                </div>
            </section>
        );
    }

    return (
        <section className="space-y-6">
            <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm md:flex-row md:items-center md:justify-between">
                <div>
                    <p className="text-sm font-black uppercase tracking-[0.18em] text-slate-500">Comparison Feed</p>
                    <p className="text-base font-semibold text-slate-800">
                        {pairs.length} hazir comparison kaydi listeleniyor.
                    </p>
                    {statusMessage ? <p className="text-sm text-slate-500">{statusMessage}</p> : null}
                </div>
                <button
                    type="button"
                    onClick={handleFetchNew}
                    disabled={isScanning}
                    className="inline-flex items-center justify-center rounded-xl bg-slate-900 px-4 py-3 text-sm font-black text-white transition hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-70"
                >
                    {isScanning ? 'Taranıyor...' : 'Yenilerini Tara / Guncelle'}
                </button>
            </div>

            <aside className="grid gap-3 lg:grid-cols-3">
                {pairs?.map((pair, index) => (
                    <button
                        key={pair?.eventId || index}
                        type="button"
                        onClick={() => setSelectedIndex(index)}
                        className={`rounded-2xl border p-4 text-left shadow-sm transition ${
                            index === selectedIndex
                                ? 'border-sky-600 bg-sky-50'
                                : 'border-slate-200 bg-white hover:border-slate-300'
                        }`}
                    >
                        <p className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                            {pair?.category || 'World'} • Skor {Number(pair?.matchScore || 0).toFixed(1)}
                        </p>
                        <h3 className="mb-3 line-clamp-2 text-base font-black leading-tight text-slate-900">
                            {pair?.eventTitle || pair?.leftArticle?.title || 'Dogrulanmis olay'}
                        </h3>
                        <p className="text-xs font-semibold text-slate-500">
                            {pair?.leftArticle?.source || 'Kaynak A'} vs {pair?.rightArticle?.source || 'Kaynak B'}
                        </p>
                        {isPairNew(pair) ? (
                            <span className="mt-3 inline-flex items-center gap-2 rounded-full border border-emerald-300 bg-emerald-50 px-3 py-1 text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">
                                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                                Yeni Eklendi
                            </span>
                        ) : null}
                    </button>
                ))}
            </aside>

            <div className="grid gap-6 lg:grid-cols-2">
                <ComparisonCard label="A" article={activePair?.leftArticle} />
                <ComparisonCard label="B" article={activePair?.rightArticle} />
            </div>

            <AnalysisBlock analysis={activePair?.analysis} pair={activePair} />
        </section>
    );
}
