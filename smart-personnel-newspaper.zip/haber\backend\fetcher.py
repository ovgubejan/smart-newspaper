# fetcher.py
from abc import ABC, abstractmethod
import feedparser
import requests
import httpx
import asyncio
from bs4 import BeautifulSoup
from typing import List
from news_dto import NewsDTO
from deduplicator import is_duplicate
from db import db
import hashlib

class IngestionStrategy(ABC):
    """Veri Toplama Stratejisi Arayüzü (Strategy Pattern)"""
    @abstractmethod
    def fetch(self, source_url: str, language: str = "en") -> List[NewsDTO]:
        pass

class WebCrawlerStrategy(IngestionStrategy):
    """RSS veya Blogları crawl eden strateji türü"""
    def fetch(self, source_url: str, language: str = "en") -> List[NewsDTO]:
        print(f"[*] [CRAWLER] Calisiyor... Kaynak: {source_url}")
        parsed_feed = feedparser.parse(source_url)
        results = []
        
        for entry in parsed_feed.entries:
            raw_desc = entry.get('description', '')
            soup = BeautifulSoup(raw_desc, "html.parser")
            clean_desc = soup.get_text()
            
            url_str = entry.get('link', '')
            url_hash = hashlib.sha256(url_str.encode('utf-8')).hexdigest() if url_str else ""
            
            try:
                dto = NewsDTO(
                    title=entry.get('title', 'Başlıksız'),
                    url=url_str,
                    description=clean_desc,
                    source=source_url,
                    language=language,
                    url_hash=url_hash
                )
                results.append(dto)
            except Exception as e:
                print(f"[CRAWLER] Veri Uyumsuzlugu, Nesne Reddedildi: {e}")
                
        return results

class APINewsStrategy(IngestionStrategy):
    """
    Dış API'lere (örn: NewsAPI, Bloomberg API) bağlanan strateji.
    (Şu an sahte/mock JSON dönen açık bir test servisine veya Dummy veriye adapte)
    """
    def fetch(self, source_url: str, language: str = "en") -> List[NewsDTO]:
        print(f"[*] [API] Veri cekiliyor... Uc Nokta: {source_url}")
        results = []
        try:
            # Örnek sahte API verisi (mock). Gerçekte requests.get(source_url).json() olmalıdır.
            mock_api_reponse = [
                {
                    "title": "API Test Haberi 1 (Dummy)", 
                    "link": "https://dummyapi.com/news/1", 
                    "content": "Bu haber API üzerinden Dummy olarak gelmiştir."
                },
                {
                    "title": "API Test Haberi Kopya (Dummy)", 
                    "link": "https://dummyapi.com/news/2", 
                    "content": "Bu haber API üzerinden Dummy olarak gelmiştir." # Kopyalamayı test etmek için
                }
            ]
            
            for item in mock_api_reponse:
                url_str = item['link']
                url_hash = hashlib.sha256(url_str.encode('utf-8')).hexdigest()
                dto = NewsDTO(
                    title=item['title'],
                    url=url_str,
                    description=item['content'],
                    source=source_url,
                    language=language,
                    url_hash=url_hash
                )
                results.append(dto)
        except Exception as e:
            print(f"[API] İstek Hatali: {e}")
            
        return results

class NewsIngestionService:
    """Veri Toplama Yöneticisi (Context)"""
    def __init__(self, strategy: IngestionStrategy):
        self._strategy = strategy
        
    def set_strategy(self, strategy: IngestionStrategy):
        self._strategy = strategy
        
    def execute_ingestion(self, source_url: str, language: str = "en"):
        news_dtos = self._strategy.fetch(source_url, language)
        inserted_count = 0
        
        for dto in news_dtos:
            # 1. DTO Kopya Denetimi (Dedüplikasyon)
            if not is_duplicate(dto, db.get_all_dtos()):
                # 2. Veritabanına Yazım Katmanı ve ID Dönüşü
                new_id = db.add_dto(dto)
                inserted_count += 1
                
                # 3. NLP Asenkron Kuyruğa Gönderim
                from tasks import process_article_nlp_task
                process_article_nlp_task.delay(new_id)  # OSINT Veri Akışı Celery'e gönderilir (NLP-Bound)
                
        print(f"=== SİSTEM DUYURUSU: '{source_url}' ({type(self._strategy).__name__}) kaynağından {inserted_count} YE-Nİ haber eklendi. ===")
        return inserted_count

async def fetch_global_news_async(source_url: str, language: str = "en") -> int:
    """Asenkron OSINT Veri Çekimi (HTTPX + Feedparser)"""
    print(f"[*] (OSINT) Asenkron veri çekiliyor: {source_url}")
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.get(source_url)
            
        parsed_feed = feedparser.parse(response.content)
        results = []
        for entry in parsed_feed.entries:
            raw_desc = entry.get('description', '')
            soup = BeautifulSoup(raw_desc, "html.parser")
            clean_desc = soup.get_text()
            
            url_str = entry.get('link', '')
            url_hash = hashlib.sha256(url_str.encode('utf-8')).hexdigest() if url_str else ""
            
            dto = NewsDTO(
                title=entry.get('title', 'Başlıksız'),
                url=url_str,
                description=clean_desc,
                source=source_url,
                language=language,
                url_hash=url_hash
            )
            results.append(dto)
            
        inserted_count = 0
        all_dtos = db.get_all_dtos()
        for dto in results:
            if not is_duplicate(dto, all_dtos):
                new_id = db.add_dto(dto)
                inserted_count += 1
                from tasks import process_article_nlp_task
                process_article_nlp_task.delay(new_id)
        
        print(f"=== SİSTEM DUYURUSU: '{source_url}' (OSINT ASYNC) kaynağından {inserted_count} YENİ haber eklendi. ===")
        return inserted_count
    except Exception as e:
        print(f"[OSINT HATA] {source_url} uzerinden veri cekilemedi: {e}")
        return 0

if __name__ == "__main__":
    # Dry Run Testi (Sıfırdan Çalıştırma)
    print("\n--- 1. CRAWLER STRATEJİSİ TESTİ ---")
    service = NewsIngestionService(WebCrawlerStrategy())
    service.execute_ingestion("https://feeds.bbci.co.uk/news/rss.xml", language="en")
    
    print("\n--- 2. OSINT ASYNC (HTTPX) TESTİ ---")
    asyncio.run(fetch_global_news_async("https://feeds.bbci.co.uk/news/rss.xml", "en"))
