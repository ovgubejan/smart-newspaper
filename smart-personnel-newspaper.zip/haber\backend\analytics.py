import math
from datetime import datetime, timedelta
import json
from sqlalchemy import func

from db import db
from models import Entity, ArticleEntity, DetectedTrends

class TrendAnalyzer:
    """
    Kelebek Etkisi Motoru: Veritabanındaki varlık geçiş frekanslarını analiz eder
    ve Z-Score kullanarak anormal patlamaları (peak) tespit eder.
    """
    
    def __init__(self, z_score_threshold: float = 2.0, min_occurrences: int = 3):
        self.z_score_threshold = z_score_threshold
        self.min_occurrences = min_occurrences
        self.session = db.session

    def analyze_trends(self):
        print("[TREND ANALYZER] Z-Score Analizi baslatiliyor...")
        now = datetime.utcnow()
        t_minus_24h = now - timedelta(days=1)
        t_minus_8d = now - timedelta(days=8)
        
        # Son 24 saatte geçen varlıkların sayımı (Current Period)
        recent_counts = self.session.query(
            ArticleEntity.entity_id,
            func.sum(ArticleEntity.count).label('total_count')
        ).filter(
            ArticleEntity.created_at >= t_minus_24h
        ).group_by(ArticleEntity.entity_id).all()
        
        if not recent_counts:
            print("[TREND ANALYZER] Son 24 saatte incelenecek varlik bulunamadi.")
            return []

        detected_spikes = []
        
        for entity_id, current_count in recent_counts:
            if current_count < self.min_occurrences:
                continue # Gürültüyü (noise) engellemek için mini threshold
                
            # Önceki 7 günün günlük frekanslarını alalım (T-8 to T-1)
            past_records = self.session.query(
                ArticleEntity.created_at,
                ArticleEntity.count,
                ArticleEntity.article_id
            ).filter(
                ArticleEntity.entity_id == entity_id,
                ArticleEntity.created_at >= t_minus_8d,
                ArticleEntity.created_at < t_minus_24h
            ).all()
            
            # Günlük sayımları gruplayalım
            daily_counts = {i: 0 for i in range(7)}
            for record in past_records:
                # Kaydın üzerinden kaç gün geçmiş (1'den 7'ye kadar)
                days_ago = (now - record.created_at).days
                if 1 <= days_ago <= 7:
                    daily_counts[days_ago - 1] += record.count
            
            counts_array = list(daily_counts.values())
            mean = sum(counts_array) / 7.0
            
            # Varyans ve Stdev bulma
            variance = sum((x - mean) ** 2 for x in counts_array) / 7.0
            stdev = math.sqrt(variance)
            
            z_score = 0.0
            if stdev > 0:
                z_score = (current_count - mean) / stdev
            else:
                # Standart sapma sıfırsa ve ortalama sıfırsa (yani hiç geçmemişse)
                # ve aniden 5-6 kere geçerse bu devasa bir anomali demektir.
                if current_count > self.min_occurrences:
                    z_score = self.z_score_threshold + 1.0 # Eşiği bilerek geçirtiyoruz
                    
            if z_score >= self.z_score_threshold:
                # Yakalandı!
                entity_info = self.session.query(Entity).filter_by(id=entity_id).first()
                if entity_info:
                    print(f"[!] KELEBEK ETKİSİ TESPİTİ [!] '{entity_info.name}' (Z-Score: {z_score:.2f}, Son 24s: {current_count}, Ort: {mean:.2f})")
                    
                    # İlgili makaleleri bul
                    recent_articles = self.session.query(ArticleEntity.article_id).filter(
                        ArticleEntity.entity_id == entity_id,
                        ArticleEntity.created_at >= t_minus_24h
                    ).all()
                    
                    article_ids = [a.article_id for a in recent_articles]
                    
                    new_trend = DetectedTrends(
                        entity_id=entity_id,
                        peak_time=now,
                        severity_score=round(z_score, 2),
                        related_articles=article_ids,
                        is_active=True
                    )
                    self.session.add(new_trend)
                    detected_spikes.append(new_trend)
        
        if detected_spikes:
            self.session.commit()
            print(f"[TREND ANALYZER] Toplam {len(detected_spikes)} yeni trend veritabanına kaydedildi.")
        else:
            print("[TREND ANALYZER] Olagandisi bir trend tespit edilmedi.")
            
        return detected_spikes

analyzer = TrendAnalyzer()
