// js/i18n.js — Çoklu Dil Desteği (TR/EN)

const translations = {
    tr: {
        // Navigation
        sources_live: "105 KAYNAK CANLI",
        news: "HABER",
        home: "Anasayfa",
        latest_news: "Güncel Haberler",
        top_stories: "Öne Çıkanlar",
        tech_news: "Teknoloji Dünyası",
        politics: "Politika",
        economy: "Ekonomi",
        technology: "Teknoloji",
        sports: "Spor",
        health: "Sağlık",
        science: "Bilim",
        world: "Dünya",
        weather: "Hava Durumu",
        education: "Eğitim",
        culture: "Kültür-Sanat",
        gazette: "Gazete",
        // Search
        search_placeholder: "Haber, konu veya kaynak ara...",
        // Auth
        login: "Giriş Yap",
        signup: "Kayıt Ol",
        signin: "Giriş Yap",
        profile: "Profilim",
        logout: "Çıkış Yap",
        profile_info: "Profil Bilgileri",
        my_preferences: "Tercihlerim",
        // Profile
        first_name: "Ad",
        last_name: "Soyad",
        email: "E-posta",
        new_password: "Yeni Şifre",
        save_changes: "Değişiklikleri Kaydet",
        stats_title: "Okuma İstatistiklerim",
        stats_subtitle: "En çok ilgi duyduğunuz kategoriler",
        // Gazette
        gazette_title: "GÜNLÜK GAZETE",
        gazette_subtitle: "Kişiselleştirilmiş Haber Bülteniniz",
        your_gazette: "Kişisel Gazeteniz",
        prev_page: "Önceki Sayfa",
        next_page: "Sonraki Sayfa",
        print_pdf: "Yazdır / PDF",
        close: "Kapat",
        ai_summary_title: "YZ ÖZETİ",
        ai_summary_short: "YZ",
        ai_badge: "ChatGPT YZ Özeti",
        issue: "Sayı",
        // Content
        read_more: "Devamını Oku",
        loading: "Yükleniyor...",
        no_news: "Haber bulunamadı.",
        empty_category_msg: "Bu kategoride henüz güncel bir haber akışı yok, lütfen daha sonra tekrar kontrol edin.",
        breaking_news: "Son Dakika",
        trending: "Trend Haberler",
        live_feed: "Canlı Haber Akışı",
        subscribe_title: "Haberdar Ol",
        subscribe_desc: "Son dakika haberleri ve günün öne çıkan gelişmeleri her gün doğrudan e-posta kutunuza gelsin.",
        subscribe_btn: "Abone Ol",
        email_placeholder: "E-posta adresiniz",
        daily_digest: "Günlük Özet",
        discovery: "Keşif",
        source: "KAYNAK",
        verified: "Doğrulandı",
        see_all: "Tümünü Gör",
        featured_topics: "Seçtiğim Konulardan Öne Çıkanlar",
        tech_featured: "Teknoloji Öne Çıkanlar",
        ad_label: "REKLAM",
        sponsored: "SPONSORLU",
        // Preferences
        select_interests: "İlgi Alanlarını Seç",
        pref_hint: "Akışında görmek istediğin konuları seç (birden fazla seçebilirsin)",
        save_prefs: "Tercihleri Kaydet",
        skip_now: "Şimdi Atla",
        // Signup
        create_account: "Hesap Oluştur",
        confirm_password: "Şifreyi Yeniden Girin",
        already_have_account: "Zaten hesabınız var mı?",
        no_account: "Hesabınız yok mu?",
        register: "Kayıt Olun",
        // Misc
        original_source: "Haberin Orijinal Kaynağı",
        news_count: "haber",
        page_of: "Sayfa"
    },
    en: {
        sources_live: "105 SOURCES LIVE",
        news: "NEWS",
        home: "Home",
        latest_news: "Latest News",
        top_stories: "Top Stories",
        tech_news: "Tech World",
        politics: "Politics",
        economy: "Economy",
        technology: "Technology",
        sports: "Sports",
        health: "Health",
        science: "Science",
        world: "World",
        weather: "Weather",
        education: "Education",
        culture: "Culture & Art",
        gazette: "Gazette",
        search_placeholder: "Search news, topics or sources...",
        login: "Login",
        signup: "Sign Up",
        signin: "Sign In",
        profile: "My Profile",
        logout: "Logout",
        profile_info: "Profile Info",
        my_preferences: "My Preferences",
        first_name: "First Name",
        last_name: "Last Name",
        email: "Email",
        new_password: "New Password",
        save_changes: "Save Changes",
        stats_title: "My Reading Stats",
        stats_subtitle: "Categories you're most interested in",
        gazette_title: "DAILY GAZETTE",
        gazette_subtitle: "Your Personalized News Bulletin",
        your_gazette: "Your Personal Gazette",
        prev_page: "Previous Page",
        next_page: "Next Page",
        print_pdf: "Print / PDF",
        close: "Close",
        ai_summary_title: "AI SUMMARY",
        ai_summary_short: "AI",
        ai_badge: "ChatGPT AI Summary",
        issue: "Issue",
        read_more: "Read More",
        loading: "Loading...",
        no_news: "No news found.",
        empty_category_msg: "There are no current news updates in this category yet, please check back later.",
        breaking_news: "Breaking News",
        trending: "Trending News",
        live_feed: "Live News Feed",
        subscribe_title: "Stay Updated",
        subscribe_desc: "Get the latest breaking news and top stories delivered to your inbox daily.",
        subscribe_btn: "Subscribe",
        email_placeholder: "Your email address",
        daily_digest: "Daily Digest",
        discovery: "Discovery",
        source: "SOURCE",
        verified: "Verified",
        see_all: "See All",
        featured_topics: "Featured From My Topics",
        tech_featured: "Technology Featured",
        ad_label: "AD",
        sponsored: "SPONSORED",
        select_interests: "Select Your Interests",
        pref_hint: "Choose the topics you want to see in your feed (you can select multiple)",
        save_prefs: "Save Preferences",
        skip_now: "Skip for Now",
        create_account: "Create Account",
        confirm_password: "Confirm Password",
        already_have_account: "Already have an account?",
        no_account: "Don't have an account?",
        register: "Register",
        original_source: "Original Source",
        news_count: "news",
        page_of: "Page"
    }
};


let currentLang = 'tr';

function setLanguage(lang) {
    // Sadece TR ve EN destekleniyor — geçersiz dil gelirse TR'ye düş
    if (lang !== 'tr' && lang !== 'en') lang = 'tr';
    if (!translations[lang]) return;
    currentLang = lang;
    window.currentLang = lang;
    localStorage.setItem('pref_lang', lang);
    
    // Update all data-i18n elements
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[lang][key]) {
            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                el.placeholder = translations[lang][key];
            } else {
                el.textContent = translations[lang][key];
            }
        }
    });

    // Re-render navigation with translated labels
    if (typeof updateNavForPreferences === 'function') {
        const session = (typeof Auth !== 'undefined') ? Auth.getSession() : null;
        const prefs = (session && session.selectedTopics && session.selectedTopics.length > 0) ? session.selectedTopics : [];
        updateNavForPreferences(prefs);
    }

    // Update sidebar static titles
    const trendTitle = document.querySelector('#trending-list')?.closest('div')?.querySelector('h3');
    if (trendTitle) trendTitle.innerHTML = `<i class="fas fa-fire text-orange-500 mr-2"></i> ${translations[lang]['trending'] || 'Trend Haberler'}`;
    
    const liveTitle = document.querySelector('#latest-feed')?.closest('div')?.querySelector('h3');
    if (liveTitle) liveTitle.innerHTML = `<span class="w-2 h-2 rounded-full bg-brandRed animate-pulse mr-2"></span> ${translations[lang]['live_feed'] || 'Canlı Haber Akışı'}`;

    // Newsletter section
    const nlTitle = document.querySelector('aside h3 .fa-envelope')?.closest('h3');
    if (nlTitle) nlTitle.innerHTML = `<i class="far fa-envelope text-brandRed mr-2"></i> ${translations[lang]['subscribe_title'] || 'Haberdar Ol'}`;

    // Daily digest
    const digestTitle = document.querySelector('#pinnedFeed')?.closest('div')?.querySelector('h3');
    if (digestTitle) digestTitle.innerHTML = `<i class="fas fa-magic mr-2"></i> ${translations[lang]['daily_digest'] || 'Günlük Özet'}`;

    // Search input placeholder
    const search = document.getElementById('searchInput');
    if (search) search.placeholder = translations[lang]['search_placeholder'] || 'Ara...';

    // Gazette controls
    const gazControlsTitle = document.querySelector('.gazette-controls-title');
    if (gazControlsTitle) gazControlsTitle.innerHTML = `<i class="fas fa-newspaper mr-2"></i>${translations[lang]['your_gazette'] || 'Kişisel Gazeteniz'}`;

    const gazPrintBtn = document.querySelector('.gazette-print-btn');
    if (gazPrintBtn) gazPrintBtn.innerHTML = `<i class="fas fa-print mr-2"></i>${translations[lang]['print_pdf'] || 'Yazdır / PDF'}`;

    const gazCloseBtn = document.querySelector('.gazette-close-btn');
    if (gazCloseBtn) gazCloseBtn.innerHTML = `<i class="fas fa-times mr-2"></i>${translations[lang]['close'] || 'Kapat'}`;

    // Re-render news if hydrateDOM available
    if (window.hydrateDOM) {
        window.hydrateDOM();
    }

    // İstisnasız TÜM metinleri çevir (EN seçildiyse)
    if (lang === 'en') {
        deepTranslateDom('en');
    }
}

// =========================================================================
// DEEPTRANSLATEDoM: SAYFADAKK TÜM GÖRÜNÜR METİNLERİ ÇEVİR
// Çevirmemesi gereken alanlar: script, style, input[type=hidden], <code>
// =========================================================================
const _domTranslationCache = {};

async function deepTranslateDom(targetLang) {
    if (targetLang === 'tr') return; // TR zaten orijinal, çevirme
    if (typeof translateTextFree !== 'function') return;

    // Çevrilmemesi gereken eleman türleri
    const SKIP_TAGS = new Set(['SCRIPT','STYLE','NOSCRIPT','CODE','PRE','IFRAME','SVG','IMG','VIDEO','AUDIO','INPUT','TEXTAREA','SELECT','OPTION','META','LINK','HEAD']);

    // Tüm text node'larını topla
    const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        {
            acceptNode(node) {
                const parent = node.parentElement;
                if (!parent) return NodeFilter.FILTER_REJECT;
                if (SKIP_TAGS.has(parent.tagName)) return NodeFilter.FILTER_REJECT;
                // Dinamik içerik alanlarını atla (haber başlıkları zaten ayrıca çevriliyor)
                if (parent.closest('#top-stories-grid, #global-news-slider, #article-modal, #compare-content-1, #compare-content-2, #rag-chat-messages, #trending-list, #latest-feed, #pinnedFeed')) return NodeFilter.FILTER_REJECT;
                // Sadece gerçekten metin olan (boşluk değil) düğümleri al
                const text = node.textContent.trim();
                if (!text || text.length < 2) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            }
        }
    );

    // Toplanan metin düğümlerini grupla
    const textNodes = [];
    let currentNode;
    while ((currentNode = walker.nextNode())) {
        textNodes.push(currentNode);
    }

    // Batch çevirisi: 15'erli gruplar halinde paralel çalıştır (Rate limit koruması)
    const BATCH = 15;
    for (let i = 0; i < textNodes.length; i += BATCH) {
        const batch = textNodes.slice(i, i + BATCH);
        await Promise.all(batch.map(async (node) => {
            const original = node.textContent.trim();
            if (!original || original.length < 2) return;
            // Cache: aynı metni tekrar çevirme
            const cacheKey = `${targetLang}:${original}`;
            if (_domTranslationCache[cacheKey]) {
                node.textContent = _domTranslationCache[cacheKey];
                return;
            }
            try {
                const translated = await translateTextFree(original, targetLang);
                if (translated && translated !== original) {
                    _domTranslationCache[cacheKey] = translated;
                    node.textContent = translated;
                }
            } catch(e) { /* sessizce atla */ }
        }));
    }
}

window.deepTranslateDom = deepTranslateDom;

function t(key) {
    return (translations[currentLang] && translations[currentLang][key]) || key;
}

// Sayfa yüklendiğinde dili ayarla
document.addEventListener('DOMContentLoaded', () => {
    const savedLang = localStorage.getItem('pref_lang') || 'tr';
    // Eski bir FR/ES tercihi kaydedilmişse TR'ye düşür
    const validLang = (savedLang === 'en') ? 'en' : 'tr';
    const langSelect = document.getElementById('lang-select');
    if (langSelect) {
        langSelect.value = validLang;
    }
    currentLang = validLang;
    window.currentLang = validLang;
    localStorage.setItem('pref_lang', validLang);
    // İlk set'te sadece statik elementleri güncelle — haberler henüz yüklenmedi
    setTimeout(() => setLanguage(validLang), 500);
});

function changeLanguage(lang) {
    setLanguage(lang);

    // TR'ye dönüşte: DOM çeviri cache'ini sıfırla ve sayfayı yenile
    // (DOM metin düğümleri değiştiğinden geri almak için reload en sağlıklı yol)
    if (lang === 'tr') {
        // Cache'i temizle
        Object.keys(_domTranslationCache).forEach(k => delete _domTranslationCache[k]);
        // LocalStorage haber cache'ini de temizle ki haberler TR çekilsin
        localStorage.removeItem('bilimhaber_global_news_tr');
        localStorage.removeItem('bilimhaber_global_news_en');
        localStorage.removeItem(`bilimhaber_recommend_user-1_en`);
        window.location.reload();
        return;
    }

    // 1. Dinamik Re-Render Katmanı - Global Haber Akışını Düşür ve Yeniden Çek (Çevirili)
    if (typeof refreshGlobalNewsForcefully === 'function') {
        refreshGlobalNewsForcefully();
    }

    // 2. Dinamik Re-Render Katmanı - AppState (Özel Haberler/Sabitlenenler) İçin Force Fetch
    if (typeof fetchRecommendations === 'function' && typeof AppState !== 'undefined') {
        fetchRecommendations(AppState.userId || 'user-1', true).then(articles => {
            if (articles && articles.length > 0) {
                AppState.setArticles(articles);
            }
        });
    }
    
    // 3. EĞER KULLANICI ŞU AN BİR HABER OKUYORSA (MODAL AÇIKSA), ON-THE-FLY ÇEVİR!
    if (typeof reTranslateActiveModal === 'function') {
        reTranslateActiveModal(lang);
    }
}

window.changeLanguage = changeLanguage;
window.t = t;
window.currentLang = currentLang;
