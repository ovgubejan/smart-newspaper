from __future__ import annotations

import hashlib
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from sqlalchemy import and_, or_

from comparison_seed_catalog import SEED_QUERY_PROFILES
from comparison_service import (
    CATEGORY_PRIORITY,
    EventCluster,
    build_comparison_analysis,
    build_event_clusters,
    comparison_service,
    compute_match,
    dedupe_articles,
    extract_event_features,
    jaccard_similarity,
    normalize_article,
    normalize_category_name,
    normalize_source_name,
    normalize_text,
    normalized_similarity,
    tokenize_text,
)
from db import SessionLocal
from models import (
    ComparisonEvent,
    ComparisonEventArticle,
    ComparisonFeedItem,
    ComparisonIngestion,
    ComparisonRecord,
    NewsArticle,
)
from news.cache_manager import news_cache
from rss_client import fetch_all_hurriyet_news, fetch_trt_news


NEW_BADGE_HOURS = 48
DEFAULT_SEED_TARGET = 30
SEED_CACHE_LIMIT = 1800
SCAN_CACHE_LIMIT = 1200
SUPPLEMENTAL_BUCKET_LIMIT = 80
SUPPLEMENTAL_NEIGHBOR_LIMIT = 12


class ComparisonFeedService:
    def ensure_seed_pool(self, target_count: int = DEFAULT_SEED_TARGET, language: str = "en") -> Dict[str, Any]:
        session = SessionLocal()
        try:
            self._expire_new_badges(session)
            current_count = self._visible_feed_count(session)
            if current_count >= target_count:
                return {"status": "ready", "count": current_count, "seeded": False}

            result = self.rebuild_seed_pool(
                target_count=target_count,
                language=language,
                run_type="bootstrap_seed",
                mark_new=False,
            )
            result["seeded"] = True
            return result
        finally:
            session.close()

    def rebuild_seed_pool(
        self,
        *,
        target_count: int = DEFAULT_SEED_TARGET,
        language: str = "en",
        run_type: str = "seed_rebuild",
        mark_new: bool = False,
        reset_existing: bool = False,
    ) -> Dict[str, Any]:
        session = SessionLocal()
        ingestion = ComparisonIngestion(run_type=run_type, source_provider="multi_provider", status="running")
        session.add(ingestion)
        session.commit()

        try:
            if reset_existing:
                self._reset_comparison_state(session)
            article_pool = self._collect_seed_articles(language=language, refresh=True, latest_only=False)
            clusters = self._select_ready_clusters(article_pool, target_count=target_count)
            persisted = self._persist_clusters(
                session,
                clusters[:target_count],
                mark_new=mark_new,
            )

            ingestion.fetched_count = len(article_pool)
            ingestion.matched_count = len(clusters)
            ingestion.inserted_count = persisted["insertedFeedItems"]
            ingestion.failed_count = 0
            ingestion.status = "completed"
            session.commit()

            return {
                "status": "completed",
                "fetchedCount": len(article_pool),
                "matchedCount": len(clusters),
                "insertedCount": persisted["insertedFeedItems"],
                "eventCount": persisted["eventCount"],
                "comparisonCount": persisted["comparisonCount"],
                "feedCount": self._visible_feed_count(session),
            }
        except Exception as exc:
            session.rollback()
            ingestion.status = "failed"
            ingestion.error_log = str(exc)
            session.commit()
            raise
        finally:
            session.close()

    def scan_latest(self, *, limit: int = 20, language: str = "en") -> Dict[str, Any]:
        session = SessionLocal()
        ingestion = ComparisonIngestion(run_type="scan_latest", source_provider="multi_provider", status="running")
        session.add(ingestion)
        session.commit()

        try:
            article_pool = self._collect_seed_articles(language=language, refresh=True, latest_only=True)
            clusters = self._select_ready_clusters(article_pool, target_count=max(limit * 2, 20))
            persisted = self._persist_clusters(session, clusters[:limit], mark_new=True)

            ingestion.fetched_count = len(article_pool)
            ingestion.matched_count = len(clusters)
            ingestion.inserted_count = persisted["insertedFeedItems"]
            ingestion.failed_count = 0
            ingestion.status = "completed"
            session.commit()

            return {
                "status": "completed",
                "fetchedCount": len(article_pool),
                "matchedCount": len(clusters),
                "insertedCount": persisted["insertedFeedItems"],
                "eventCount": persisted["eventCount"],
                "comparisonCount": persisted["comparisonCount"],
                "feedCount": self._visible_feed_count(session),
                "newEventIds": persisted["newEventIds"],
            }
        except Exception as exc:
            session.rollback()
            ingestion.status = "failed"
            ingestion.error_log = str(exc)
            session.commit()
            raise
        finally:
            session.close()

    def get_feed(self, *, limit: int = DEFAULT_SEED_TARGET) -> Dict[str, Any]:
        session = SessionLocal()
        try:
            self._expire_new_badges(session)

            rows = (
                session.query(ComparisonFeedItem, ComparisonEvent, ComparisonRecord)
                .join(ComparisonEvent, ComparisonEvent.id == ComparisonFeedItem.event_id)
                .join(ComparisonRecord, ComparisonRecord.id == ComparisonFeedItem.comparison_id)
                .filter(
                    ComparisonFeedItem.visible == True,
                    ComparisonEvent.comparison_ready == True,
                    ComparisonRecord.status == "ready",
                )
                .order_by(
                    ComparisonFeedItem.is_new.desc(),
                    ComparisonFeedItem.priority_score.desc(),
                    ComparisonFeedItem.created_at.desc(),
                )
                .limit(limit)
                .all()
            )

            comparisons = []
            now = datetime.now(timezone.utc)
            for feed_item, event, comparison in rows:
                left_article = session.query(NewsArticle).filter_by(id=comparison.source_a_article_id).first()
                right_article = session.query(NewsArticle).filter_by(id=comparison.source_b_article_id).first()
                if not left_article or not right_article:
                    continue

                left_payload = self._serialize_article(left_article)
                right_payload = self._serialize_article(right_article)
                analysis = self._deserialize_analysis(comparison, left_payload, right_payload)
                is_new_active = bool(feed_item.is_new and feed_item.new_until and feed_item.new_until.replace(tzinfo=timezone.utc) > now)

                comparisons.append({
                    "feedItemId": feed_item.id,
                    "eventId": event.id,
                    "eventTitle": event.canonical_title,
                    "category": event.category,
                    "eventType": event.event_type,
                    "sourceCount": event.source_count,
                    "matchScore": round(min(float(feed_item.priority_score or 0.0), 100.0), 1),
                    "isNew": is_new_active,
                    "newUntil": feed_item.new_until.isoformat() if feed_item.new_until else None,
                    "leftArticle": left_payload,
                    "rightArticle": right_payload,
                    "analysisEligible": True,
                    "analysis": analysis,
                })

            return {
                "generatedAt": datetime.now(timezone.utc).isoformat(),
                "count": len(comparisons),
                "comparisons": comparisons,
                "meta": {
                    "source": "database_feed",
                    "readyCount": self._visible_feed_count(session),
                }
            }
        finally:
            session.close()

    def _collect_seed_articles(self, *, language: str, refresh: bool, latest_only: bool) -> List[Dict[str, Any]]:
        comparison_service._ensure_seed_articles(force_refresh=refresh)

        cache_limit = SCAN_CACHE_LIMIT if latest_only else SEED_CACHE_LIMIT
        article_pool: List[Dict[str, Any]] = [
            normalize_article(item, provider="news_cache", source_type="rss")
            for item in news_cache.get_news(limit=cache_limit)
        ]

        # Reliable local feeds are added once as a stabilizer for exact multi-source matches.
        for item in fetch_trt_news()[:80]:
            article_pool.append(
                normalize_article(
                    item,
                    provider="trt_rss",
                    source_type="rss",
                    category_hint=getattr(item, "ai_category", None),
                )
            )

        for item in fetch_all_hurriyet_news()[:240]:
            article_pool.append(
                normalize_article(
                    item,
                    provider="hurriyet_rss",
                    source_type="rss",
                    category_hint=getattr(item, "ai_category", None),
                )
            )

        article_pool = dedupe_articles(article_pool)
        article_pool.sort(key=lambda article: article.get("publishedAt") or "", reverse=True)
        return article_pool

    def _select_ready_clusters(self, article_pool: Sequence[Dict[str, Any]], *, target_count: int) -> List[EventCluster]:
        base_clusters = build_event_clusters(list(article_pool))
        selected: List[EventCluster] = []
        seen_event_hashes = set()

        for quality_mode in ("strict", "balanced", "relaxed"):
            for cluster in base_clusters:
                if not self._cluster_matches_quality(cluster, quality_mode=quality_mode):
                    continue
                event_hash = self._make_event_hash(cluster)
                if event_hash in seen_event_hashes:
                    continue
                seen_event_hashes.add(event_hash)
                selected.append(cluster)
                if len(selected) >= target_count:
                    return selected[:target_count]

        supplemental_clusters = self._build_supplemental_title_clusters(article_pool)
        for cluster in supplemental_clusters:
            if not self._cluster_matches_quality(cluster, quality_mode="relaxed"):
                continue
            event_hash = self._make_event_hash(cluster)
            if event_hash in seen_event_hashes:
                continue
            seen_event_hashes.add(event_hash)
            selected.append(cluster)
            if len(selected) >= target_count:
                break

        selected.sort(
            key=lambda cluster: (
                float(cluster.max_pair_score or (cluster.best_pair or {}).get("score", 0.0)),
                len(cluster.sources),
                cluster.updated_at,
            ),
            reverse=True,
        )
        return selected[:target_count]

    def _cluster_matches_quality(self, cluster: EventCluster, *, quality_mode: str) -> bool:
        if not cluster.best_pair:
            return False

        score = float(cluster.best_pair.get("score") or 0.0)
        breakdown = cluster.best_pair.get("breakdown") or {}
        title_similarity = float(breakdown.get("titleSimilarity") or 0.0)
        keyword_overlap = float(breakdown.get("keywordOverlap") or 0.0)
        canonical_similarity = float(breakdown.get("canonicalSimilarity") or 0.0)
        actor_overlap = float(breakdown.get("actorOverlap") or 0.0)
        category_match = float(breakdown.get("categoryMatch") or 0.0)
        editorial_contrast = float(breakdown.get("editorialContrast") or 0.0)

        if quality_mode == "strict":
            return (
                score >= 78.0
                and title_similarity >= 0.42
                and (keyword_overlap >= 0.20 or canonical_similarity >= 0.70 or actor_overlap >= 0.50)
                and editorial_contrast >= 0.10
                and category_match >= 0.0
            )

        if quality_mode == "balanced":
            return (
                score >= 70.0
                and title_similarity >= 0.36
                and (keyword_overlap >= 0.18 or canonical_similarity >= 0.62 or actor_overlap >= 0.50)
                and editorial_contrast >= 0.06
            )

        return (
            score >= 66.0
            and title_similarity >= 0.32
            and (keyword_overlap >= 0.14 or canonical_similarity >= 0.58 or actor_overlap >= 0.50)
        )

    def _build_supplemental_title_clusters(self, article_pool: Sequence[Dict[str, Any]]) -> List[EventCluster]:
        feature_map = {}
        token_buckets: Dict[str, List[Any]] = {}

        for article in article_pool:
            title = str(article.get("title") or "").strip()
            if not title:
                continue

            feature = extract_event_features(article)
            feature_map[article["id"]] = feature
            title_tokens = [token for token in tokenize_text(title) if len(token) >= 4][:4]
            if not title_tokens:
                continue
            for token in title_tokens[:2]:
                token_buckets.setdefault(token, []).append(feature)

        candidate_clusters: Dict[str, EventCluster] = {}
        for bucket_features in token_buckets.values():
            bucket_features.sort(key=lambda item: item.published_at, reverse=True)
            limited_bucket = bucket_features[:SUPPLEMENTAL_BUCKET_LIMIT]

            for index, left in enumerate(limited_bucket):
                for right in limited_bucket[index + 1:index + 1 + SUPPLEMENTAL_NEIGHBOR_LIMIT]:
                    if left.article["sourceNormalized"] == right.article["sourceNormalized"]:
                        continue

                    time_hours = abs((left.published_at - right.published_at).total_seconds()) / 3600
                    if time_hours > 48:
                        continue

                    title_similarity = normalized_similarity(left.article["title"], right.article["title"])
                    title_keyword_overlap = jaccard_similarity(
                        tokenize_text(left.article["title"]),
                        tokenize_text(right.article["title"]),
                    )
                    if title_similarity < 0.58 or title_keyword_overlap < 0.22:
                        continue

                    match = compute_match(left, right)
                    pair_score = max(
                        float(match.get("score") or 0.0),
                        round(
                            (
                                title_similarity * 0.62
                                + title_keyword_overlap * 0.20
                                + (1.0 if left.category == right.category else 0.0) * 0.08
                                + max(0.0, 1 - (time_hours / 48.0)) * 0.10
                            ) * 100,
                            1,
                        ),
                    )
                    pair_score = min(pair_score, 100.0)
                    if pair_score < 72.0:
                        continue

                    event_hash = hashlib.md5(
                        "|".join([
                            normalize_category_name(left.category),
                            normalize_text(left.article["title"]),
                            normalize_text(right.article["title"]),
                            left.published_at.strftime("%Y-%m-%d"),
                        ]).encode("utf-8", errors="ignore")
                    ).hexdigest()

                    existing_cluster = candidate_clusters.get(event_hash)
                    if existing_cluster and pair_score <= existing_cluster.max_pair_score:
                        continue

                    cluster = EventCluster(
                        event_id=event_hash,
                        event_title=left.canonical_title if title_similarity < 0.86 else left.article["title"],
                        category=left.category,
                        event_type=left.event_type,
                    )
                    cluster.features = [left, right]
                    cluster.articles = [left.article, right.article]
                    cluster.sources = {left.article["source"], right.article["source"]}
                    cluster.updated_at = max(left.published_at, right.published_at)
                    cluster.max_pair_score = pair_score
                    cluster.best_pair = {
                        "left": left.article,
                        "right": right.article,
                        "score": pair_score,
                        "breakdown": {
                            **(match.get("breakdown") or {}),
                            "titleSimilarity": round(title_similarity, 3),
                            "keywordOverlap": round(title_keyword_overlap, 3),
                            "canonicalSimilarity": round(
                                normalized_similarity(left.canonical_title, right.canonical_title),
                                3,
                            ),
                            "categoryMatch": 1.0 if left.category == right.category else 0.0,
                        },
                    }
                    candidate_clusters[event_hash] = cluster

        return sorted(
            candidate_clusters.values(),
            key=lambda cluster: (cluster.max_pair_score, cluster.updated_at),
            reverse=True,
        )

    def _preferred_event_title(self, cluster: EventCluster) -> str:
        best_pair = cluster.best_pair or {}
        left_title = str((best_pair.get("left") or {}).get("title") or "").strip()
        right_title = str((best_pair.get("right") or {}).get("title") or "").strip()
        cluster_title = str(cluster.event_title or "").strip()

        if not cluster_title:
            return left_title or right_title or "Comparison Event"

        normalized_cluster_title = normalize_text(cluster_title)
        looks_generic = (
            "reported" in normalized_cluster_title
            or "update" in normalized_cluster_title
            or normalized_cluster_title.endswith(" decision")
            or len(normalized_cluster_title.split()) < 4
        )
        title_alignment = max(
            normalized_similarity(cluster_title, left_title),
            normalized_similarity(cluster_title, right_title),
        )
        if not looks_generic and title_alignment >= 0.45:
            return cluster_title

        left_tokens = tokenize_text(left_title)
        right_tokens = tokenize_text(right_title)
        if left_title and len(left_tokens) >= len(right_tokens):
            return left_title
        if right_title:
            return right_title
        return cluster_title

    def get_event_articles(self, event_id: str) -> Dict[str, Any]:
        session = SessionLocal()
        try:
            event = session.query(ComparisonEvent).filter_by(id=event_id).first()
            if not event:
                return {"eventId": event_id, "articles": []}

            links = (
                session.query(ComparisonEventArticle, NewsArticle)
                .join(NewsArticle, NewsArticle.id == ComparisonEventArticle.article_id)
                .filter(ComparisonEventArticle.event_id == event_id)
                .order_by(ComparisonEventArticle.similarity_score.desc())
                .all()
            )

            return {
                "eventId": event.id,
                "eventTitle": event.canonical_title,
                "category": event.category,
                "articles": [self._serialize_article(article) for _, article in links],
            }
        finally:
            session.close()

    def get_event_comparison(self, event_id: str) -> Dict[str, Any]:
        session = SessionLocal()
        try:
            comparison = (
                session.query(ComparisonRecord)
                .filter(ComparisonRecord.event_id == event_id, ComparisonRecord.status == "ready")
                .order_by(ComparisonRecord.updated_at.desc(), ComparisonRecord.created_at.desc())
                .first()
            )
            if not comparison:
                return {"eventId": event_id, "analysisEligible": False, "analysis": None}

            left_article = session.query(NewsArticle).filter_by(id=comparison.source_a_article_id).first()
            right_article = session.query(NewsArticle).filter_by(id=comparison.source_b_article_id).first()
            if not left_article or not right_article:
                return {"eventId": event_id, "analysisEligible": False, "analysis": None}

            left_payload = self._serialize_article(left_article)
            right_payload = self._serialize_article(right_article)
            return {
                "eventId": event_id,
                "analysisEligible": True,
                "analysis": self._deserialize_analysis(comparison, left_payload, right_payload),
                "leftArticle": left_payload,
                "rightArticle": right_payload,
            }
        finally:
            session.close()

    def _persist_clusters(self, session, clusters: Sequence[Any], *, mark_new: bool) -> Dict[str, Any]:
        inserted_feed_items = 0
        comparison_count = 0
        event_count = 0
        new_event_ids: List[str] = []

        for cluster in clusters:
            if not cluster.best_pair:
                continue

            event_hash = self._make_event_hash(cluster)
            event = session.query(ComparisonEvent).filter_by(event_hash=event_hash).first()
            is_fresh_event = event is None

            if not event:
                event = ComparisonEvent(
                    event_hash=event_hash,
                    canonical_title=self._preferred_event_title(cluster),
                )
                session.add(event)
                event_count += 1

            main_entities = self._cluster_main_entities(cluster)
            event.canonical_title = self._preferred_event_title(cluster)
            event.canonical_summary = cluster.best_pair["breakdown"].__repr__()
            event.category = cluster.category
            event.event_type = cluster.event_type
            event.main_entities = main_entities
            event.main_location = self._cluster_main_location(cluster)
            event.start_time = min((feature.published_at for feature in cluster.features), default=datetime.now(timezone.utc))
            event.end_time = max((feature.published_at for feature in cluster.features), default=datetime.now(timezone.utc))
            event.source_count = len(cluster.sources)
            event.comparison_ready = len(cluster.sources) >= 2
            event.updated_at = datetime.utcnow()
            session.flush()

            article_models = {}
            for feature in cluster.features:
                article_model = self._upsert_article(session, feature.article, event.id)
                article_models[feature.article["id"]] = article_model
                self._upsert_event_article(
                    session,
                    event_id=event.id,
                    article_id=article_model.id,
                    source=feature.article["source"],
                    similarity_score=cluster.max_pair_score or cluster.best_pair["score"],
                    is_primary_source=feature.article["id"] in {
                        cluster.best_pair["left"]["id"],
                        cluster.best_pair["right"]["id"],
                    },
                )

            left_model = article_models.get(cluster.best_pair["left"]["id"])
            right_model = article_models.get(cluster.best_pair["right"]["id"])
            if not left_model or not right_model:
                continue

            comparison = (
                session.query(ComparisonRecord)
                .filter_by(event_id=event.id, source_a_article_id=left_model.id, source_b_article_id=right_model.id)
                .first()
            )
            if not comparison:
                comparison = ComparisonRecord(
                    event_id=event.id,
                    source_a_article_id=left_model.id,
                    source_b_article_id=right_model.id,
                )
                session.add(comparison)
                session.flush()
                comparison_count += 1

            analysis = build_comparison_analysis(cluster.best_pair["left"], cluster.best_pair["right"])
            comparison.ai_summary = analysis.get("overallSummary")
            comparison.title_comparison = self._pair_text(analysis.get("headlineComparison"))
            comparison.tone_comparison = self._pair_text(analysis.get("toneComparison"))
            comparison.focus_comparison = self._pair_text(analysis.get("focusComparison"))
            comparison.actor_framing = self._pair_text(analysis.get("actorPresentation"))
            comparison.missing_points = self._pair_text(analysis.get("missingOrUnderplayed"))
            comparison.status = "ready"
            comparison.updated_at = datetime.utcnow()

            feed_item = session.query(ComparisonFeedItem).filter_by(event_id=event.id).first()
            if not feed_item:
                feed_item = ComparisonFeedItem(event_id=event.id, comparison_id=comparison.id)
                session.add(feed_item)
                session.flush()
                inserted_feed_items += 1
                if mark_new:
                    new_event_ids.append(event.id)

            feed_item.comparison_id = comparison.id
            feed_item.priority_score = min(float(cluster.max_pair_score or cluster.best_pair["score"]), 100.0)
            feed_item.visible = True

            if mark_new and is_fresh_event:
                feed_item.is_new = True
                feed_item.new_until = datetime.utcnow() + timedelta(hours=NEW_BADGE_HOURS)
            elif not feed_item.new_until:
                feed_item.is_new = False
                feed_item.new_until = None

            session.flush()

        session.commit()
        return {
            "insertedFeedItems": inserted_feed_items,
            "comparisonCount": comparison_count,
            "eventCount": event_count,
            "newEventIds": new_event_ids,
        }

    def _upsert_article(self, session, article_payload: Dict[str, Any], event_id: str) -> NewsArticle:
        normalized = normalize_article(article_payload, provider=article_payload.get("provider") or "persisted", source_type=article_payload.get("sourceType") or "api")
        normalized_hash = self._make_article_hash(normalized)

        article = (
            session.query(NewsArticle)
            .filter(
                or_(
                    NewsArticle.normalized_hash == normalized_hash,
                    NewsArticle.url_hash == normalized_hash,
                    NewsArticle.url == normalized.get("url"),
                )
            )
            .first()
        )

        if not article:
            article = NewsArticle(url_hash=normalized_hash, normalized_hash=normalized_hash)
            session.add(article)

        article.normalized_hash = normalized_hash
        article.title = normalized.get("title") or article.title or "Untitled"
        article.url = normalized.get("url") or article.url or ""
        article.source = normalized.get("source") or article.source or "Unknown"
        article.source_type = normalized.get("sourceType")
        article.content_text = normalized.get("content") or normalized.get("summary") or article.content_text or ""
        article.language = normalized.get("language") or article.language or "en"
        article.published_at = self._parse_dt(normalized.get("publishedAt"))
        article.author = normalized.get("author")
        article.category = normalized.get("category")
        article.ai_category = normalized.get("category")
        article.country = normalized.get("country")
        article.image_url = normalized.get("imageUrl")
        article.keywords = normalized.get("keywords")
        article.entities_json = normalized.get("entities")
        article.ai_tags = normalized.get("keywords")
        article.ai_summary = normalized.get("summary") or normalized.get("ai_summary")
        article.event_id = event_id
        article.updated_at = datetime.utcnow()
        if not article.created_at:
            article.created_at = datetime.utcnow()
        session.flush()
        return article

    def _upsert_event_article(
        self,
        session,
        *,
        event_id: str,
        article_id: str,
        source: str,
        similarity_score: float,
        is_primary_source: bool,
    ) -> None:
        record = (
            session.query(ComparisonEventArticle)
            .filter_by(event_id=event_id, article_id=article_id)
            .first()
        )
        if not record:
            record = ComparisonEventArticle(event_id=event_id, article_id=article_id, source=source)
            session.add(record)
        record.source = source
        record.similarity_score = float(similarity_score)
        record.is_primary_source = is_primary_source

    def _reset_comparison_state(self, session) -> None:
        session.query(ComparisonFeedItem).delete()
        session.query(ComparisonRecord).delete()
        session.query(ComparisonEventArticle).delete()
        session.query(ComparisonEvent).delete()
        session.query(NewsArticle).filter(NewsArticle.event_id != None).update({"event_id": None})
        session.commit()

    def _visible_feed_count(self, session) -> int:
        return (
            session.query(ComparisonFeedItem)
            .filter(ComparisonFeedItem.visible == True)
            .count()
        )

    def _expire_new_badges(self, session) -> None:
        now = datetime.utcnow()
        expired = (
            session.query(ComparisonFeedItem)
            .filter(
                ComparisonFeedItem.is_new == True,
                ComparisonFeedItem.new_until != None,
                ComparisonFeedItem.new_until < now,
            )
            .all()
        )
        for item in expired:
            item.is_new = False
        if expired:
            session.commit()

    def _serialize_article(self, article: NewsArticle) -> Dict[str, Any]:
        return {
            "id": article.id,
            "source": article.source,
            "sourceType": article.source_type,
            "title": article.title,
            "summary": article.ai_summary or article.content_text,
            "content": article.content_text,
            "author": article.author,
            "publishedAt": article.published_at.isoformat() if article.published_at else None,
            "category": article.category or article.ai_category,
            "language": article.language,
            "country": article.country,
            "url": article.url,
            "imageUrl": article.image_url,
            "keywords": article.keywords or article.ai_tags or [],
            "entities": article.entities_json or [],
            "eventId": article.event_id,
        }

    def _deserialize_analysis(self, comparison: ComparisonRecord, left_article: Dict[str, Any], right_article: Dict[str, Any]) -> Dict[str, Any]:
        def section_from_text(blob: Optional[str]) -> Dict[str, str]:
            if not blob:
                return {"sourceA": "", "sourceB": ""}
            left_text, _, right_text = blob.partition(" || ")
            return {"sourceA": left_text.strip(), "sourceB": right_text.strip()}

        analysis = {
            "headlineComparison": section_from_text(comparison.title_comparison),
            "focusComparison": section_from_text(comparison.focus_comparison),
            "toneComparison": section_from_text(comparison.tone_comparison),
            "actorPresentation": section_from_text(comparison.actor_framing),
            "missingOrUnderplayed": section_from_text(comparison.missing_points),
            "overallSummary": comparison.ai_summary or "",
        }
        if not analysis["overallSummary"]:
            analysis = build_comparison_analysis(left_article, right_article)
        return analysis

    def _pair_text(self, value: Optional[Dict[str, str]]) -> str:
        if not value:
            return ""
        return f"{value.get('sourceA', '').strip()} || {value.get('sourceB', '').strip()}"

    def _make_article_hash(self, article: Dict[str, Any]) -> str:
        base = "|".join([
            normalize_source_name(article.get("source")),
            normalize_text(article.get("url") or ""),
            normalize_text(article.get("title") or ""),
            (article.get("publishedAt") or "")[:13],
        ])
        return hashlib.md5(base.encode("utf-8", errors="ignore")).hexdigest()

    def _make_event_hash(self, cluster: Any) -> str:
        entities = self._cluster_main_entities(cluster)
        time_bucket = min((feature.published_at for feature in cluster.features), default=datetime.now(timezone.utc)).strftime("%Y-%m-%d")
        left_article = (cluster.best_pair or {}).get("left") or {}
        right_article = (cluster.best_pair or {}).get("right") or {}
        pair_title_key = "|".join(sorted([
            normalize_text(left_article.get("title") or ""),
            normalize_text(right_article.get("title") or ""),
        ]))
        pair_source_key = "|".join(sorted([
            normalize_source_name(left_article.get("source")),
            normalize_source_name(right_article.get("source")),
        ]))
        base = "|".join([
            normalize_category_name(cluster.category),
            normalize_text(cluster.event_type or ""),
            pair_title_key or normalize_text(cluster.event_title or ""),
            pair_source_key,
            "|".join(sorted(normalize_text(entity) for entity in entities[:4])),
            time_bucket,
        ])
        return hashlib.md5(base.encode("utf-8", errors="ignore")).hexdigest()

    def _cluster_main_entities(self, cluster: Any) -> List[str]:
        names = []
        for feature in cluster.features:
            names.extend(feature.actor_entities or [])
            names.extend(feature.place_entities or [])
        deduped = []
        seen = set()
        for name in names:
            key = normalize_text(name)
            if not key or key in seen:
                continue
            seen.add(key)
            deduped.append(name)
        return deduped[:8]

    def _cluster_main_location(self, cluster: Any) -> Optional[str]:
        for feature in cluster.features:
            if feature.place_entities:
                return feature.place_entities[0]
        return None

    def _parse_dt(self, value: Optional[str]) -> Optional[datetime]:
        if not value:
            return None
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00")).replace(tzinfo=None)
        except Exception:
            return None


comparison_feed_service = ComparisonFeedService()
