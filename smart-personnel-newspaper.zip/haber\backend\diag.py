import uuid
from typing import List, Dict
from datetime import datetime
import enum
import sqlalchemy
from sqlalchemy import Column, String, Text, Boolean, DateTime, JSON, Integer, ForeignKey, Date
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class AppUser(Base):
    __tablename__ = 'users_test'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String(50), nullable=False, unique=True)
    joined_at = Column(DateTime, default=datetime.utcnow)

print("DIAG SUCCESS: AppUser created")
