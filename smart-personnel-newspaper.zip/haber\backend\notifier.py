# notifier.py
import os

class NotificationService:
    """(FR-6.2) Notification service architecture (handling push/email triggers)"""
    
    def __init__(self):
        # Gelecekte gerçek SMTP veya FCM Push ekleneceği düşünülerek kurgulandı.
        self.smtp_host = os.environ.get("SMTP_HOST", "mock.smtp.local")
        self.push_apiKey = os.environ.get("FCM_API_KEY", "mock_key")

    def send_email_notification(self, user_email: str, subject: str, message: str):
        # Mock Gerçekleme
        print(f"\n[EMAIL_SERVICE] Gonderiliyor -> {user_email}")
        print(f"Konu: {subject}")
        print(f"Mesaj: {message}")
        print("[EMAIL_SERVICE] Basarili.\n")

    def send_push_notification(self, device_token: str, title: str, body: str):
        # Mock Push
        print(f"\n[PUSH_SERVICE] Akilli Telefona İletiliyor -> {device_token}")
        print(f"Push Title: {title}")
        print(f"Push Body: {body}")
        print("[PUSH_SERVICE] Basarili.\n")

# Global singleton
notifier = NotificationService()
