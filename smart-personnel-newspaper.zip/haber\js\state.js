// js/state.js

/**
 * Global App State
 * Manages the current category, search keywords, pinned widgets, and loaded articles.
 */
const AppState = {
    userId: "demo-user-123", // Single user prototype
    currentCategory: "Home",
    searchQuery: "",
    articles: [],
    pinnedCategories: JSON.parse(localStorage.getItem('news_pinned_widgets')) || [],
    userPrefs: [], // Kullanıcının seçtiği konular (auth.js tarafından set edilir)
    
    // Subscriber pattern (Notify UI when state changes)
    listeners: [],
    subscribe(callback) {
        this.listeners.push(callback);
    },
    notify() {
        this.listeners.forEach(cb => cb());
    },

    setCategory(cat) {
        if(this.currentCategory !== cat) {
            this.currentCategory = cat;
            this.notify();
        }
    },

    setSearchQuery(q) {
        this.searchQuery = q.toLowerCase();
        this.notify();
    },

    setArticles(data) {
        this.articles = data;
        this.notify();
    },

    togglePin(cat) {
        if(this.pinnedCategories.includes(cat)) {
            this.pinnedCategories = this.pinnedCategories.filter(c => c !== cat);
        } else {
            this.pinnedCategories.push(cat);
        }
        localStorage.setItem('news_pinned_widgets', JSON.stringify(this.pinnedCategories));
        this.notify();
    }
};
