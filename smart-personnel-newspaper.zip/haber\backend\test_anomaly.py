from datetime import datetime, timedelta
from db import db
from models import Entity, ArticleEntity, EntityTypeEnum
import uuid

# 1. Create a mock entity
now = datetime.utcnow()
ent = Entity(name="Çip Krizi (DEMO)", entity_type=EntityTypeEnum.EVENT)
db.session.add(ent)
db.session.commit()

# 2. Add past occurrences (Small baseline = 1 per day)
for i in range(2, 7):
    art = ArticleEntity(article_id=str(uuid.uuid4()), entity_id=ent.id, count=1, created_at=now - timedelta(days=i))
    db.session.add(art)

# 3. SPIKE: Add 4 occurrences in last 12 hours
for _ in range(4):
    art = ArticleEntity(article_id=str(uuid.uuid4()), entity_id=ent.id, count=1, created_at=now - timedelta(hours=6))
    db.session.add(art)

db.session.commit()

print("Veritabanina yapay anomali (spike) datası enjekte edildi. Motor çalıştırılıyor...\n")

# Analiz motorunu çalıştır
from analytics import analyzer
spikes = analyzer.analyze_trends()
print(f"Toplam tespit edilen patlamalar: {len(spikes)}")
