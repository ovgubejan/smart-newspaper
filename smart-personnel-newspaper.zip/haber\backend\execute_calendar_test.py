# execute_calendar_test.py
import os
import sys

# Ensure backend modules can be imported
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from calendar_parser import CalendarParser
from tasks import check_upcoming_events
from db import SessionLocal
from models import InstitutionalEvent
from datetime import datetime, timedelta

def run_test():
    print("\n--- 1. PARSING iCAL ---")
    parser = CalendarParser(use_mock=True)
    parser.fetch_and_parse()
    
    # Veritabanında zamanları manuel olarak manipüle edelim ki bildirim triggellensin.
    print("\n--- 2. DATABASE TIME MANIPULATION (For Notification Test) ---")
    db = SessionLocal()
    events = db.query(InstitutionalEvent).all()
    for e in events:
        # Etkinliklerin zamanını dünden bugüne alalım (yaklaşmış gibi gösterelim)
        e.start_time = datetime.utcnow() + timedelta(hours=5) 
    db.commit()
    db.close()
    
    print("\n--- 3. TRIGGERING CHRON ALERT TASK ---")
    # Call the celery task synchronously
    check_upcoming_events()
    print("Test passed successfully.")

if __name__ == "__main__":
    run_test()
