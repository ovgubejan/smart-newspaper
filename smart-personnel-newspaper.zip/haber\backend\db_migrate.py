import sqlite3
import os

db_path = "news.db"
if not os.path.exists(db_path):
    print("news.db not found here.")
else:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute("ALTER TABLE news_articles ADD COLUMN sentiment_score FLOAT")
        conn.commit()
        print("Successfully added sentiment_score column.")
    except sqlite3.OperationalError as e:
        print(f"OperationalError: {e} (Column might already exist)")
    conn.close()

from db import engine
from models import Base
Base.metadata.create_all(engine)
print("Successfully created missing SQLAlchemy models/tables.")
