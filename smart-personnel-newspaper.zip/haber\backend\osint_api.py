from fastapi import APIRouter
from pydantic import BaseModel
import asyncio
from typing import List
from datetime import datetime, timedelta
from sqlalchemy import func

try:
    import diskcache
except ImportError:
    diskcache = None

# OSINT Router Configuration
osint_router = APIRouter(
    prefix="/api/v1/osint",
    tags=["OSINT Operations"]
)

if diskcache is not None:
    cache = diskcache.Cache('./.cache')
else:
    class _MemoryCache:
        def __init__(self):
            self._store = {}

        def get(self, key):
            record = self._store.get(key)
            if not record:
                return None
            value, expires_at = record
            if expires_at and expires_at < datetime.utcnow():
                self._store.pop(key, None)
                return None
            return value

        def set(self, key, value, expire=0):
            expires_at = None
            if expire:
                expires_at = datetime.utcnow() + timedelta(seconds=expire)
            self._store[key] = (value, expires_at)

    cache = _MemoryCache()

class OSINTTriggerRequest(BaseModel):
    sources: List[str]
    language: str = "en"

@osint_router.post("/trigger")
async def trigger_osint_ingestion(req: OSINTTriggerRequest):
    """Manuel olarak hedef URL'lerden anında veri toplar (OSINT Trigger)."""
    from fetcher import fetch_global_news_async
    
    results = {}
    total_added = 0
    for source in req.sources:
        try:
            # fetcher async olduğu için doğrudan await yapabiliriz.
            added = await fetch_global_news_async(source, language=req.language)
            results[source] = {"status": "success", "added": added}
            total_added += added
        except Exception as e:
            results[source] = {"status": "error", "message": str(e)}
            
    return {"message": "OSINT Data Pipeline triggered successfully.", "total_added": total_added, "results": results}

@osint_router.get("/stats")
async def osint_statistics():
    """OSINT Veritabanı Toplam Veri İstatistiği"""
    from db import db
    all_dtos = db.get_all_dtos()
    
    return {
        "status": "active",
        "total_crawled_articles": len(all_dtos)
    }

# ==========================================
# DASHBOARD API ROUTES (Heatmap & Trends)
# ==========================================

@osint_router.get("/heatmap")
async def get_osint_heatmap():
    """Son 48 saat içindeki LOCATION varlıklarının harita frekansını döner."""
    cache_key = "osint_heatmap_data"
    cached_data = cache.get(cache_key)
    if cached_data:
        return {"status": "success", "source": "cache", "data": cached_data}

    from db import db
    from models import Entity, ArticleEntity, EntityTypeEnum
    
    t_minus_48h = datetime.utcnow() - timedelta(hours=48)
    
    heatmap_data = db.session.query(
        Entity.name,
        func.sum(ArticleEntity.count).label('frequency')
    ).join(ArticleEntity, Entity.id == ArticleEntity.entity_id).filter(
        Entity.entity_type == EntityTypeEnum.LOCATION,
        ArticleEntity.created_at >= t_minus_48h
    ).group_by(Entity.name).order_by(func.sum(ArticleEntity.count).desc()).limit(50).all()
    
    result = [{"location": row[0], "frequency": row[1]} for row in heatmap_data]
    
    cache.set(cache_key, result, expire=900) # 15 min TTL
    return {"status": "success", "source": "db", "data": result}

@osint_router.get("/trends/active")
async def get_active_trends():
    """Sistemde aktif olarak Peak yapan Kelebek Etkisi trendlerini listeler."""
    cache_key = "osint_active_trends"
    cached_data = cache.get(cache_key)
    if cached_data:
        return {"status": "success", "source": "cache", "data": cached_data}

    from db import db
    from models import Entity, DetectedTrends
    
    active_peaks = db.session.query(
        DetectedTrends.peak_time,
        DetectedTrends.severity_score,
        DetectedTrends.related_articles,
        Entity.name,
        Entity.entity_type
    ).join(Entity, DetectedTrends.entity_id == Entity.id).filter(
        DetectedTrends.is_active == True
    ).order_by(DetectedTrends.severity_score.desc()).limit(20).all()
    
    result = []
    for row in active_peaks:
        result.append({
            "entity": row.name,
            "entity_type": row.entity_type.value,
            "peak_time": row.peak_time.isoformat() if row.peak_time else None,
            "severity_score": row.severity_score,
            "related_articles_count": len(row.related_articles) if row.related_articles else 0
        })
        
    cache.set(cache_key, result, expire=300) # 5 min TTL
    return {"status": "success", "source": "db", "data": result}

@osint_router.get("/entity/{entity_id}/timeline")
async def get_entity_timeline(entity_id: int):
    """Belirli bir varlığın son 7 güne ait Time-Series (Zaman serisi) grafiğini çizer."""
    cache_key = f"osint_timeline_{entity_id}"
    cached_data = cache.get(cache_key)
    if cached_data:
        return {"status": "success", "source": "cache", "data": cached_data}

    from db import db
    from models import ArticleEntity
    
    t_minus_7d = datetime.utcnow() - timedelta(days=7)
    
    records = db.session.query(
        ArticleEntity.created_at,
        ArticleEntity.count
    ).filter(
        ArticleEntity.entity_id == entity_id,
        ArticleEntity.created_at >= t_minus_7d
    ).all()
    
    timeline_dict = {}
    for r in records:
        if r.created_at:
            day_str = r.created_at.strftime("%Y-%m-%d")
            timeline_dict[day_str] = timeline_dict.get(day_str, 0) + r.count
        
    sorted_dict = sorted(timeline_dict.items(), key=lambda x: x[0])
    result = [{"date": k, "count": v} for k, v in sorted_dict]
    
    cache.set(cache_key, result, expire=1800) # 30dk TTL
    return {"status": "success", "source": "db", "data": result}
