'use strict';

window._CE = {
    pairs: [],
    activePairIdx: 0,
    isLoading: false,
    isScanning: false,
    hasInit: false,
    lastPayload: null,
    lastStatusText: '',
    lastScanMessage: '',
};

window.initComparisonTab = async function(options = {}) {
    const wrap = document.getElementById('comp-tab-content');
    const forceReload = !!options.forceReload;
    if (!wrap || window._CE.isLoading) return;

    if (window._CE.hasInit && !forceReload && window._CE.pairs.length > 0) {
        _renderPairList();
        return;
    }

    window._CE.isLoading = true;
    _showGlobalLoading(wrap, 'Hazir comparison havuzu yukleniyor...');

    try {
        let payload = await _fetchComparisonFeed({ limit: 30, forceRefresh: forceReload });
        let comparisons = _extractComparisons(payload);

        if (comparisons.length === 0) {
            _showGlobalLoading(wrap, 'Hazir feed bos. Database comparison havuzu yeniden kuruluyor...');
            payload = await _rebuildComparisonFeed({ targetCount: 30 });
            comparisons = _extractComparisons(payload);
        }

        window._CE.pairs = comparisons;
        window._CE.activePairIdx = 0;
        window._CE.hasInit = true;
        window._CE.lastPayload = payload;

        if (comparisons.length > 0) {
            _renderPairList();
        } else {
            _renderRecoveryState(wrap, 'Hazir comparison havuzu henuz olusmadi. Rebuild akisi calisiyor.');
        }
    } catch (err) {
        console.error('[CE] initComparisonTab error:', err);
        _renderRecoveryState(wrap, err?.message || 'Beklenmeyen bir hata olustu.');
    } finally {
        window._CE.isLoading = false;
    }
};

function _extractComparisons(payload) {
    const items = Array.isArray(payload?.comparisons) ? payload.comparisons : [];
    return items.filter((item) => {
        const left = item?.leftArticle;
        const right = item?.rightArticle;
        return !!(item?.eventId && left?.source && right?.source && left?.url && right?.url);
    });
}

async function _fetchComparisonFeed(options = {}) {
    if (typeof fetchComparisonFeedApi === 'function') {
        return fetchComparisonFeedApi(options);
    }

    const params = new URLSearchParams();
    params.set('limit', String(options.limit || 30));
    params.set('lang', window.currentLang || localStorage.getItem('pref_lang') || 'tr');
    if (options.forceRefresh) params.set('force_refresh', 'true');

    const response = await fetch(`${API_BASE_URL}/comparison-feed?${params.toString()}`);
    if (!response.ok) return { comparisons: [] };
    return response.json();
}

async function _rebuildComparisonFeed(options = {}) {
    if (typeof rebuildComparisonFeedApi === 'function') {
        return rebuildComparisonFeedApi({
            targetCount: options.targetCount || 30,
            language: window.currentLang || localStorage.getItem('pref_lang') || 'tr',
        });
    }

    const response = await fetch(`${API_BASE_URL}/comparison/rebuild`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            target_count: options.targetCount || 30,
            language: window.currentLang || localStorage.getItem('pref_lang') || 'tr',
        })
    });
    if (!response.ok) return { comparisons: [] };
    return response.json();
}

async function _scanLatestComparisons(options = {}) {
    if (typeof scanLatestComparisonsApi === 'function') {
        return scanLatestComparisonsApi({
            language: window.currentLang || localStorage.getItem('pref_lang') || 'tr',
            limit: options.limit || 20,
        });
    }

    const response = await fetch(`${API_BASE_URL}/comparison/scan-latest`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            category: null,
            keywords: [],
            language: window.currentLang || localStorage.getItem('pref_lang') || 'tr',
            limit: options.limit || 20,
        })
    });
    if (!response.ok) return { comparisons: [] };
    return response.json();
}

async function _fetchEventComparison(eventId) {
    if (typeof fetchEventComparisonApi === 'function') {
        return fetchEventComparisonApi(eventId);
    }
    const response = await fetch(`${API_BASE_URL}/events/${encodeURIComponent(eventId)}/comparison`);
    if (!response.ok) return { analysisEligible: false, analysis: null };
    return response.json();
}

window.scanLatestComparisonFeed = async function() {
    if (window._CE.isScanning) return;

    window._CE.isScanning = true;
    window._CE.lastScanMessage = 'Yeni comparison-ready olaylar taraniyor...';
    _renderPairList();

    try {
        const payload = await _scanLatestComparisons({ limit: 20 });
        const comparisons = _extractComparisons(payload);
        if (comparisons.length > 0) {
            window._CE.pairs = comparisons;
            window._CE.activePairIdx = 0;
        }
        const inserted = Number(payload?.scanResult?.insertedCount || 0);
        window._CE.lastScanMessage = inserted > 0
            ? `Tarama tamamlandi. ${inserted} yeni comparison kaydi eklendi ve yesil badge ile isaretlendi.`
            : 'Tarama tamamlandi. Yeni comparison-ready kayit bulunamadi.';
    } catch (err) {
        console.warn('[CE] scanLatestComparisonFeed error:', err);
        window._CE.lastScanMessage = 'Tarama sirasinda hata olustu. Hazir database havuzu ekranda tutuluyor.';
    } finally {
        window._CE.isScanning = false;
        _renderPairList();
    }
};

function _showGlobalLoading(container, message) {
    window._CE.lastStatusText = message;
    container.innerHTML = `
        <div class="comp-loading-state">
            <div class="comp-loading-inner">
                <div class="comp-loading-orbit">
                    <div class="comp-loading-planet"></div>
                    <div class="comp-loading-moon"></div>
                </div>
                <p class="comp-loading-msg">${_escHtml(message)}</p>
                <p class="comp-loading-sub">Sayfa once database icindeki hazir comparison havuzunu kullanir.</p>
            </div>
        </div>`;
}

function _renderPairList() {
    const wrap = document.getElementById('comp-tab-content');
    const pairs = window._CE.pairs;
    if (!wrap) return;

    if (!pairs || pairs.length === 0) {
        _renderRecoveryState(wrap);
        return;
    }

    wrap.innerHTML = `
        <div class="comp-page-grid" id="comp-page-grid">
            <aside class="comp-pair-list" id="comp-pair-list">
                <div class="comp-pair-list-header" style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <i class="fas fa-layer-group"></i>
                        <span>${pairs.length} dogrulanmis karsilastirma</span>
                    </div>
                    <button class="comp-refresh-btn" onclick="window.scanLatestComparisonFeed()" ${window._CE.isScanning ? 'disabled' : ''}>
                        <i class="fas ${window._CE.isScanning ? 'fa-circle-notch fa-spin' : 'fa-satellite-dish'}"></i>
                        ${window._CE.isScanning ? 'Taranıyor...' : 'Yenilerini Tara'}
                    </button>
                </div>
                ${window._CE.lastScanMessage ? `<div class="comp-ai-raw" style="margin:12px 0;">${_escHtml(window._CE.lastScanMessage)}</div>` : ''}
                <div class="comp-pair-list-items" id="comp-pair-items">
                    ${pairs.map((pair, idx) => _renderPairCard(pair, idx)).join('')}
                </div>
            </aside>

            <main class="comp-detail-area" id="comp-detail-area">
                <div id="comp-detail-inner"></div>
            </main>
        </div>`;

    window.openComparisonPair(window._CE.activePairIdx || 0);
}

function _renderPairCard(pair, idx) {
    const leftSource = _formatDisplaySource(pair?.leftArticle?.source);
    const rightSource = _formatDisplaySource(pair?.rightArticle?.source);
    const title = pair?.eventTitle || pair?.leftArticle?.title || 'Dogrulanmis olay';
    const topic = pair?.category || 'World';
    const score = Number(pair?.matchScore || 0).toFixed(1);
    const isActive = idx === window._CE.activePairIdx;

    return `
        <div class="comp-pair-card ${isActive ? 'comp-pair-card--active' : ''}"
             id="comp-pair-card-${idx}"
             onclick="window.openComparisonPair(${idx})">
            <div class="comp-pair-card-cat">
                <i class="fas ${_getCatIcon(topic)}"></i>
                <span>${_escHtml(topic)}</span>
                <span class="comp-pair-card-score">Skor: ${score}</span>
            </div>
            <p class="comp-pair-card-title line-clamp-2">
                ${_escHtml(title)}
                ${_isNewPair(pair) ? `<span style="display:inline-flex;align-items:center;gap:6px;margin-left:8px;background:#dcfce7;color:#166534;border:1px solid #86efac;border-radius:999px;padding:3px 8px;font-size:10px;font-weight:900;vertical-align:middle;"><span style="width:8px;height:8px;border-radius:999px;background:#22c55e;box-shadow:0 0 0 0 rgba(34,197,94,.7);animation:pulseGreen 1.8s infinite;"></span>Yeni Eklendi</span>` : ''}
            </p>
            <div class="comp-pair-card-sources">
                <span class="comp-src-badge comp-src-a">${_escHtml(leftSource)}</span>
                <span class="comp-src-vs">VS</span>
                <span class="comp-src-badge comp-src-b">${_escHtml(rightSource)}</span>
            </div>
        </div>`;
}

window.openComparisonPair = async function(idx) {
    window._CE.activePairIdx = idx;

    document.querySelectorAll('.comp-pair-card').forEach((el, i) => {
        el.classList.toggle('comp-pair-card--active', i === idx);
    });

    const pair = window._CE.pairs[idx];
    const detail = document.getElementById('comp-detail-inner');
    if (!pair || !detail) return;

    const left = pair?.leftArticle || {};
    const right = pair?.rightArticle || {};

    detail.innerHTML = `
        <div class="comp-detail-header">
            <div class="comp-detail-header-cat">
                <i class="fas ${_getCatIcon(pair?.category)}"></i>
                <span>${_escHtml(pair?.category || 'World')}</span>
                ${_isNewPair(pair) ? `<span style="margin-left:10px;background:#dcfce7;color:#166534;border:1px solid #86efac;border-radius:999px;padding:4px 10px;font-size:10px;font-weight:900;">YENI EKLENEN HABER</span>` : ''}
            </div>
            <button class="comp-refresh-btn" onclick="window.initComparisonTab({ forceReload: true })">
                <i class="fas fa-sync-alt"></i> Feedi Yenile
            </button>
        </div>

        <div class="comp-panels-grid">
            ${_renderNewsPanel('A', left)}
            ${_renderNewsPanel('B', right)}
        </div>

        <div class="comp-ai-section" id="comp-ai-section-${idx}">
            <div class="comp-ai-section-header">
                <i class="fas fa-robot"></i>
                <span>Yapay Zeka Medya Analizi</span>
                <div class="comp-ai-section-divider"></div>
            </div>
            <div class="comp-ai-body" id="comp-ai-body-${idx}">
                <div class="comp-ai-loading">
                    <i class="fas fa-circle-notch fa-spin"></i>
                    <span>Ayni olay dogrulandi. Analiz hazirlaniyor...</span>
                </div>
            </div>
        </div>`;

    const bodyEl = document.getElementById(`comp-ai-body-${idx}`);
    const localAnalysis = pair?.analysis || null;

    try {
        const remote = await _fetchEventComparison(pair?.eventId);
        const analysis = remote?.analysis || localAnalysis || _fallbackAnalysis(left, right);
        bodyEl.innerHTML = _renderAnalysisHtml(analysis, left, right, pair);
    } catch (err) {
        console.warn('[CE] event comparison error:', err);
        bodyEl.innerHTML = _renderAnalysisHtml(localAnalysis || _fallbackAnalysis(left, right), left, right, pair);
    }
};

function _renderNewsPanel(label, article) {
    const imageUrl = article?.imageUrl || article?.image_url || '';
    const source = _formatDisplaySource(article?.source);
    const publishedAt = article?.publishedAt || article?.published_at || '';
    const summary = article?.summary || article?.description || article?.ai_summary || 'Ozet bulunamadi.';
    const title = article?.title || 'Baslik yok';
    const link = article?.url || '#';
    const panelClass = label === 'A' ? 'comp-panel--a' : 'comp-panel--b';

    return `
        <div class="comp-panel ${panelClass}">
            <div class="comp-panel-badge">KAYNAK ${label}</div>
            ${imageUrl ? `
                <div class="comp-panel-img-wrap">
                    <img src="${_escHtml(imageUrl)}" alt="${_escHtml(title)}" class="comp-panel-img" onerror="this.parentElement.style.display='none'">
                </div>` : ''}
            <div class="comp-panel-body">
                <div class="comp-panel-source-row">
                    <span class="comp-panel-source-name">${_escHtml(source)}</span>
                    ${publishedAt ? `<span class="comp-panel-date">${_formatDate(publishedAt)}</span>` : ''}
                </div>
                <h3 class="comp-panel-title">${_escHtml(title)}</h3>
                <p class="comp-panel-desc">${_escHtml(summary)}</p>
                ${link !== '#' ? `<a href="${_escHtml(link)}" target="_blank" rel="noopener noreferrer" class="comp-panel-link"><i class="fas fa-external-link-alt"></i> Orijinal Habere Git</a>` : ''}
            </div>
        </div>`;
}

function _renderAnalysisHtml(analysis, left, right, pair = {}) {
    const sourceA = _formatDisplaySource(left?.source);
    const sourceB = _formatDisplaySource(right?.source);
    const data = analysis || _fallbackAnalysis(left, right);
    const model = _buildAnalysisExperienceModel(data, left, right, pair);

    return `
        <div class="comp-ai-shell">
            <div class="comp-ai-overview-card">
                <div class="comp-ai-overview-top">
                    <div>
                        <span class="comp-ai-overview-kicker">Kullanici Odakli Medya Analizi</span>
                        <h4 class="comp-ai-overview-title">Ayni olay iki kaynakta nasil farkli bir okuma deneyimi uretiyor?</h4>
                    </div>
                    <div class="comp-ai-overview-badges">
                        <span class="comp-ai-overview-badge"><i class="fas fa-layer-group"></i> ${_escHtml(pair?.category || 'World')}</span>
                        <span class="comp-ai-overview-badge"><i class="fas fa-network-wired"></i> ${_escHtml(sourceA)} vs ${_escHtml(sourceB)}</span>
                        <span class="comp-ai-overview-badge"><i class="fas fa-bullseye"></i> Eslesme ${_escHtml(String(Number(pair?.matchScore || 0).toFixed(1)))}</span>
                    </div>
                </div>

                <p class="comp-ai-overview-summary">${_escHtml(data?.overallSummary || 'Iki kaynak ayni olayi farkli vurgu merkezleriyle anlatiyor.')}</p>

                <div class="comp-ai-overview-grid">
                    ${_renderOverviewMiniCard('Ayni Olay Omurgasi', 'fa-link', model.sharedFrame)}
                    ${_renderOverviewMiniCard(`${sourceA} neyi one tasiyor?`, 'fa-arrow-up-right-dots', data?.focusComparison?.sourceA || 'Bu kaynak ana bilgi omurgasini kendi vurgusuyla veriyor.')}
                    ${_renderOverviewMiniCard(`${sourceB} neyi one tasiyor?`, 'fa-arrow-up-right-dots', data?.focusComparison?.sourceB || 'Bu kaynak ana bilgi omurgasini kendi vurgusuyla veriyor.')}
                </div>
            </div>

            <div class="comp-ai-reader-grid">
                ${_renderSourceInsightCard({
                    side: 'A',
                    accentClass: 'comp-ai-reader-card--a',
                    source: sourceA,
                    article: left,
                    headlineNote: data?.headlineComparison?.sourceA,
                    focusNote: data?.focusComparison?.sourceA,
                    toneNote: data?.toneComparison?.sourceA,
                    actorNote: data?.actorPresentation?.sourceA,
                    missingNote: data?.missingOrUnderplayed?.sourceA,
                    evidence: model.sourceA.evidence,
                    metrics: model.sourceA.metrics,
                })}
                ${_renderSourceInsightCard({
                    side: 'B',
                    accentClass: 'comp-ai-reader-card--b',
                    source: sourceB,
                    article: right,
                    headlineNote: data?.headlineComparison?.sourceB,
                    focusNote: data?.focusComparison?.sourceB,
                    toneNote: data?.toneComparison?.sourceB,
                    actorNote: data?.actorPresentation?.sourceB,
                    missingNote: data?.missingOrUnderplayed?.sourceB,
                    evidence: model.sourceB.evidence,
                    metrics: model.sourceB.metrics,
                })}
            </div>

            <div class="comp-ai-sections comp-ai-sections--grid">
                ${_renderAnalysisSection('BASLIK KARSILASTIRMASI', 'fa-heading', '#6366f1', sourceA, sourceB, data?.headlineComparison?.sourceA, data?.headlineComparison?.sourceB)}
                ${_renderAnalysisSection('HABERIN ODAK NOKTASI', 'fa-crosshairs', '#0ea5e9', sourceA, sourceB, data?.focusComparison?.sourceA, data?.focusComparison?.sourceB)}
                ${_renderAnalysisSection('DIL VE TON FARKI', 'fa-comment-dots', '#8b5cf6', sourceA, sourceB, data?.toneComparison?.sourceA, data?.toneComparison?.sourceB)}
                ${_renderAnalysisSection('AKTOR SUNUMU', 'fa-user-tag', '#f59e0b', sourceA, sourceB, data?.actorPresentation?.sourceA, data?.actorPresentation?.sourceB)}
                ${_renderAnalysisSection('EKSIK VEYA AZ VURGULANAN BILGILER', 'fa-eye-slash', '#64748b', sourceA, sourceB, data?.missingOrUnderplayed?.sourceA, data?.missingOrUnderplayed?.sourceB)}
                <div class="comp-ai-sec comp-ai-sec--special">
                    <div class="comp-ai-sec-title">
                        <i class="fas fa-balance-scale" style="color:#10b981"></i>
                        <span>OKUR ICIN KISA SONUC</span>
                    </div>
                    <div class="comp-ai-sec-body">
                        <p class="comp-ai-plain comp-ai-plain--special">${_escHtml(data?.overallSummary || 'Iki kaynak ayni olayi farkli vurgu merkezleriyle anlatiyor.')}</p>
                    </div>
                </div>
            </div>
        </div>`;
}

function _renderAnalysisSection(title, icon, color, sourceA, sourceB, valueA, valueB) {
    return `
        <div class="comp-ai-sec">
            <div class="comp-ai-sec-title">
                <i class="fas ${icon}" style="color:${color}"></i>
                <span>${title}</span>
            </div>
            <div class="comp-ai-sec-body">
                <div class="comp-ai-src-row comp-ai-src-row--a">
                    <span class="comp-ai-src-label comp-ai-src-label--a">${_escHtml(sourceA)}</span>
                    <span class="comp-ai-src-text">${_escHtml(valueA || 'Bilgi hazirlaniyor.')}</span>
                </div>
                <div class="comp-ai-src-row comp-ai-src-row--b">
                    <span class="comp-ai-src-label comp-ai-src-label--b">${_escHtml(sourceB)}</span>
                    <span class="comp-ai-src-text">${_escHtml(valueB || 'Bilgi hazirlaniyor.')}</span>
                </div>
            </div>
        </div>`;
}

function _renderOverviewMiniCard(title, icon, text) {
    return `
        <div class="comp-ai-mini-card">
            <div class="comp-ai-mini-card-title">
                <i class="fas ${icon}"></i>
                <span>${_escHtml(title)}</span>
            </div>
            <p class="comp-ai-mini-card-text">${_escHtml(text || 'Detay hazirlaniyor.')}</p>
        </div>`;
}

function _renderSourceInsightCard(config) {
    const article = config?.article || {};
    return `
        <div class="comp-ai-reader-card ${config?.accentClass || ''}">
            <div class="comp-ai-reader-head">
                <div>
                    <span class="comp-ai-reader-side">Kaynak ${_escHtml(config?.side || '')}</span>
                    <h5 class="comp-ai-reader-source">${_escHtml(config?.source || 'Kaynak')}</h5>
                </div>
                <div class="comp-ai-reader-metrics">
                    ${(config?.metrics || []).map((metric) => `<span class="comp-ai-reader-metric">${_escHtml(metric)}</span>`).join('')}
                </div>
            </div>

            <div class="comp-ai-reader-titlebox">
                <span class="comp-ai-reader-kicker">Bu kaynagin basligi</span>
                <p class="comp-ai-reader-title">${_escHtml(article?.title || 'Baslik bulunamadi.')}</p>
            </div>

            <div class="comp-ai-reader-block">
                <span class="comp-ai-reader-kicker">Ilk bakista editoryal tercih</span>
                <p class="comp-ai-reader-copy">${_escHtml(config?.headlineNote || 'Baslik tercihi analiz edilemedi.')}</p>
            </div>

            <div class="comp-ai-reader-block">
                <span class="comp-ai-reader-kicker">Icerikten dogrudan ornekler</span>
                <div class="comp-ai-evidence-list">
                    ${(config?.evidence || []).map((sentence) => `
                        <div class="comp-ai-evidence-item">
                            <i class="fas fa-quote-left"></i>
                            <span>${_escHtml(sentence)}</span>
                        </div>`).join('')}
                </div>
            </div>

            <div class="comp-ai-reader-grid-mini">
                <div class="comp-ai-reader-block comp-ai-reader-block--soft">
                    <span class="comp-ai-reader-kicker">Bu kaynak neyi one tasiyor?</span>
                    <p class="comp-ai-reader-copy">${_escHtml(config?.focusNote || 'Odak notu hazirlanamadi.')}</p>
                </div>
                <div class="comp-ai-reader-block comp-ai-reader-block--soft">
                    <span class="comp-ai-reader-kicker">Dil ve ton</span>
                    <p class="comp-ai-reader-copy">${_escHtml(config?.toneNote || 'Ton notu hazirlanamadi.')}</p>
                </div>
                <div class="comp-ai-reader-block comp-ai-reader-block--soft">
                    <span class="comp-ai-reader-kicker">Aktor cizimi</span>
                    <p class="comp-ai-reader-copy">${_escHtml(config?.actorNote || 'Aktor cizimi notu hazirlanamadi.')}</p>
                </div>
                <div class="comp-ai-reader-block comp-ai-reader-block--soft">
                    <span class="comp-ai-reader-kicker">Karsi tarafta daha guclu kalan detay</span>
                    <p class="comp-ai-reader-copy">${_escHtml(config?.missingNote || 'Eksik detay notu hazirlanamadi.')}</p>
                </div>
            </div>
        </div>`;
}

function _buildAnalysisExperienceModel(analysis, left, right, pair = {}) {
    const leftText = _getAnalysisReadableText(left);
    const rightText = _getAnalysisReadableText(right);
    const sourceA = _formatDisplaySource(left?.source);
    const sourceB = _formatDisplaySource(right?.source);
    const commonTerms = _findCommonTerms(leftText, rightText, 5);

    return {
        sharedFrame: commonTerms.length > 0
            ? `${sourceA} ve ${sourceB}, olayin ortak omurgasini ${commonTerms.join(', ')} ekseninde kuruyor.`
            : `${sourceA} ve ${sourceB}, ayni olay akisina bagli kalarak benzer temel bilgileri paylasiyor.`,
        sourceA: {
            evidence: _pickEvidenceSentences(left, right),
            metrics: _buildContentMetrics(leftText, left),
        },
        sourceB: {
            evidence: _pickEvidenceSentences(right, left),
            metrics: _buildContentMetrics(rightText, right),
        },
    };
}

function _getAnalysisReadableText(article) {
    const fields = [article?.summary, article?.description, article?.content, article?.ai_summary, article?.title];
    const unique = [];
    const seen = new Set();
    fields.forEach((value) => {
        const cleaned = _stripHtmlToText(value);
        const key = cleaned.toLowerCase();
        if (!cleaned || seen.has(key)) return;
        seen.add(key);
        unique.push(cleaned);
    });
    return unique.join(' ');
}

function _stripHtmlToText(value) {
    if (!value) return '';
    const temp = document.createElement('div');
    temp.innerHTML = String(value);
    return (temp.textContent || temp.innerText || '')
        .replace(/\s+/g, ' ')
        .replace(/\bhttps?:\/\/\S+/gi, ' ')
        .trim();
}

function _splitIntoSentences(text) {
    return _dedupeStrings(
        (String(text || '').match(/[^.!?]+[.!?]*/g) || [])
            .map((item) => item.replace(/\s+/g, ' ').trim())
            .filter((item) => item.length >= 48)
    );
}

function _pickEvidenceSentences(primaryArticle, secondaryArticle, limit = 3) {
    const primarySentences = _splitIntoSentences(_getAnalysisReadableText(primaryArticle));
    const secondarySentences = _splitIntoSentences(_getAnalysisReadableText(secondaryArticle));
    const uniqueFirst = primarySentences.filter((sentence) => {
        return secondarySentences.every((other) => _sentenceSimilarity(sentence, other) < 0.78);
    });

    const fallback = primarySentences.slice(0, limit);
    const selected = (uniqueFirst.length > 0 ? uniqueFirst : fallback).slice(0, limit);
    return selected.length > 0 ? selected : [_stripHtmlToText(primaryArticle?.summary || primaryArticle?.title || 'Icerik ozeti bulunamadi.')];
}

function _buildContentMetrics(text, article) {
    const sentenceCount = _splitIntoSentences(text).length;
    const tokenCount = _tokenizeForCompare(text).length;
    const hasNumber = /\d/.test(text);
    const hasQuote = /["“”'‘’]/.test(text);
    const metrics = [];
    if (article?.publishedAt || article?.published_at) metrics.push(_formatDate(article?.publishedAt || article?.published_at));
    metrics.push(`${Math.max(sentenceCount, 1)} cumle izi`);
    metrics.push(`${tokenCount} kelime izi`);
    metrics.push(hasNumber ? 'sayisal detay var' : 'sayisal detay yok');
    metrics.push(hasQuote ? 'alinti var' : 'alinti yok');
    return metrics.slice(0, 4);
}

function _findCommonTerms(leftText, rightText, limit = 5) {
    const leftTokens = _tokenizeForCompare(leftText);
    const rightTokens = new Set(_tokenizeForCompare(rightText));
    const common = [];
    const seen = new Set();
    leftTokens.forEach((token) => {
        if (!rightTokens.has(token) || seen.has(token)) return;
        seen.add(token);
        common.push(token);
    });
    return common.slice(0, limit);
}

function _tokenizeForCompare(text) {
    const stopWords = new Set([
        've','ile','ama','fakat','ancak','gibi','daha','icin','için','olan','olarak','bir','iki','bu','su','şu','o',
        'the','and','for','with','from','that','this','were','was','have','has','had','into','about','after','before',
        'dedi','etti','oldu','olduğu','oldugu','belirtti','bildirdi','duyurdu','haber','kaynak','kadar','sonra'
    ]);

    return _stripHtmlToText(text)
        .toLowerCase()
        .match(/[0-9\p{L}]+/gu)?.filter((token) => token.length > 3 && !stopWords.has(token)) || [];
}

function _sentenceSimilarity(a, b) {
    const left = new Set(_tokenizeForCompare(a));
    const right = new Set(_tokenizeForCompare(b));
    if (left.size === 0 || right.size === 0) return 0;
    const intersection = [...left].filter((token) => right.has(token)).length;
    const union = new Set([...left, ...right]).size;
    return union ? intersection / union : 0;
}

function _dedupeStrings(items) {
    const seen = new Set();
    return items.filter((item) => {
        const key = item.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function _fallbackAnalysis(left, right) {
    const sourceA = _formatDisplaySource(left?.source);
    const sourceB = _formatDisplaySource(right?.source);
    return {
        headlineComparison: {
            sourceA: `${sourceA} basligi olayi daha dogrudan kuruyor.`,
            sourceB: `${sourceB} basligi alternatif vurgu alanini one cikariyor.`,
        },
        focusComparison: {
            sourceA: `${sourceA} ana gelismeyi ve sonucu one cikariyor.`,
            sourceB: `${sourceB} ayni olay icindeki farkli ayrintilari gorunur kiliyor.`,
        },
        toneComparison: {
            sourceA: 'Dil daha notr ve bilgi aktarma odakli.',
            sourceB: 'Dil daha secilmis vurgu kelimeleriyle ilerliyor.',
        },
        actorPresentation: {
            sourceA: 'Aktorler haber akisinin merkezinde sunuluyor.',
            sourceB: 'Aktorler sonuc ve baglam uzerinden konumlandiriliyor.',
        },
        missingOrUnderplayed: {
            sourceA: 'Karsi kaynakta yer alan bazi baglamsal ayrintilar burada daha sinirli kaliyor.',
            sourceB: 'Karsi kaynakta one cikan bazi sonuc ayrintilari burada daha zayif vurgulaniyor.',
        },
        overallSummary: 'Iki kaynak ayni olay kumesini paylasiyor; fark hangi ayrintinin basliga ve ozet paragrafina tasindiginda ortaya cikiyor.'
    };
}

function _renderRecoveryState(wrap, errorMessage = '') {
    wrap.innerHTML = `
        <div class="comp-fallback">
            <div class="comp-fallback-icon">
                <i class="fas fa-database"></i>
            </div>
            <h3 class="comp-fallback-title">Hazir comparison havuzu olusturuluyor</h3>
            <p class="comp-fallback-desc">
                Sayfa pasif bos birakilmadi. Database seed/rebuild akisi tamamlaninca hazir kayitlar burada listelenecek.
            </p>
            <p class="comp-fallback-desc" style="margin-top:14px;">${_escHtml(errorMessage || 'Hazir comparison feed olusana kadar rebuild akisi calismaya devam ediyor.')}</p>
            <button class="comp-fallback-retry" onclick="window.initComparisonTab({ forceReload: true })">
                <i class="fas fa-redo"></i> Simdi Yeniden Tara
            </button>
        </div>`;
}

function _isNewPair(pair) {
    if (!pair?.isNew || !pair?.newUntil) return false;
    try {
        return new Date(pair.newUntil).getTime() > Date.now();
    } catch (_) {
        return false;
    }
}

function _formatDisplaySource(src) {
    if (!src) return 'Kaynak';
    return String(src)
        .trim()
        .replace(/_(feed|rss|news)$/i, '')
        .replace(/^(the|www\.)/i, '')
        .split(/[\.\-_]/)
        .filter(Boolean)
        .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
        .join(' ');
}

function _getCatIcon(category) {
    const map = {
        Technology: 'fa-microchip',
        Politics: 'fa-landmark',
        Economy: 'fa-chart-line',
        World: 'fa-globe-americas',
        Sports: 'fa-trophy',
        Health: 'fa-heartbeat',
    };
    return map[category] || 'fa-newspaper';
}

function _formatDate(value) {
    if (!value) return '';
    try {
        return new Date(value).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short', year: 'numeric' });
    } catch (_) {
        return '';
    }
}

function _escHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}
