// js/api.js

// Frontend artık FastAPI üzerinden http://127.0.0.1:8000'da çalışıyor → aynı origin
const API_BASE_URL = "http://127.0.0.1:8000/api/v1";
window.API_BASE_URL = API_BASE_URL;

// OpenAI ChatGPT API — Frontend'den direkt özet üret
// API key: window.OPENAI_API_KEY ile set edin (index.html içinde)
const OPENAI_MODEL = "gpt-4o-mini";
const _summaryCache = {};

async function summarizeWithOpenAI(text, apiKey) {
    if (!text || !apiKey) return null;
    const cacheKey = text.trim().slice(0, 200);
    if (_summaryCache[cacheKey]) return _summaryCache[cacheKey];
    
    let targetLang = (typeof window.currentLang !== 'undefined') ? window.currentLang : (localStorage.getItem('pref_lang') || 'tr');
    const langInstructions = {
        'tr': 'Türkçe olarak en fazla 3 kısa, net cümleyle özetle.',
        'en': 'Summarize in English in a maximum of 3 short, clear sentences.'
    };
    const instruction = langInstructions[targetLang] || langInstructions['tr'];

    try {
        const res = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: OPENAI_MODEL,
                messages: [
                    { role: 'system', content: `Sen bir haber özetleyicisisin. ${instruction} Her cümle yeni satırda olsun, madde işareti kullanma, abartı yapma.` },
                    { role: 'user', content: `Haber:\n${text.slice(0, 600)}` }
                ],
                temperature: 0.2,
                max_tokens: 200
            })
        });
        if (!res.ok) return null;
        const data = await res.json();
        const result = data?.choices?.[0]?.message?.content?.trim() || null;
        if (result) _summaryCache[cacheKey] = result;
        return result;
    } catch (e) {
        console.warn('[OpenAI] Özet alınamadı:', e);
        return null;
    }
}

/**
 * Haberin tam metnini backend scraper'dan çek + OpenAI özet al
 * Backend: POST /api/v1/article/content  { url, title }
 */
async function fetchArticleContent(url, title) {
    try {
        const res = await fetch(`${API_BASE_URL}/article/content`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url: url, title: title || "" })
        });
        if (!res.ok) return null;
        const data = await res.json();
        
        // KÖKLÜ ÇÖZÜM: Backend'den gelen ham İngilizce özet ve içeriği, ekrana basmadan ÖNCE çevir
        let targetLang = (typeof window.currentLang !== 'undefined') ? window.currentLang : (localStorage.getItem('pref_lang') || 'tr');
        if (targetLang && typeof translateTextFree === 'function') {
            if (data.summary) data.summary = await translateTextFree(data.summary, targetLang);
            if (data.content) data.content = await translateTextFree(data.content, targetLang);
        }
        return data;
    } catch (e) {
        console.warn("[fetchArticleContent] Hata:", e);
        return null;
    }
}

/**
 * MOCK: If the backend is not running, fallback to Dummy data
 */
async function fallbackMockData() {
    const targetLang = (typeof window.currentLang !== 'undefined') ? window.currentLang : (localStorage.getItem('pref_lang') || 'tr');
    const raw = [
        { id: "1", title: "Apple to launch AI glasses with real-time translation in 2027", ai_category: "Technology", sentiment: "Positive", ai_summary: "Apple has confirmed AR expansion plans. High cost barrier expected. Direct competition with Meta.", source: "MockFeed", url: "https://example.com/ai-glasses" },
        { id: "2", title: "Elections entering crucial final week with record turnout predicted", ai_category: "Politics", sentiment: "Urgent", ai_summary: "Swing states will be decisive. Historic turnout is forecast. Social media impact has been analyzed.", source: "MockFeed", url: "https://example.com/elections" },
        { id: "3", title: "Global market reaches all-time high amid sustained tech rally", ai_category: "Economy", sentiment: "Positive", ai_summary: "S&P 500 has surpassed a major milestone. Tech earnings exceeded forecasts. Inflation core is trending down.", source: "MockFeed", url: "https://example.com/market-rally" },
        { id: "4", title: "Global sports committee announces sweeping structural overhaul", ai_category: "Sports", sentiment: "Neutral", ai_summary: "Major rule changes have been confirmed. Format reviews are ongoing. Player safety is at the forefront.", source: "MockFeed", url: "https://example.com/sports-reform" },
        { id: "5", title: "Breakthrough cancer therapy shows remarkable results in Phase 3 trials", ai_category: "Health", sentiment: "Positive", ai_summary: "87% remission rate reported. FDA fast-track approval has been sought. Treatment cost remains a barrier.", source: "MockFeed", url: "https://example.com/cancer-therapy" },
    ];
    // İngilizce mock veriyi de çeviri motorundan geçir!
    if (typeof translateNewsArray === 'function') {
        return await translateNewsArray(raw, targetLang);
    }
    return raw;
}

const CACHE_HOURS = 8;
const CACHE_MS = CACHE_HOURS * 60 * 60 * 1000;

// ====== GİZLİ ÇEVİRİ KATMANI (FRONTEND MIDDLEWARE - YÜKSEK KAPASİTE) ======
async function translateTextFree(text, targetLang) {
    if (!text || !targetLang) return text;
    try {
        // Eğer metin çok uzunsa (Makale Gövdesi vb.) URL sınırlarına (GET Limits) takılmamak için böl
        if (text.length > 1500) {
            const chunks = text.match(/[\s\S]{1,1500}(?!\S)/g) || [text];
            let fullTranslated = "";
            for (let chunk of chunks) {
                const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(chunk)}`;
                const res = await fetch(url);
                if (res.ok) {
                    const data = await res.json();
                    if (data && data[0]) {
                        data[0].forEach(part => { if(part[0]) fullTranslated += part[0]; });
                    }
                } else {
                    fullTranslated += chunk; 
                }
            }
            return fullTranslated || text;
        }

        // Kısa metinler (Başlıklar vb.)
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;
        const res = await fetch(url);
        if (!res.ok) return text;
        const data = await res.json();
        let translated = "";
        if (data && data[0]) {
            data[0].forEach(part => { if(part[0]) translated += part[0]; });
        }
        return translated || text;
    } catch(e) {
        return text;
    }
}

async function translateNewsArray(newsArray, targetLang) {
    if (!targetLang) return newsArray;
    console.log(`[Translation Middleware] EKSİKSİZ Çeviri Katmanı devreye girdi: Hedef Dil -> ${targetLang}`);
    
    // Görüntülenecek ilk 40 haberi istisnasız çevir (Performans/RateLimit korumalı)
    const toTranslate = newsArray.slice(0, 40); 
    const promises = toTranslate.map(async (item) => {
        if(item.title) item.title = await translateTextFree(item.title, targetLang);
        if(item.description) item.description = await translateTextFree(item.description, targetLang);
        return item;
    });
    
    await Promise.all(promises);
    return newsArray;
}

async function fetchRecommendations(userId, forceFetch = false) {
    let targetLang = (typeof window.currentLang !== 'undefined') ? window.currentLang : (localStorage.getItem('pref_lang') || 'tr');
    const cacheKey = `bilimhaber_recommend_${userId}_${targetLang}`;
    if (!forceFetch) {
        const cached = localStorage.getItem(cacheKey);
        if (cached) {
            try {
                const parsed = JSON.parse(cached);
                if (Date.now() - parsed.timestamp < CACHE_MS) return parsed.data;
            } catch(e) {}
        }
    }
    try {
        const res = await fetch(`${API_BASE_URL}/recommend/${userId}`);
        if (!res.ok) throw new Error("Backend not available");
        const data = await res.json();
        let recs = (data.recommendations || []).map((article, index) => ({
            ...article,
            id: String(article.id ?? `article-${index}`),
            title: article.title || "Başlıksız haber",
            ai_category: article.ai_category || "General",
            ai_summary: article.ai_summary || article.summary || "",
            url: article.url || article.link || "",
            description: article.description || "",
            source: article.source || "BilimHaber"
        }));
        
        recs.unshift({
            id: "trt-vtalks-1",
            title: "8. Verimlilik ve Teknoloji Fuarı kapsamında VTalks paneli düzenlendi",
            ai_category: "Technology",
            ai_summary: "8. Verimlilik ve Teknoloji Fuarı kapsamında düzenlenen etkinlikte teknoloji dünyasının önemli isimleri bir araya geldi. Bilişim ve teknoloji konuları masaya yatırıldı.",
            url: "https://www.trthaber.com/haber/bilim-teknoloji/8-verimlilik-ve-teknoloji-fuari-kapsaminda-vtalks-paneli-duzenlendi-941923.html",
            description: "8. Verimlilik ve Teknoloji Fuarı kapsamında düzenlenen etkinlikte teknoloji uzmanları buluştu.",
            source: "TRT Haber",
            image_url: "https://trthaberstatic.cdn.wp.trt.com.tr/resimler/2454000/vtalks-aa-2454372.jpg"
        });
        
        // ÖNEMLİ: Veriler Cache'e GİRMEDEN ÖNCE kesin olarak çevrilmelidir!
        recs = await translateNewsArray(recs, targetLang);
        localStorage.setItem(cacheKey, JSON.stringify({ data: recs, timestamp: Date.now() }));
        return recs;
    } catch (e) {
        console.warn("Backend API fail, using Mock Data", e);
        return await fallbackMockData();
    }
}

async function sendBeaconTelemetry(userId, articleId, type, duration = 0) {
    const payload = JSON.stringify({
        user_id: userId,
        article_id: articleId,
        interaction_type: type,
        reading_duration_seconds: duration
    });

    if (navigator.sendBeacon) {
        navigator.sendBeacon(`${API_BASE_URL}/interactions`, payload);
    } else {
        // Fallback to fetch
        fetch(`${API_BASE_URL}/interactions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: payload
        }).catch(() => {});
    }
}
async function fetchGlobalNews(limit = 120, forceFetch = false) {
    let targetLang = (typeof window.currentLang !== 'undefined') ? window.currentLang : (localStorage.getItem('pref_lang') || 'tr');
    const cacheKey = `bilimhaber_global_news_${targetLang}`;
    if (!forceFetch) {
        const cached = localStorage.getItem(cacheKey);
        if (cached) {
            try {
                const parsed = JSON.parse(cached);
                if (Date.now() - parsed.timestamp < CACHE_MS) return parsed.data;
            } catch(e) {}
        }
    }

    try {
        let apiUrl = `${API_BASE_URL}/news?limit=${limit}&lang=${targetLang}`;
        if (forceFetch) {
            localStorage.removeItem(cacheKey); // Cache patlatma
            apiUrl += `&sortBy=publishedAt&order=latest&_t=${Date.now()}`;
        }
        const res = await fetch(apiUrl);
        if (!res.ok) return { news: [] };
        const data = await res.json();
        
        // ZENGİN KATEGORİZASYON MOTORU
        const keywordMap = {
            "Technology": ["teknoloji", "technology", "tech", "bilim", "yazılım", "yapay zeka", "apple", "google", "samsung", "ai", "uzay", "telefon", "internet", "işlemci", "siber", "microsoft", "kripto", "bitcoin", "nasa", "spacex", "elon musk", "robot", "elektrikli araç"],
            "Politics": ["politika", "politics", "siyaset", "bakan", "başkan", "parti", "meclis", "milletvekili", "erdogan", "chp", "akp", "seçim", "hükümet", "diplomasi", "trump", "biden", "putin", "savaş", "pkk", "terör", "ordu", "ankara", "tbmm"],
            "Economy": ["ekonomi", "economy", "finans", "finance", "business", "dolar", "sterlin", "merkez bankası", "enflasyon", "borsa", "altın", "kredi", "faiz", "piyasa", "ihracat", "ithalat", "euro", "yatırım", "zam", "ekonomik", "şirket", "ticaret"],
            "Sports": ["spor", "sports", "football", "futbol", "basketbol", "galatasaray", "fenerbahçe", "beşiktaş", "trabzonspor", "şampiyon", "lig", "maç", "kupa", "transfer", "nba", "uefa", "milli takım", "olimpiyat", "teknik direktör", "voleybol", "tenis", "taraftar"],
            "Health": ["sağlık", "health", "medical", "hastane", "doktor", "virüs", "kanser", "kalp", "beyin", "tedavi", "ilaç", "aşı", "beslenme", "diyet", "hastalık", "ameliyat", "sağlıklı", "salgın", "covid", "sendrom", "klinik"]
        };

        if (data.news && Array.isArray(data.news)) {
            data.news.unshift({
                id: "trt-vtalks-global",
                title: "8. Verimlilik ve Teknoloji Fuarı kapsamında VTalks paneli düzenlendi",
                ai_category: "Technology",
                country: "Turkey",
                link: "https://www.trthaber.com/haber/bilim-teknoloji/8-verimlilik-ve-teknoloji-fuari-kapsaminda-vtalks-paneli-duzenlendi-941923.html",
                description: "8. Verimlilik ve Teknoloji Fuarı kapsamında düzenlenen etkinlikte teknoloji dünyasının önemli isimleri bir araya geldi.",
                source: "TRT Haber",
                image_url: "https://trthaberstatic.cdn.wp.trt.com.tr/resimler/2454000/vtalks-aa-2454372.jpg"
            });
            
            data.news.forEach(item => {
                const text = ((item.title || "") + " " + (item.description || "")).toLowerCase();
                let matchedCat = "World"; // Varsayılan Dünyaya At!
                
                // Eğer modelden kategori gelmemişse text mining ile bul!
                if (!item.ai_category && !item.category) {
                    for (const [key, keywords] of Object.entries(keywordMap)) {
                        if (keywords.some(kw => text.includes(kw))) {
                            matchedCat = key;
                            break;
                        }
                    }
                    item.ai_category = matchedCat;
                }
            });
        }

        // ÖNEMLİ: API'den gelen Array'i Frontend Çeviri Motorundan Geçir ve çevrilmiş olarak CASH'e (Önbelleğe) at!
        data.news = await translateNewsArray(data.news, targetLang);
        localStorage.setItem(cacheKey, JSON.stringify({ data, timestamp: Date.now() }));
        
        return data;
    } catch (e) {
        console.warn("[fetchGlobalNews] Hata:", e);
        return { news: [] };
    }
}

/**
 * RAG Chat: Haberle Sohbet
 * POST /api/v1/chat/article { article_id, user_question }
 */
async function chatWithArticle(articleId, question, token) {
    try {
        const res = await fetch(`${API_BASE_URL}/chat/article`, {
            method: "POST",
            headers: { 
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify({ article_id: articleId, user_question: question })
        });
        if (!res.ok) {
            const err = await res.json();
            return { answer: `Hata: ${err.detail || 'Sohbet başlatılamadı.'}` };
        }
        return await res.json();
    } catch (e) {
        console.warn("[chatWithArticle] Hata:", e);
        return { answer: "Bağlantı hatası: Yapay zeka şu an cevap veremiyor." };
    }
}

/**
 * Global AI Chat: Backend üzerinden genel haberler üzerinden sohbet.
 */
async function chatWithGlobalAI(question, contextData) {
    try {
        const res = await fetch(`${API_BASE_URL}/chat/global`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_question: question,
                context_data: contextData
            })
        });
        if (!res.ok) {
            const errResult = await res.json().catch(()=>({}));
            return `Yapay zeka ile iletişim kurulamadı. ${errResult.detail || ''}`;
        }
        const data = await res.json();
        return data.answer || "Cevap üretilemedi.";
    } catch(e) {
        console.warn("[chatWithGlobalAI] Hata:", e);
        return "Bağlantı hatası: Yapay zeka şu an cevap veremiyor.";
    }
}

/**
 * Makale beğenme (Like) / Geri alma işlemi
 * ZORUNLU: Kullanıcı oturum açmış (JWT) olmalıdır.
 */
async function toggleLikeApi(articleId, token) {
    try {
        const res = await fetch(`${API_BASE_URL}/interactions/like`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ article_id: articleId })
        });
        if (!res.ok) {
            const err = await res.json().catch(()=>({}));
            throw new Error(err.detail || "Beğeni işlemi başarısız.");
        }
        return await res.json();
    } catch (e) {
        console.warn("[toggleLikeApi] Hata:", e);
        throw e;
    }
}

/**
 * Yapay Zeka ile Kümelenmiş ve Özeti çıkarılmış (Clustered) Haber Konularını Çekme
 */
async function fetchClusters() {
    try {
        const res = await fetch(`${API_BASE_URL}/clusters`);
        if (!res.ok) return { clusters: [] };
        return await res.json();
    } catch (e) {
        console.warn("[fetchClusters] Hata:", e);
        return { clusters: [] };
    }
}

/**
 * Haberin ait olduğu kümeyi (Karşılaştırmalı kaynakları) çeker
 */
async function fetchArticleCluster(articleId) {
    try {
        const res = await fetch(`${API_BASE_URL}/clusters/article/${encodeURIComponent(articleId)}`);
        if (!res.ok) return null;
        return await res.json();
    } catch (e) {
        return null;
    }
}

async function fetchComparisonFeedApi(options = {}) {
    const {
        category = "",
        limit = 10,
        lang = (typeof window.currentLang !== "undefined" ? window.currentLang : (localStorage.getItem("pref_lang") || "tr")),
        keyword = "",
        forceRefresh = false,
    } = options;

    const params = new URLSearchParams();
    params.set("limit", String(limit));
    params.set("lang", lang);
    if (category) params.set("category", category);
    if (keyword) params.set("keyword", keyword);
    if (forceRefresh) params.set("force_refresh", "true");

    try {
        const res = await fetch(`${API_BASE_URL}/comparison-feed?${params.toString()}`);
        if (!res.ok) {
            return { comparisons: [], count: 0, meta: { error: "comparison_feed_request_failed" } };
        }
        return await res.json();
    } catch (e) {
        console.warn("[fetchComparisonFeedApi] Hata:", e);
        return { comparisons: [], count: 0, meta: { error: e.message } };
    }
}

async function forceAggregateApi(options = {}) {
    const {
        category = null,
        keywords = [],
        language = (typeof window.currentLang !== "undefined" ? window.currentLang : (localStorage.getItem("pref_lang") || "tr")),
        limit = 10,
    } = options;

    try {
        const res = await fetch(`${API_BASE_URL}/force-aggregate`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                category,
                keywords,
                language,
                limit,
            })
        });
        if (!res.ok) {
            return { comparisons: [], count: 0, meta: { error: "force_aggregate_request_failed" } };
        }
        return await res.json();
    } catch (e) {
        console.warn("[forceAggregateApi] Hata:", e);
        return { comparisons: [], count: 0, meta: { error: e.message } };
    }
}

async function fetchEventComparisonApi(eventId) {
    if (!eventId) {
        return { analysisEligible: false, analysis: null };
    }
    try {
        const res = await fetch(`${API_BASE_URL}/events/${encodeURIComponent(eventId)}/comparison`);
        if (!res.ok) {
            return { analysisEligible: false, analysis: null };
        }
        return await res.json();
    } catch (e) {
        console.warn("[fetchEventComparisonApi] Hata:", e);
        return { analysisEligible: false, analysis: null };
    }
}

async function scanLatestComparisonsApi(options = {}) {
    const {
        language = (typeof window.currentLang !== "undefined" ? window.currentLang : (localStorage.getItem("pref_lang") || "tr")),
        limit = 20,
    } = options;

    try {
        const res = await fetch(`${API_BASE_URL}/comparison/scan-latest`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                category: null,
                keywords: [],
                language,
                limit,
            })
        });
        if (!res.ok) {
            return { comparisons: [], count: 0, scanResult: { status: "failed" } };
        }
        return await res.json();
    } catch (e) {
        console.warn("[scanLatestComparisonsApi] Hata:", e);
        return { comparisons: [], count: 0, scanResult: { status: "failed", error: e.message } };
    }
}

async function rebuildComparisonFeedApi(options = {}) {
    const {
        targetCount = 30,
        language = (typeof window.currentLang !== "undefined" ? window.currentLang : (localStorage.getItem("pref_lang") || "tr")),
    } = options;

    try {
        const res = await fetch(`${API_BASE_URL}/comparison/rebuild`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                target_count: targetCount,
                language,
            })
        });
        if (!res.ok) {
            return { comparisons: [], count: 0, rebuildResult: { status: "failed" } };
        }
        return await res.json();
    } catch (e) {
        console.warn("[rebuildComparisonFeedApi] Hata:", e);
        return { comparisons: [], count: 0, rebuildResult: { status: "failed", error: e.message } };
    }
}
