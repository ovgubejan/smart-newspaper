import asyncio
from datetime import datetime
from news.aggregator import aggregator_instance
from ws_manager import ws_manager
from nlp_service import nlp_manager

class SmartJobScheduler:
    def __init__(self):
        self.is_running_cron = False
        self.is_running_realtime = False

    async def run_8_hour_cron(self):
        """8 saatte bir genel haberleri toplayan Cron Job (Task Scheduler)"""
        if self.is_running_cron: return
        self.is_running_cron = True
        
        while self.is_running_cron:
            print(f"[CRON] 8 Saatlik Standart Haber Tarama Döngüsü Başlıyor: {datetime.utcnow()}")
            try:
                # Normalde aggregator 5 dakikada bir çalışıyordu, 
                # yeni sistemimizde asıl ağırlıklı işlem 8 saatte bir yapılır 
                # ve sadece kritik haberler anlık denetlenir.
                await aggregator_instance.run_once()
            except Exception as e:
                print(f"[CRON_ERROR] 8 saat döngüsünde hata: {e}")
                
            await asyncio.sleep(8 * 3600)  # 28800 saniye (8 saat)

    async def simulate_realtime_critical_fetch(self):
        """Gerçek zamanlı kritik haber (Savaş, Ekonomi, Sağlık, Teknoloji) takibi (BETA/Simulasyon)"""
        if self.is_running_realtime: return
        self.is_running_realtime = True
        
        CRITICAL_CATEGORIES = ["Politics", "War", "Economy", "Health", "Technology"]
        
        while self.is_running_realtime:
            # Gerçek bir sistemde bu sürekli bir SSE veya RSS dinleyicisi olur (Örn: her 2 dakikada bir kontrol ederiz)
            await asyncio.sleep(120) 
            
            # Cache'ten en son haberlere bakalım
            # Eğer son 2 dakika içerisinde girmiş kritik bir haber varsa WebSocket ile basalım
            from news.cache_manager import news_cache
            live_news = news_cache.get_news(limit=15)
            
            for item in live_news:
               # AI sınıflandırması veya basit anahtar kelime sınıflandırması kullan
               cat = nlp_manager.classify_text(item.title + " " + item.description)
               if cat in CRITICAL_CATEGORIES:
                   # WebSocket ile frontend'e pushla
                   article_data = {
                       "id": item.id if hasattr(item, 'id') else "live-news",
                       "title": item.title,
                       "category": cat,
                       "source": item.source,
                       "link": item.link
                   }
                   await ws_manager.broadcast_news(f"Kritik {cat} Haberi!", article_data)
                   # Spam atmamak için döngüyü burada kırabiliriz veya bir SET ile takip edebiliriz.
                   # Şimdilik örnek emit atıp geçiyoruz.
                   break

smart_scheduler = SmartJobScheduler()
