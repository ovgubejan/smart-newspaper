# backend/news/parser.py
import aiohttp
import asyncio
import feedparser
from datetime import datetime
from typing import List, Optional
from .models import GlobalNewsItem

class NewsParser:
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }

    async def fetch_and_parse(self, source_info: dict) -> List[GlobalNewsItem]:
        """
        Fetches an RSS feed and parses it into standardized NewsItem objects.
        """
        url = source_info["url"]
        country = source_info["country"]
        source_name = source_info["source_name"]
        
        try:
            async with aiohttp.ClientSession(headers=self.headers) as session:
                async with session.get(url, timeout=10) as response:
                    if response.status != 200:
                        print(f"[PARSER] Error {response.status} for {url}")
                        return []
                    
                    content = await response.read()
                    
                    # Feedparser is blocking, but for small RSS it's usually fast. 
                    # For 100+ sources, we could use run_in_executor but gather is already parallelizing IO.
                    feed = feedparser.parse(content)
                    
                    parsed_items = []
                    for entry in feed.entries:
                        # Extracting image
                        image_url = None
                        if 'media_content' in entry and len(entry.media_content) > 0:
                            image_url = entry.media_content[0].get('url', '')
                        elif 'enclosures' in entry and len(entry.enclosures) > 0:
                            image_url = entry.enclosures[0].get('href', '')
                            
                        # If still no image, check standard image field
                        if not image_url and 'image' in entry and 'href' in entry.image:
                            image_url = entry.image.href

                        # Fallback: Parse description/summary for raw <img src="..."> tags
                        if not image_url:
                            desc_text = entry.get('description', '') or entry.get('summary', '')
                            if '<img' in desc_text:
                                import re
                                match = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', desc_text, re.IGNORECASE)
                                if match:
                                    image_url = match.group(1)
                                    
                        # Also check content list if available
                        if not image_url and hasattr(entry, 'content') and len(entry.content) > 0:
                            content_val = entry.content[0].value
                            if '<img' in content_val:
                                import re
                                match = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', content_val, re.IGNORECASE)
                                if match:
                                    image_url = match.group(1)
                        
                        # Pub Date handling
                        pub_date = datetime.utcnow()
                        if hasattr(entry, 'published_parsed') and entry.published_parsed:
                            pub_date = datetime(*entry.published_parsed[:6])
                        elif hasattr(entry, 'updated_parsed') and entry.updated_parsed:
                            pub_date = datetime(*entry.updated_parsed[:6])

                        item = GlobalNewsItem(
                            title=entry.get('title', 'No Title'),
                            description=entry.get('summary', entry.get('description', '')),
                            link=entry.get('link', ''),
                            pub_date=pub_date,
                            source=source_name,
                            country=country,
                            image_url=image_url
                        )
                        parsed_items.append(item)
                    
                    return parsed_items
                    
        except asyncio.TimeoutError:
            print(f"[PARSER] Timeout for {url}")
            return []
        except Exception as e:
            print(f"[PARSER] Error fetching {url}: {e}")
            return []

parser_instance = NewsParser()
