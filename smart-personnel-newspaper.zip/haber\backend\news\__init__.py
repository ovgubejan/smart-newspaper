# backend/news/__init__.py
# Modüler Haber Aggregator Paketi
