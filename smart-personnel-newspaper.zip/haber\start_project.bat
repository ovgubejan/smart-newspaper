@echo off
chcp 65001 >nul
setlocal

echo.
echo ============================================
echo  Smart Personnel Newspaper - Proje Baslat
echo ============================================
echo.

cd /d "%~dp0backend"

REM --- 1. Sanal Ortam Kontrolu ---
set "VENV_DIR="
if exist ".venv\Scripts\python.exe" set "VENV_DIR=.venv"
if exist ".venv311\Scripts\python.exe" set "VENV_DIR=.venv311"

if not defined VENV_DIR (
    echo [1/4] Sanal ortam bulunamadi. Olusturuluyor...
    python -m venv .venv
    if errorlevel 1 (
        echo [HATA] Python bulunamadi! Lutfen Python 3.10+ yukleyin.
        echo        https://www.python.org/downloads/
        pause
        exit /b 1
    )
    set "VENV_DIR=.venv"
    echo [OK] Sanal ortam olusturuldu: .venv
) else (
    echo [1/4] Sanal ortam bulundu: %VENV_DIR%
)

REM --- 2. .env Kontrolu ---
if not exist ".env" (
    echo [2/4] .env dosyasi bulunamadi. .env.example kopyalaniyor...
    if exist ".env.example" (
        copy ".env.example" ".env" >nul
        echo [UYARI] .env dosyasi olusturuldu. Lutfen API anahtarlarinizi girin!
        echo         Dosya: %CD%\.env
    ) else (
        echo [UYARI] .env.example bulunamadi. Manuel olarak .env olusturun.
    )
) else (
    echo [2/4] .env dosyasi mevcut.
)

REM --- 3. Bagimliliklari Kur ---
echo [3/4] Python bagimliliklar kontrol ediliyor...
"%VENV_DIR%\Scripts\pip.exe" install -r requirements.txt --quiet
if errorlevel 1 (
    echo [UYARI] Bazi paketler yuklenemedi, devam ediliyor...
)

REM --- 4. Sunucuyu Baslat ---
echo [4/4] Backend API baslatiliyor (http://127.0.0.1:8000)...
echo.
echo  Frontend: http://127.0.0.1:8000
echo  API Docs: http://127.0.0.1:8000/docs
echo.
set PYTHONIOENCODING=utf-8
"%VENV_DIR%\Scripts\python.exe" -m uvicorn api:app --host 127.0.0.1 --port 8000 --reload
