import feedparser
import httpx
from db import SessionLocal
from models import WeatherEvents

class WeatherService:
    @staticmethod
    async def fetch_gdacs_events():
        print("[WEATHER] Global Disaster Alert and Coordination System (GDACS) verileri asenkron çekiliyor...")
        url = "https://gdacs.org/xml/rss.xml"
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(url, timeout=15.0)
                if response.status_code != 200:
                    print(f"[WEATHER_ERROR] GDACS feed ulaşılamıyor. Status: {response.status_code}")
                    return
                feed_data = response.text
                
        except Exception as e:
            print(f"[WEATHER_ERROR] İstek hatası: {e}")
            return
            
        feed = feedparser.parse(feed_data)
        
        new_count = 0
        session = SessionLocal()
        
        for entry in feed.entries:
            title = entry.get('title', '')
            desc = entry.get('description', '')
            link = entry.get('link', '')
            
            # Şiddet rengini tespit et (Green, Orange, Red)
            severity = "Unknown"
            if "Green " in title: severity = "Green"
            elif "Orange " in title: severity = "Orange"
            elif "Red " in title: severity = "Red"
            
            # Olay tipini tespit et
            ev_type = "Disaster"
            if "Earthquake" in title: ev_type = "Earthquake"
            elif "Tsunami" in title: ev_type = "Tsunami"
            elif "Cyclone" in title: ev_type = "Tropical Cyclone"
            elif "Flood" in title: ev_type = "Flood"
            elif "Drought" in title: ev_type = "Drought"
            elif "Volcano" in title: ev_type = "Volcano"
            
            # Veritabanında aynısı var mı?
            exists = session.query(WeatherEvents).filter_by(link=link).first()
            if not exists:
                new_event = WeatherEvents(
                    title=title,
                    description=desc[:2000],
                    event_type=ev_type,
                    severity_level=severity,
                    location="Global Data (Check Link)",
                    link=link
                )
                session.add(new_event)
                new_count += 1
                
        if new_count > 0:
            session.commit()
        session.close()
            
        print(f"[WEATHER] Başarılı: {new_count} yeni ekstrem küresel hava olayı kaydedildi.")

weather_manager = WeatherService()
