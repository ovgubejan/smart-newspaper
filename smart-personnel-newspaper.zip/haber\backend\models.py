import uuid
from typing import List, Dict
from datetime import datetime
import enum
from sqlalchemy import Column, String, Text, Boolean, Enum as SQLEnum, DateTime, JSON, Integer, ForeignKey, Date, Float
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

# ==========================================
# 0. KURUMSAL ETKİNLİKLER (Modül 6)
# ==========================================
class EventCategoryEnum(enum.Enum):
    MEETING = "Meeting"
    EXAM = "Exam"
    DEADLINE = "Deadline"
    HOLIDAY = "Holiday"
    OTHER = "Other"

class InstitutionalEvent(Base):
    """(FR-6.1) Kurumsal Duyuru ve Etkinlikler"""
    __tablename__ = 'institutional_events'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    start_time = Column(DateTime, nullable=False, index=True)
    end_time = Column(DateTime, nullable=True)
    
    category = Column(SQLEnum(EventCategoryEnum), default=EventCategoryEnum.OTHER)
    is_critical = Column(Boolean, default=False)
    
    source_uid = Column(String(100), unique=True, index=True) # ICS iCal UID kopya denetimi için
    created_at = Column(DateTime, default=datetime.utcnow)


# ==========================================
# 1. ENUMS (FR-2.2 Sentiment Analysis, etc)
# ==========================================
class SentimentType(enum.Enum):
    POSITIVE = "Positive"
    NEGATIVE = "Negative"
    NEUTRAL = "Neutral"
    URGENT = "Urgent"

# ==========================================
# 2. NLP ENTITIES (NER)
# ==========================================
class EntityTypeEnum(enum.Enum):
    LOCATION = "LOCATION"
    DISEASE = "DISEASE"
    EVENT = "EVENT"
    ORGANIZATION = "ORGANIZATION"

class Entity(Base):
    """Bulunan NLP Varlıkları (Mekan, Organizasyon, Olay vb.) Sözlüğü"""
    __tablename__ = 'entities'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(200), nullable=False, unique=True, index=True)
    entity_type = Column(SQLEnum(EntityTypeEnum), nullable=False)

class ArticleEntity(Base):
    """NewsArticle ile Entity arasındaki ilişki (Many-To-Many)"""
    __tablename__ = 'article_entities'
    id = Column(Integer, primary_key=True, autoincrement=True)
    article_id = Column(String(36), ForeignKey('news_articles.id', ondelete="CASCADE"), index=True)
    entity_id = Column(Integer, ForeignKey('entities.id', ondelete="CASCADE"), index=True)
    count = Column(Integer, default=1) # Haberde kaç kere geçti
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

class DetectedTrends(Base):
    """(FR) Kelebek Etkisi & Kantitatif Trend (Z-Score Peak) Tablosu"""
    __tablename__ = 'detected_trends'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    entity_id = Column(Integer, ForeignKey('entities.id', ondelete="CASCADE"), index=True)
    peak_time = Column(DateTime, default=datetime.utcnow, index=True)
    severity_score = Column(Float, default=0.0)
    related_articles = Column(JSON, nullable=True) # İlgili haber path/id listesi
    is_active = Column(Boolean, default=True)

class WeatherEvents(Base):
    """Küresel Afet ve Ekstrem Hava Durumu Olayları (GDACS, vb.)"""
    __tablename__ = 'weather_events'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=True)
    event_type = Column(String(100), nullable=False) # Örn: Earthquake, Tropical Cyclone
    severity_level = Column(String(50), nullable=True) # Örn: Orange, Red
    location = Column(String(200), nullable=True)
    link = Column(String(1000), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

# ==========================================
# 3. VERİTABANI ŞEMASI (SQLAlchemy)
# ==========================================
class NewsArticle(Base):
    """
    Haber verilerinin ilişkisel veritabanında (PostgreSQL) tutulacağı şema tasarımı.
    """
    __tablename__ = 'news_articles'

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    url_hash = Column(String(64), unique=True, index=True, nullable=False)
    
    # Ingestion Sonuçları (Ham Veriler)
    title = Column(String(500), nullable=False)
    url = Column(String(1000), nullable=False)
    source = Column(String(200), nullable=False)
    content_text = Column(Text, nullable=False)
    language = Column(String(10), default="en")
    published_at = Column(DateTime, nullable=True)
    source_type = Column(String(50), nullable=True)
    author = Column(String(200), nullable=True)
    category = Column(String(100), nullable=True)
    country = Column(String(100), nullable=True)
    image_url = Column(String(1000), nullable=True)
    keywords = Column(JSON, nullable=True)
    entities_json = Column("entities", JSON, nullable=True)
    normalized_hash = Column(String(64), index=True, nullable=True)
    event_id = Column(String(36), index=True, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, index=True)

    # NLP İşlem Çıktıları (AI Üretimleri)
    ai_category = Column(String(100), nullable=True)     # Örn: Technology, Politics
    ai_tags = Column(JSON, nullable=True)                # Anahtar Kelime Dizisi
    ai_summary = Column(Text, nullable=True)             # Max 3-bullet-point Özet
    ai_sentiment = Column(SQLEnum(SentimentType), nullable=True)
    sentiment_score = Column(Float, nullable=True)       # -1.0 ile 1.0 arası sayısal duygu puanı

    # Yönetici Geçersiz Kılma (Admin Override) (Prompt 3: Kurumsal Model)
    is_overridden = Column(Boolean, default=False)
    manual_category = Column(String(100), nullable=True)
    manual_tags = Column(JSON, nullable=True)
    manual_sentiment = Column(SQLEnum(SentimentType), nullable=True)
    
    # İşleme Durumu
    is_nlp_processed = Column(Boolean, default=False)

# ==========================================
# 3. KULLANICI VE TELEMETRİ (Modül 3 & 4)
# ==========================================
class Category(Base):
    """Sistemdeki haber kategorileri (Technology, Sports, vs.)"""
    __tablename__ = 'categories'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, unique=True)
    slug = Column(String(100), nullable=False, unique=True)

class UserInterest(Base):
    """Kullanıcı ve Kategori arasındaki Many-To-Many ilişki tablosu"""
    __tablename__ = 'user_interests'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey('users.id', ondelete="CASCADE"), index=True)
    category_id = Column(Integer, ForeignKey('categories.id', ondelete="CASCADE"), index=True)

class Bookmark(Base):
    """Daha Sonra Oku (Bookmarks) Tablosu"""
    __tablename__ = 'bookmarks'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey('users.id', ondelete="CASCADE"), index=True, nullable=False)
    article_id = Column(String(36), ForeignKey('news_articles.id', ondelete="CASCADE"), index=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class UserStats(Base):
    """Kullanıcı İstatistikleri ve Streak (Giriş Serisi)"""
    __tablename__ = 'user_stats'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey('users.id', ondelete="CASCADE"), unique=True, index=True, nullable=False)
    total_articles_read = Column(Integer, default=0)
    current_streak = Column(Integer, default=0)
    longest_streak = Column(Integer, default=0)
    last_login_date = Column(Date, nullable=True)

class Badge(Base):
    """Sistemdeki mevcut rozetler"""
    __tablename__ = 'badges'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(String(255), nullable=True)

class UserBadge(Base):
    """Kullanıcıların kazandığı rozetler"""
    __tablename__ = 'user_badges'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey('users.id', ondelete="CASCADE"), index=True, nullable=False)
    badge_id = Column(Integer, ForeignKey('badges.id', ondelete="CASCADE"), index=True, nullable=False)
    awarded_at = Column(DateTime, default=datetime.utcnow)

class User(Base):
    __tablename__ = 'users'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String(50), nullable=False, unique=True)
    joined_at = Column(DateTime, default=datetime.utcnow)
    
    interests = relationship("UserInterest", backref="user", cascade="all, delete-orphan")

class UserPreference(Base):
    """(FR-3.1) Onboarding Tercihleri - Açık İlgi Alanları (Baseline Topic Preferences)"""
    __tablename__ = 'user_preferences'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), index=True)
    selected_topics = Column(JSON, nullable=False) # Örn: ["Technology", "Politics"]
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class UserInteraction(Base):
    """Kullanıcı Davranışları Log Tablosu"""
    __tablename__ = 'user_interactions'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), index=True, nullable=False)
    article_id = Column(String(36), index=True, nullable=False)
    
    interaction_type = Column(String(50), nullable=False)   # 'like', 'dislike', 'view'
    time_spent_seconds = Column(Integer, default=0)
    scroll_depth_percent = Column(Integer, default=0)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)

# ==========================================
# 4. KÜMELEME VE HABER GRUPLARI (Yapay Zeka Karşılaştırmalı Özetler)
# ==========================================
class TopicCluster(Base):
    """Farklı kaynaklardaki bağlantılı haberleri kümeleyen yapı"""
    __tablename__ = 'topic_clusters'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    topic_name = Column(String(255), nullable=False)
    ai_summary = Column(Text, nullable=True) # Zıt görüşleri harmanyan AI Özeti
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)

class ArticleClusterLink(Base):
    """NewsArticle ile TopicCluster arası N-N (Many-To-Many) bağlantı"""
    __tablename__ = 'article_cluster_links'
    id = Column(Integer, primary_key=True, autoincrement=True)
    cluster_id = Column(String(36), ForeignKey('topic_clusters.id', ondelete="CASCADE"), index=True)
    article_id = Column(String(36), ForeignKey('news_articles.id', ondelete="CASCADE"), index=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class ComparisonEvent(Base):
    __tablename__ = 'comparison_events'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    event_hash = Column(String(64), nullable=False, unique=True, index=True)
    canonical_title = Column(String(500), nullable=False)
    canonical_summary = Column(Text, nullable=True)
    category = Column(String(100), nullable=True, index=True)
    event_type = Column(String(100), nullable=True, index=True)
    main_entities = Column(JSON, nullable=True)
    main_location = Column(String(255), nullable=True)
    start_time = Column(DateTime, nullable=True, index=True)
    end_time = Column(DateTime, nullable=True, index=True)
    source_count = Column(Integer, default=0)
    comparison_ready = Column(Boolean, default=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, index=True)


class ComparisonEventArticle(Base):
    __tablename__ = 'comparison_event_articles'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    event_id = Column(String(36), ForeignKey('comparison_events.id', ondelete="CASCADE"), index=True, nullable=False)
    article_id = Column(String(36), ForeignKey('news_articles.id', ondelete="CASCADE"), index=True, nullable=False)
    source = Column(String(200), nullable=False)
    similarity_score = Column(Float, default=0.0)
    is_primary_source = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)


class ComparisonRecord(Base):
    __tablename__ = 'comparison_records'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    event_id = Column(String(36), ForeignKey('comparison_events.id', ondelete="CASCADE"), index=True, nullable=False)
    source_a_article_id = Column(String(36), ForeignKey('news_articles.id', ondelete="CASCADE"), index=True, nullable=False)
    source_b_article_id = Column(String(36), ForeignKey('news_articles.id', ondelete="CASCADE"), index=True, nullable=False)
    ai_summary = Column(Text, nullable=True)
    title_comparison = Column(Text, nullable=True)
    tone_comparison = Column(Text, nullable=True)
    focus_comparison = Column(Text, nullable=True)
    actor_framing = Column(Text, nullable=True)
    missing_points = Column(Text, nullable=True)
    status = Column(String(50), default="ready", index=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, index=True)


class ComparisonIngestion(Base):
    __tablename__ = 'comparison_ingestions'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    run_type = Column(String(50), nullable=False, index=True)
    source_provider = Column(String(100), nullable=True)
    fetched_count = Column(Integer, default=0)
    matched_count = Column(Integer, default=0)
    inserted_count = Column(Integer, default=0)
    failed_count = Column(Integer, default=0)
    status = Column(String(50), default="pending", index=True)
    error_log = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)


class ComparisonFeedItem(Base):
    __tablename__ = 'comparison_feed_items'
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    event_id = Column(String(36), ForeignKey('comparison_events.id', ondelete="CASCADE"), index=True, nullable=False)
    comparison_id = Column(String(36), ForeignKey('comparison_records.id', ondelete="CASCADE"), index=True, nullable=False)
    is_new = Column(Boolean, default=False, index=True)
    new_until = Column(DateTime, nullable=True, index=True)
    priority_score = Column(Float, default=0.0, index=True)
    visible = Column(Boolean, default=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

# SQLAlchemy Models completed. (NewsDTO moved to news_dto.py)
