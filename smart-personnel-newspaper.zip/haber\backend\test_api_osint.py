import asyncio
from osint_api import get_osint_heatmap, get_active_trends, get_entity_timeline

async def main():
    print("--- 1. HEATMAP TEST ---")
    heat = await get_osint_heatmap()
    import pprint
    pprint.pprint(heat)
    
    print("\n--- 2. ACTIVE TRENDS TEST ---")
    trends = await get_active_trends()
    pprint.pprint(trends)
    
    print("\n--- 3. TIMELINE TEST (Entity ID: 1) ---")
    timeline = await get_entity_timeline(1)
    pprint.pprint(timeline)

if __name__ == "__main__":
    asyncio.run(main())
