import sqlite3
import os

db_path = "news.db"
if os.path.exists(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute("ALTER TABLE article_entities ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP")
        conn.commit()
        print("Successfully added created_at to article_entities.")
    except sqlite3.OperationalError as e:
        print(f"OperationalError: {e} (Column might already exist)")
    conn.close()

from db import engine
from models import Base
Base.metadata.create_all(engine)
print("Successfully created DetectedTrends and any missing models.")
