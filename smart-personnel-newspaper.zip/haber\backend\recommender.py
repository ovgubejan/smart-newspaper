# recommender.py
import math
from datetime import datetime, timezone
from typing import List, Dict

# Varsayılan Kaynak Güvenilirlik Çarpanları (Sorunuza İstinaden)
SOURCE_CREDIBILITY_MAP = {
    "https://feeds.bbci.co.uk/news/rss.xml": 1.2, # Kaliteli/Global Haber = %20 Boost
    "https://api.mocknews.com/v1/top-headlines": 1.0,
    "DEFAULT": 0.8 # Bilinmeyen bir kaynaksa düşük katsayı
}

def calculate_base_importance(article_source: str, keyword_count: int, sentiment: str) -> float:
    """Haberin Kalite/Önem Puanı (Global Importance Score)"""
    credibility = SOURCE_CREDIBILITY_MAP.get(article_source, SOURCE_CREDIBILITY_MAP["DEFAULT"])
    
    # 1. Kelime Sayısı ve Ağırlaştırma (Temsili, her 10 kelimede 0.1 ekleniyor, max 2.0)
    keyword_weight = min(2.0, keyword_count * 0.1) if keyword_count else 0.5
    
    # 2. Urgent (Acil/Son Dakika) haberler için ekstra +1.5 çarpan
    sentiment_bonus = 1.5 if sentiment == "Urgent" else 1.0

    return credibility * keyword_weight * sentiment_bonus

def exponential_decay(timestamp: datetime, decay_rate: float = 0.05) -> float:
    """Gelen time-series log'un ne kadar eski olduğuna göre gücünü zayıflatır (şüpheli gün sayısına böler)."""
    now = datetime.utcnow()
    # timestamp navie ise (tzinfo null ise)
    if timestamp.tzinfo is not None:
         now = now.replace(tzinfo=timezone.utc)
    
    delta_days = (now - timestamp).days
    delta_days = max(0, delta_days) # Gelecek zaman engeli
    
    # e ^ (-lambda * t) formülü
    return math.exp(-decay_rate * delta_days)

def adaptive_rank(user_preferences: List[str], interaction_logs: List[Dict], all_articles: List[Dict]):
    """
    (NFR-3) Adaptive Recommendation Algoritması.
    Kullanıcının statik tercihleri (Onboard) %30, 
    Zamanla aşınan Telemetri logları (Implicit CTR) %70 etkiler.
    """
    # 1. Telemetry Loglarını Toparlayıp Dinamik "Topic/Kategori" Ağırlıklarını Çıkarma
    dynamic_weights = {}
    for log in interaction_logs:
        topic = log.get("article_category", "General")
        # Eski etkileşimlerin gücü decay function ile azalır
        log_date = log.get('timestamp')
        weight_bonus = 2.0 if log.get('interaction_type') == "READ_TIME" else 1.0 # Okuma, tıklamadan değerlidir
        
        decayed_value = weight_bonus * exponential_decay(log_date)
        dynamic_weights[topic] = dynamic_weights.get(topic, 0) + decayed_value
        
    print(f"[RECOM_ENGINE] Implicit Behavior Modeli: {dynamic_weights}")

    # 2. Makaleleri Sıralama (Ranking)
    ranked_articles = []
    for article in all_articles:
        base_score = float(article.get("base_importance", 1.0))
        article_cat = article.get("ai_category", "")
        
        # Explicit (Onboard) Weight (Sabit %30 etki)
        explicit_score = 0.3 * (2.0 if article_cat in user_preferences else 0.5)
        
        # Implicit (Telemetry) Weight (Dinamik %70 etki)
        implicit_score = 0.7 * dynamic_weights.get(article_cat, 0.5)
        
        # Matematiksel Toplama
        final_rank_score = base_score * (explicit_score + implicit_score)
        
        article_copy = article.copy()
        article_copy["final_score"] = round(final_rank_score, 3)
        ranked_articles.append(article_copy)
        
    # En yüksek puanı alan üste çıkacak şekilde sırala
    ranked_articles.sort(key=lambda x: x["final_score"], reverse=True)
    return ranked_articles

if __name__ == "__main__":
    from datetime import datetime, timedelta
    
    print("--- DECAY FUNCTION TEST ---")
    now = datetime.utcnow()
    print(f"0 Gun Once Etkilesim: {exponential_decay(now):.2f} Puan")
    print(f"5 Gun Once Etkilesim: {exponential_decay(now - timedelta(days=5)):.2f} Puan")
    print(f"20 Gun Once Etkilesim: {exponential_decay(now - timedelta(days=20)):.2f} Puan")
    
    # Mock articles and user
    user_prefs = ["Technology"] # Explicit interest
    logs = [
        {"timestamp": now - timedelta(days=1), "interaction_type": "READ_TIME", "article_category": "Sports"},
        {"timestamp": now - timedelta(days=2), "interaction_type": "CLICK", "article_category": "Sports"}
    ] # Implicit interest is Sports, heavily recent!
    
    articles = [
        {"id": "a1", "ai_category": "Technology", "base_importance": 1.0},
        {"id": "a2", "ai_category": "Sports", "base_importance": 1.0},
        {"id": "a3", "ai_category": "Politics", "base_importance": 1.0}
    ]
    
    result = adaptive_rank(user_prefs, logs, articles)
    print("\n--- ADAPTIVE RANKING SONUC ---")
    for r in result:
        print(f"Kategori: {r['ai_category']}, Puan: {r['final_score']}")
