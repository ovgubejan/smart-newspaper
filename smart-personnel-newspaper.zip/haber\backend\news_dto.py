from pydantic import BaseModel, Field
import uuid
from typing import Optional

class NewsDTO(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    url: str
    description: str
    source: str
    language: str = "en"
    published_at: Optional[str] = None
    url_hash: Optional[str] = None
    ai_category: Optional[str] = None
    image_url: Optional[str] = None
