import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

from nlp_service import nlp_manager
text = "The devastating earthquake in Japan and COVID-19 pandemic severely affected the supply chain of Apple Inc."
ents = nlp_manager.extract_entities(text)
score = nlp_manager.calculate_sentiment_score(text)
print("Entities:", ents)
print("Sentiment Score:", score)
