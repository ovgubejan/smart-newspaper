// js/gazette.js — BilimHaber Gazete Baskı Modülü — Sayfalı Gazete UI

const CATEGORY_TR = {
    "Technology": "Teknoloji",
    "Politics":   "Politika",
    "Economy":    "Ekonomi",
    "Sports":     "Spor",
    "Health":     "Sağlık",
    "Science":    "Bilim",
    "World":      "Dünya",
    "Weather":    "Hava Durumu",
    "Culture":    "Kültür-Sanat",
    "Education":  "Eğitim",
    "Home":       "Anasayfa",
    "General":    "Genel",
    "Dashboard":  "Pano"
};

const ARTICLES_PER_GAZETTE_PAGE = 6;
let gazetteCurrentPage = 1;
let gazetteArticles = [];

function openGazetteModal() {
    const session = typeof Auth !== 'undefined' ? Auth.getSession() : null;
    const prefs   = (session && session.selectedTopics && session.selectedTopics.length > 0)
                    ? session.selectedTopics
                    : null;

    const articles = AppState.articles || [];

    // Tercihlere göre filtrele; tercih yoksa tümünü al
    let filtered = prefs
        ? articles.filter(a => prefs.includes(a.ai_category))
        : articles;

    // En fazla 60 haber
    gazetteArticles = filtered.slice(0, 60);
    gazetteCurrentPage = 1;

    if (gazetteArticles.length === 0) {
        alert(typeof t === 'function' ? t('no_news') : 'Gazete için haber bulunamadı. Lütfen önce tercih seçin ve haberlerin yüklenmesini bekleyin.');
        return;
    }

    renderGazettePage();

    const modal = document.getElementById('gazette-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        document.body.style.overflow = 'hidden';
    }
}

function renderGazettePage() {
    const content = document.getElementById('gazette-content');
    if (!content) return;

    const totalPages = Math.ceil(gazetteArticles.length / ARTICLES_PER_GAZETTE_PAGE);
    const startIdx = (gazetteCurrentPage - 1) * ARTICLES_PER_GAZETTE_PAGE;
    const pageArts = gazetteArticles.slice(startIdx, startIdx + ARTICLES_PER_GAZETTE_PAGE);

    const session = typeof Auth !== 'undefined' ? Auth.getSession() : null;
    const prefs = (session && session.selectedTopics && session.selectedTopics.length > 0)
                    ? session.selectedTopics : null;

    // Bugünün tarihi
    const langStr = (window.currentLang || 'tr') === 'en' ? 'en-US' : (window.currentLang || 'tr');
    const today = new Date().toLocaleDateString(langStr, {
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
    });

    // Sayı numarası (güne göre deterministik)
    const dayOfYear = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
    const issueNum = dayOfYear + 1000;

    // İlk sayfa hero'lu, diğerleri grid
    const isFirstPage = gazetteCurrentPage === 1;
    const hero = isFirstPage ? pageArts[0] : null;
    const gridArts = isFirstPage ? pageArts.slice(1) : pageArts;

    const heroImgFallback = `https://images.unsplash.com/photo-1495020689067-958852a7765e?auto=format&fit=crop&w=900&q=80`;

    // Hero bölümü
    let heroHtml = '';
    if (hero) {
        const heroImg = (hero.image_url && hero.image_url.trim().length > 10) ? hero.image_url : heroImgFallback;
        const heroSummary = (hero.ai_summary || '').replace(/^[-•]\s*/gm, '').substring(0, 400);
        heroHtml = `
            <section class="gazette-hero-section">
                <div class="gazette-hero-layout">
                    <div class="gazette-hero-text">
                        <span class="gazette-hero-cat">${CATEGORY_TR[hero.ai_category] || hero.ai_category}</span>
                        <h2 class="gazette-hero-headline">
                            ${hero.url ? `<a href="${hero.url}" target="_blank" rel="noopener">${hero.title}</a>` : hero.title}
                        </h2>
                        <div class="gazette-ai-summary-box">
                            <div class="gazette-ai-badge"><i class="fas fa-robot"></i> ${typeof t === 'function' ? t('ai_summary_title') : 'YZ ÖZETİ'}</div>
                            <p>${heroSummary}</p>
                        </div>
                        <span class="gazette-hero-meta">${typeof t === 'function' ? t('source') : 'KAYNAK'}: ${typeof formatSourceName === 'function' ? formatSourceName(hero.source || 'BİLİMHABER') : (hero.source || 'BİLİMHABER')}</span>
                    </div>
                    <div class="gazette-hero-img-col">
                        <img src="${heroImg}" alt="" class="gazette-hero-photo" onerror="this.style.display='none'">
                    </div>
                </div>
            </section>
            <div class="gazette-divider-thick"></div>
        `;
    }

    // Kategorilere göre grupla (sayfa içi)
    const grouped = {};
    gridArts.forEach(art => {
        const cat = CATEGORY_TR[art.ai_category] || art.ai_category || 'Genel';
        if (!grouped[cat]) grouped[cat] = [];
        grouped[cat].push(art);
    });

    let columnsHtml = '';
    Object.entries(grouped).forEach(([catTR, arts]) => {
        const articlesHtml = arts.map((art, i) => {
            const img = (art.image_url && art.image_url.trim().length > 10) ? art.image_url : '';
            const summary = (art.ai_summary || '').replace(/^[-•]\s*/gm, '').substring(0, 220);
            const isLead = i === 0;
            const sourceLabel = typeof t === 'function' ? t('source') : 'KAYNAK';
            return `
                <article class="gaz-article ${isLead ? 'gaz-article-lead' : ''}">
                    ${isLead && img ? `<img src="${img}" class="gaz-article-img" onerror="this.style.display='none'" alt="">` : ''}
                    <div class="gaz-article-body">
                    <span class="gaz-article-source">${sourceLabel}: ${typeof formatSourceName === 'function' ? formatSourceName(art.source || 'BİLİMHABER') : (art.source || 'BİLİMHABER')}</span>
                        <h3 class="gaz-article-title">
                            ${art.url ? `<a href="${art.url}" target="_blank" rel="noopener">${art.title}</a>` : art.title}
                        </h3>
                        ${summary ? `
                        <div class="gaz-ai-summary-inline">
                            <span class="gaz-ai-tag"><i class="fas fa-robot"></i> ${typeof t === 'function' ? t('ai_summary_short') : 'YZ'}</span>
                            <p>${summary}</p>
                        </div>` : ''}
                    </div>
                </article>
            `;
        }).join('');

        columnsHtml += `
            <section class="gaz-category-section">
                <h2 class="gaz-category-heading">${catTR}</h2>
                <div class="gaz-articles-column">
                    ${articlesHtml}
                </div>
            </section>
        `;
    });

    // Sayfa navigasyonu
    let pageNavHtml = '';
    if (totalPages > 1) {
        let pageButtons = '';
        for (let p = 1; p <= totalPages; p++) {
            const isActive = p === gazetteCurrentPage;
            pageButtons += `<button onclick="goToGazettePage(${p})" class="gaz-page-btn ${isActive ? 'gaz-page-btn-active' : ''}">${p}</button>`;
        }
        const prevLabel = (typeof t === 'function' ? t('prev_page') : 'Önceki Sayfa');
        const nextLabel = (typeof t === 'function' ? t('next_page') : 'Sonraki Sayfa');
        pageNavHtml = `
            <div class="gaz-pagination">
                <button onclick="goToGazettePage(${gazetteCurrentPage - 1})" ${gazetteCurrentPage <= 1 ? 'disabled' : ''} class="gaz-page-nav-btn">
                    <i class="fas fa-chevron-left"></i> ${prevLabel}
                </button>
                <div class="gaz-page-numbers">${pageButtons}</div>
                <button onclick="goToGazettePage(${gazetteCurrentPage + 1})" ${gazetteCurrentPage >= totalPages ? 'disabled' : ''} class="gaz-page-nav-btn">
                    ${nextLabel} <i class="fas fa-chevron-right"></i>
                </button>
            </div>
            <p class="gaz-page-info">${typeof t === 'function' ? t('page_of') : 'Sayfa'} ${gazetteCurrentPage} / ${totalPages} — ${typeof t === 'function' ? t('news_count') : 'haber'}: ${gazetteArticles.length}</p>
        `;
    }

    content.innerHTML = `
        <!-- Gazete Başlığı -->
        <header class="gaz-masthead">
            <div class="gaz-masthead-top">
                <span class="gaz-masthead-date">${today}</span>
                <span class="gaz-masthead-issue">${typeof t === 'function' ? t('issue') : 'Sayı'}: ${issueNum}</span>
            </div>
            <div class="gaz-masthead-rule"></div>
            <h1 class="gaz-masthead-logo">BİLİM<span>HABER</span></h1>
            <div class="gaz-masthead-rule"></div>
            <div class="gaz-masthead-bottom">
                <span>${typeof t === 'function' ? t('your_gazette') : 'Kişisel Gazeteniz'}</span>
                <span class="gaz-masthead-cats">${(prefs || [typeof t === 'function' ? t('home') : 'Tümü']).map(p => CATEGORY_TR[p] || p).join(' • ')}</span>
            </div>
        </header>

        <!-- Hero / Ana Haber -->
        ${heroHtml}

        <!-- Kategori Bölümleri -->
        <div class="gaz-columns-wrapper">
            ${columnsHtml}
        </div>

        <!-- Sayfa Navigasyonu -->
        ${pageNavHtml}

        <!-- Gazete Altbilgi -->
        <footer class="gaz-footer">
            <div class="gaz-masthead-rule"></div>
            <p>© ${new Date().getFullYear()} BilimHaber — ${window.currentLang === 'en' ? 'This gazette is automatically generated by AI based on your personal preferences.' : 'Bu gazete kişisel tercihlerinize göre YZ destekli olarak otomatik oluşturulmuştur.'}</p>
        </footer>
    `;
}

function goToGazettePage(page) {
    const totalPages = Math.ceil(gazetteArticles.length / ARTICLES_PER_GAZETTE_PAGE);
    if (page < 1 || page > totalPages) return;
    gazetteCurrentPage = page;
    renderGazettePage();
    // Scroll to top of gazette
    const wrapper = document.getElementById('gazette-wrapper');
    if (wrapper) wrapper.scrollTo({ top: 0, behavior: 'smooth' });
}

function closeGazetteModal() {
    const modal = document.getElementById('gazette-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
    document.body.style.overflow = '';
}

function printGazette() {
    const origTitle = document.title;
    document.title = 'BilimHaber — Kişisel Gazete';
    window.print();
    document.title = origTitle;
}

window.openGazetteModal = openGazetteModal;
window.closeGazetteModal = closeGazetteModal;
window.printGazette = printGazette;
window.goToGazettePage = goToGazettePage;
