from __future__ import annotations

import asyncio
import hashlib
import html
import os
import re
import threading
import uuid
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher
from email.utils import parsedate_to_datetime
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from news.aggregator import aggregator_instance
from news.cache_manager import news_cache
from newsapi_client import fetch_everything, fetch_top_headlines
from nlp_service import nlp_manager
from rss_client import fetch_all_hurriyet_news, fetch_trt_news


CATEGORY_PRIORITY = ["Politics", "Economy", "World", "Technology", "Sports"]
SECONDARY_THEMES = [
    "breaking news",
    "official statements",
    "economic decisions",
    "court decisions",
    "international conflicts",
    "major sports matches",
    "disasters",
    "diplomatic developments",
]
SEARCH_QUERY_HINTS = {
    "Politics": ["official statements", "cabinet decision", "election decision", "court ruling"],
    "Economy": ["interest rate decision", "inflation data", "market reaction", "economic decision"],
    "World": ["diplomatic developments", "international conflict", "ceasefire statement", "summit outcome"],
    "Technology": ["product launch", "AI announcement", "antitrust decision", "official statement"],
    "Sports": ["major sports matches", "cup final", "coach statement", "transfer decision"],
}
ACTION_TERMS = {
    "announce", "announced", "say", "said", "confirm", "confirmed", "approve", "approved",
    "reject", "rejected", "sign", "signed", "launch", "launched", "open", "opened",
    "close", "closed", "attack", "attacked", "strike", "struck", "vote", "voted",
    "win", "won", "lose", "lost", "defeat", "defeated", "meet", "met", "agree", "agreed",
    "declare", "declared", "warn", "warned", "sanction", "sanctioned", "file", "filed",
    "rule", "ruled", "sentence", "sentenced", "resign", "resigned", "appoint", "appointed",
    "duyurdu", "açıkladi", "açıkladı", "onayladı", "reddetti", "başlattı", "başladı",
    "kazandı", "kaybetti", "kararlaştırdı", "karar", "imzaladı", "görüştü", "uyardı",
    "ilan etti", "saldırdı", "vurdu", "erteledi", "durdurdu", "atadı",
}
OUTCOME_TERMS = {
    "approved", "approval", "rejected", "delay", "delayed", "ceasefire", "agreement",
    "sanction", "victory", "defeat", "draw", "lawsuit", "decision", "result", "warning",
    "crisis", "casualties", "injured", "dead", "settlement", "fine", "merger", "ban",
    "onay", "ret", "ertelendi", "anlaşma", "ateşkes", "zafer", "mağlubiyet", "beraberlik",
    "karar", "sonuç", "uyarı", "ceza", "yasak", "anlaşma", "yaralı", "ölü",
}
STOP_WORDS = {
    "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "of", "with",
    "by", "is", "are", "was", "were", "be", "been", "has", "have", "had", "not", "this",
    "that", "it", "as", "do", "did", "from", "so", "if", "after", "before", "will", "would",
    "could", "should", "there", "their", "they", "than", "more", "also", "its", "into",
    "about", "up", "when", "what", "how", "why", "who", "which", "your", "our", "his",
    "her", "them", "over", "under", "amid", "amidst", "latest", "live", "update",
    "bir", "bu", "ve", "de", "da", "ile", "icin", "için", "olan", "den", "dan", "ise",
    "ya", "mi", "mı", "mu", "mü", "degil", "değil", "ki", "her", "hem", "daha", "cok",
    "çok", "gibi", "kadar", "var", "şu", "su", "o", "biz", "siz", "onlar", "ben", "sen",
    "ne", "nasil", "nasıl", "nerede", "kim", "hangi", "kendi", "cunku", "çünkü", "ama",
    "ancak", "fakat", "lakin", "veya", "son", "dakika", "guncel", "güncel", "haber",
}
ANALYSIS_IMPORTANT_SHORT_TOKENS = {"abd", "fed", "msb", "nyt", "tff", "pfdk", "tbmm"}
ANALYSIS_NOISE_TOKENS = {
    "oldugu", "olduğunu", "olduğu", "oldu", "olduklarini", "olduklarını", "belirtti",
    "belirtildi", "bildirdi", "duyurdu", "kaydedildi", "degerlendirildi", "değerlendirildi",
    "yönelik", "yonelik", "ilişkin", "iliskin", "arasında", "arasındaki", "aralarındaki",
    "halen", "ikinci", "birinci", "üzerine", "uzerine", "yerine", "kararı", "kararını",
    "kararini", "görüşmelere", "gorusmelere", "görüşmelerine", "gorusmelerine",
    "görüşmelerinin", "gorusmelerinin", "toplantıya", "toplantiya", "içeren", "iceren",
    "olmak", "üzere", "uzere", "edildi", "etti", "ettiği", "ettigi", "konusunda",
    "kapsamında", "kapsaminda", "diken", "hurriyet", "trthaber", "trt", "aa", "haberler",
    "haberlercom", "site", "link", "href", "https", "http", "www", "post", "appeared",
    "first", "source", "kaynak", "metin", "icerik", "içerik", "başlık", "baslik",
}


@dataclass
class EventFeatures:
    article: Dict[str, Any]
    canonical_title: str
    category: str
    event_type: str
    action: str
    outcome: str
    published_at: datetime
    keywords: List[str]
    entities: List[Dict[str, str]]
    entity_names: List[str]
    actor_entities: List[str]
    place_entities: List[str]
    signature_tokens: List[str]


@dataclass
class EventCluster:
    event_id: str
    event_title: str
    category: str
    event_type: str
    articles: List[Dict[str, Any]] = field(default_factory=list)
    features: List[EventFeatures] = field(default_factory=list)
    sources: set = field(default_factory=set)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    max_pair_score: float = 0.0
    best_pair: Optional[Dict[str, Any]] = None


class BaseProviderAdapter:
    name = "base"
    source_type = "api"

    def fetch(self, *, category: str, keywords: Sequence[str], language: str, limit: int) -> List[Dict[str, Any]]:
        raise NotImplementedError


class CacheProviderAdapter(BaseProviderAdapter):
    name = "news_cache"
    source_type = "cache"

    def fetch(self, *, category: str, keywords: Sequence[str], language: str, limit: int) -> List[Dict[str, Any]]:
        seed_items = news_cache.get_news(limit=max(limit, 60))
        return [normalize_article(item, provider=self.name, source_type=self.source_type) for item in seed_items]


class GNewsProviderAdapter(BaseProviderAdapter):
    name = "gnews"
    source_type = "api"

    def fetch(self, *, category: str, keywords: Sequence[str], language: str, limit: int) -> List[Dict[str, Any]]:
        articles: List[Dict[str, Any]] = []

        for dto in fetch_top_headlines(
            category=category,
            language=language or "en",
            page_size=max(4, min(limit, 20)),
            allow_mock=False,
        ):
            articles.append(normalize_article(dto, provider=self.name, source_type=self.source_type, category_hint=category))

        for query in list(keywords)[:3]:
            for dto in fetch_everything(query=query, language=language or "en", page_size=max(3, min(limit // 2 or 3, 10))):
                articles.append(normalize_article(dto, provider=self.name, source_type=self.source_type, category_hint=category))

        return articles


class TRTProviderAdapter(BaseProviderAdapter):
    name = "trt_rss"
    source_type = "rss"

    def fetch(self, *, category: str, keywords: Sequence[str], language: str, limit: int) -> List[Dict[str, Any]]:
        return [
            normalize_article(dto, provider=self.name, source_type=self.source_type, category_hint=category)
            for dto in fetch_trt_news()[:limit]
        ]


class HurriyetProviderAdapter(BaseProviderAdapter):
    name = "hurriyet_rss"
    source_type = "rss"

    def fetch(self, *, category: str, keywords: Sequence[str], language: str, limit: int) -> List[Dict[str, Any]]:
        return [
            normalize_article(dto, provider=self.name, source_type=self.source_type, category_hint=category)
            for dto in fetch_all_hurriyet_news()[:limit]
        ]


class ComparisonService:
    def __init__(self) -> None:
        self.providers: List[BaseProviderAdapter] = [
            CacheProviderAdapter(),
            GNewsProviderAdapter(),
            TRTProviderAdapter(),
            HurriyetProviderAdapter(),
        ]
        self._feed_cache: Dict[str, Dict[str, Any]] = {}
        self._cluster_index: Dict[str, EventCluster] = {}
        self._lock = threading.Lock()
        self.cache_ttl = timedelta(minutes=12)

    def get_comparison_feed(
        self,
        *,
        category: Optional[str] = None,
        limit: int = 10,
        language: str = "en",
        keywords: Optional[Sequence[str]] = None,
        force_refresh: bool = False,
    ) -> Dict[str, Any]:
        normalized_category = normalize_category_name(category) if category else None
        cache_key = self._make_cache_key(normalized_category, language, keywords)
        cache_hit = self._feed_cache.get(cache_key)

        if cache_hit and not force_refresh and not self._is_cache_expired(cache_hit):
            return self._clone_payload(cache_hit["payload"], limit)

        articles = self.collect_articles(
            categories=[normalized_category] if normalized_category else CATEGORY_PRIORITY,
            language=language,
            keywords=list(keywords or []),
            force_refresh=force_refresh,
            limit=max(40, limit * 8),
        )
        payload = self._build_feed_payload(articles, requested_categories=[normalized_category] if normalized_category else [], limit=limit)
        self._store_payload(cache_key, payload)
        return self._clone_payload(payload, limit)

    def force_aggregate(
        self,
        *,
        category: Optional[str] = None,
        language: str = "en",
        keywords: Optional[Sequence[str]] = None,
        limit: int = 10,
    ) -> Dict[str, Any]:
        categories = self._expand_categories(category)
        requested_keywords = [kw for kw in (keywords or []) if kw]
        articles = self.collect_articles(
            categories=categories,
            language=language,
            keywords=requested_keywords,
            force_refresh=True,
            limit=max(60, limit * 10),
        )
        payload = self._build_feed_payload(
            articles,
            requested_categories=categories,
            limit=limit,
            requested_keywords=requested_keywords,
            forced=True,
        )

        if not payload["comparisons"]:
            broad_keywords = requested_keywords or SECONDARY_THEMES
            retry_articles = self.collect_articles(
                categories=categories,
                language=language,
                keywords=broad_keywords,
                force_refresh=True,
                limit=max(80, limit * 12),
            )
            payload = self._build_feed_payload(
                retry_articles,
                requested_categories=categories,
                limit=limit,
                requested_keywords=broad_keywords,
                forced=True,
            )

        cache_key = self._make_cache_key(category, language, keywords)
        self._store_payload(cache_key, payload)
        return payload

    def collect_articles(
        self,
        *,
        categories: Sequence[Optional[str]],
        language: str,
        keywords: Sequence[str],
        force_refresh: bool,
        limit: int,
    ) -> List[Dict[str, Any]]:
        self._ensure_seed_articles(force_refresh=force_refresh)

        categories = [normalize_category_name(cat) for cat in categories if cat] or CATEGORY_PRIORITY
        tasks: List[Tuple[BaseProviderAdapter, str, List[str]]] = []
        for category in categories:
            task_keywords = self._keywords_for_category(category, keywords)
            for provider in self.providers:
                tasks.append((provider, category, task_keywords))

        articles: List[Dict[str, Any]] = []
        with ThreadPoolExecutor(max_workers=min(12, max(4, len(tasks)))) as executor:
            futures = [
                executor.submit(
                    provider.fetch,
                    category=category,
                    keywords=task_keywords,
                    language=language,
                    limit=limit,
                )
                for provider, category, task_keywords in tasks
            ]
            for future in futures:
                try:
                    articles.extend(future.result() or [])
                except Exception as exc:
                    print(f"[COMPARISON] Provider fetch failed: {exc}")

        filtered = [article for article in dedupe_articles(articles) if article]
        for article in filtered:
            merged_text = " ".join(
                str(article.get(key) or "")
                for key in ("title", "summary", "content", "description", "ai_summary")
            ).strip()
            if not article.get("category"):
                article["category"] = infer_category(merged_text)
                article["ai_category"] = article["category"]

        return filtered[:limit * max(4, len(categories))]

    def filter_news(
        self,
        *,
        category: Optional[str] = None,
        source: Optional[str] = None,
        keyword: Optional[str] = None,
        language: str = "en",
        limit: int = 50,
        force_refresh: bool = False,
    ) -> List[Dict[str, Any]]:
        categories = self._expand_categories(category)
        articles = self.collect_articles(
            categories=categories,
            language=language,
            keywords=[keyword] if keyword else [],
            force_refresh=force_refresh,
            limit=max(40, limit * 4),
        )

        filtered = []
        for article in articles:
            if category and normalize_category_name(article.get("category")) != normalize_category_name(category):
                continue
            if source and normalize_source_name(article.get("source")) != normalize_source_name(source):
                continue
            if keyword and keyword.lower() not in " ".join(
                str(article.get(key) or "").lower()
                for key in ("title", "summary", "description", "content")
            ):
                continue
            filtered.append(article)
        return filtered[:limit]

    def extract_event(self, article: Dict[str, Any]) -> Dict[str, Any]:
        normalized = normalize_article(article, provider="manual", source_type=article.get("sourceType", "manual"))
        features = extract_event_features(normalized)
        return event_features_to_payload(features)

    def match_events(self, articles: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
        normalized = [normalize_article(article, provider="manual", source_type=article.get("sourceType", "manual")) for article in articles]
        features = [extract_event_features(article) for article in normalized]
        results = []
        for index, feature_a in enumerate(features):
            for feature_b in features[index + 1:]:
                match = compute_match(feature_a, feature_b)
                results.append({
                    "leftArticleId": feature_a.article["id"],
                    "rightArticleId": feature_b.article["id"],
                    **match,
                })
        results.sort(key=lambda item: item["score"], reverse=True)
        return {"count": len(results), "matches": results}

    def get_event_articles(self, event_id: str) -> Dict[str, Any]:
        cluster = self._cluster_index.get(event_id)
        if not cluster:
            return {"eventId": event_id, "articles": []}
        articles = [attach_event_to_article(article, event_id, cluster.event_title) for article in cluster.articles]
        return {
            "eventId": event_id,
            "eventTitle": cluster.event_title,
            "category": cluster.category,
            "articles": articles,
            "sourceCount": len(cluster.sources),
        }

    def get_event_comparison(self, event_id: str) -> Dict[str, Any]:
        cluster = self._cluster_index.get(event_id)
        if not cluster or not cluster.best_pair:
            return {
                "eventId": event_id,
                "analysisEligible": False,
                "analysis": None,
            }

        pair = cluster.best_pair
        analysis = build_comparison_analysis(pair["left"], pair["right"])
        return {
            "eventId": event_id,
            "eventTitle": cluster.event_title,
            "category": cluster.category,
            "analysisEligible": True,
            "analysis": analysis,
            "pairScore": pair["score"],
            "leftArticle": attach_event_to_article(pair["left"], event_id, cluster.event_title),
            "rightArticle": attach_event_to_article(pair["right"], event_id, cluster.event_title),
        }

    def _build_feed_payload(
        self,
        articles: Sequence[Dict[str, Any]],
        *,
        requested_categories: Sequence[Optional[str]],
        limit: int,
        requested_keywords: Optional[Sequence[str]] = None,
        forced: bool = False,
    ) -> Dict[str, Any]:
        clusters = build_event_clusters(list(articles))
        comparisons: List[Dict[str, Any]] = []

        with self._lock:
            self._cluster_index = {cluster.event_id: cluster for cluster in clusters}

        for cluster in clusters:
            if not cluster.best_pair:
                continue
            pair = cluster.best_pair
            comparisons.append({
                "eventId": cluster.event_id,
                "eventTitle": cluster.event_title,
                "category": cluster.category,
                "eventType": cluster.event_type,
                "sourceCount": len(cluster.sources),
                "matchScore": pair["score"],
                "matchedAt": cluster.updated_at.isoformat(),
                "sources": sorted(cluster.sources),
                "articles": [
                    attach_event_to_article(article, cluster.event_id, cluster.event_title)
                    for article in cluster.articles
                ],
                "leftArticle": attach_event_to_article(pair["left"], cluster.event_id, cluster.event_title),
                "rightArticle": attach_event_to_article(pair["right"], cluster.event_id, cluster.event_title),
                "analysisEligible": True,
                "analysis": build_comparison_analysis(pair["left"], pair["right"]),
            })

        comparisons.sort(key=lambda item: (item["matchScore"], item["sourceCount"]), reverse=True)
        truncated = comparisons[:limit]
        return {
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "requestedCategories": [cat for cat in requested_categories if cat],
            "requestedKeywords": list(requested_keywords or []),
            "forced": forced,
            "comparisons": truncated,
            "count": len(truncated),
            "meta": {
                "articlesProcessed": len(articles),
                "clustersBuilt": len(clusters),
                "matchedComparisons": len(comparisons),
                "providerCount": len(self.providers),
            },
        }

    def _ensure_seed_articles(self, *, force_refresh: bool = False) -> None:
        if news_cache.get_news(limit=1) and not force_refresh:
            return

        try:
            asyncio.run(aggregator_instance.run_once())
        except RuntimeError:
            loop = asyncio.new_event_loop()
            try:
                loop.run_until_complete(aggregator_instance.run_once())
            finally:
                loop.close()
        except Exception as exc:
            print(f"[COMPARISON] Aggregator seed failed: {exc}")

    def _expand_categories(self, category: Optional[str]) -> List[str]:
        normalized = normalize_category_name(category) if category else None
        if normalized:
            remaining = [cat for cat in CATEGORY_PRIORITY if cat != normalized]
            return [normalized, *remaining]
        return list(CATEGORY_PRIORITY)

    def _keywords_for_category(self, category: str, keywords: Sequence[str]) -> List[str]:
        merged = list(dict.fromkeys([*keywords, *SEARCH_QUERY_HINTS.get(category, []), category.lower()]))
        return merged[:6]

    def _make_cache_key(self, category: Optional[str], language: str, keywords: Optional[Sequence[str]]) -> str:
        normalized_keywords = "|".join(sorted((keywords or [])))
        return f"{normalize_category_name(category) if category else 'all'}::{language or 'en'}::{normalized_keywords}"

    def _store_payload(self, cache_key: str, payload: Dict[str, Any]) -> None:
        with self._lock:
            self._feed_cache[cache_key] = {
                "createdAt": datetime.now(timezone.utc),
                "payload": payload,
            }

    def _clone_payload(self, payload: Dict[str, Any], limit: int) -> Dict[str, Any]:
        cloned = dict(payload)
        cloned["comparisons"] = list(payload.get("comparisons", []))[:limit]
        cloned["count"] = len(cloned["comparisons"])
        return cloned

    def _is_cache_expired(self, cache_hit: Dict[str, Any]) -> bool:
        created_at = cache_hit.get("createdAt")
        if not created_at:
            return True
        return datetime.now(timezone.utc) - created_at > self.cache_ttl


def normalize_article(
    article: Any,
    *,
    provider: str = "unknown",
    source_type: str = "api",
    category_hint: Optional[str] = None,
) -> Dict[str, Any]:
    raw: Dict[str, Any]
    if hasattr(article, "model_dump"):
        raw = article.model_dump()
    elif isinstance(article, dict):
        raw = dict(article)
    else:
        raw = {
            key: getattr(article, key)
            for key in dir(article)
            if not key.startswith("_") and not callable(getattr(article, key))
        }

    title = str(raw.get("title") or "").strip()
    title = html.unescape(title)
    summary = str(raw.get("summary") or raw.get("description") or raw.get("ai_summary") or "").strip()
    summary = html.unescape(summary)
    content = str(raw.get("content") or raw.get("content_text") or raw.get("description") or summary).strip()
    content = html.unescape(content)
    url = str(raw.get("url") or raw.get("link") or "").strip()
    source = str(raw.get("source") or raw.get("source_name") or provider).strip() or provider
    source = html.unescape(source)
    published_value = raw.get("publishedAt") or raw.get("published_at") or raw.get("pub_date") or raw.get("created_at")
    published_dt = parse_datetime_value(published_value)
    category = normalize_category_name(raw.get("category") or raw.get("ai_category") or category_hint or infer_category(" ".join([title, summary, content])))
    source_normalized = normalize_source_name(source)
    article_id = str(raw.get("id") or make_stable_id(source_normalized, url or title))
    language = str(raw.get("language") or "en").strip() or "en"
    country = str(raw.get("country") or "").strip()
    image_url = str(raw.get("imageUrl") or raw.get("image_url") or raw.get("image") or "").strip()
    keywords = raw.get("keywords")
    if not isinstance(keywords, list) or not keywords:
        keywords = extract_keywords(f"{title} {summary}", limit=7)
    entities = raw.get("entities")
    if not isinstance(entities, list):
        entities = []

    normalized = {
        "id": article_id,
        "provider": provider,
        "source": source,
        "sourceType": source_type,
        "sourceNormalized": source_normalized,
        "title": title,
        "summary": summary,
        "description": summary,
        "content": content,
        "author": raw.get("author"),
        "publishedAt": published_dt.isoformat(),
        "published_at": published_dt.isoformat(),
        "category": category,
        "ai_category": category,
        "language": language,
        "country": country,
        "url": url,
        "imageUrl": image_url,
        "image_url": image_url,
        "keywords": keywords,
        "entities": entities,
        "eventId": raw.get("eventId"),
        "eventTitle": raw.get("eventTitle"),
        "ai_summary": raw.get("ai_summary") or summary,
    }
    return normalized


def event_features_to_payload(features: EventFeatures) -> Dict[str, Any]:
    return {
        "articleId": features.article["id"],
        "canonicalEventTitle": features.canonical_title,
        "category": features.category,
        "eventType": features.event_type,
        "action": features.action,
        "outcome": features.outcome,
        "publishedAt": features.published_at.isoformat(),
        "keywords": features.keywords,
        "entities": features.entities,
        "actors": features.actor_entities,
        "places": features.place_entities,
        "signatureTokens": features.signature_tokens,
    }


def extract_event_features(article: Dict[str, Any]) -> EventFeatures:
    title = str(article.get("title") or "")
    summary = str(article.get("summary") or article.get("description") or "")
    content = str(article.get("content") or "")
    merged_text = " ".join(part for part in [title, summary, content] if part).strip()

    entity_candidates = article.get("entities") or []
    if not entity_candidates:
        try:
            entity_candidates = nlp_manager.extract_entities(merged_text)
        except Exception:
            entity_candidates = []

    normalized_entities: List[Dict[str, str]] = []
    seen_entities = set()
    for entity in entity_candidates:
        if not entity:
            continue
        name = str(entity.get("name") or "").strip()
        entity_type = str(entity.get("type") or "ORGANIZATION").strip().upper()
        if len(name) < 2:
            continue
        dedupe_key = f"{entity_type}:{normalize_token(name)}"
        if dedupe_key in seen_entities:
            continue
        seen_entities.add(dedupe_key)
        normalized_entities.append({"name": name, "type": entity_type})

    if not normalized_entities:
        normalized_entities = extract_fallback_entities(f"{title} {summary}")

    entity_names = [normalize_entity_name(entity["name"]) for entity in normalized_entities]
    actor_entities = [
        entity["name"]
        for entity in normalized_entities
        if entity["type"] in {"PERSON", "ORGANIZATION", "ORG"}
    ]
    place_entities = [
        entity["name"]
        for entity in normalized_entities
        if entity["type"] in {"LOCATION", "GPE", "LOC"}
    ]

    keywords = extract_keywords(merged_text, limit=8)
    action = detect_action(merged_text)
    outcome = detect_outcome(merged_text)
    event_type = detect_event_type(merged_text, article.get("category"))
    published_at = parse_datetime_value(article.get("publishedAt") or article.get("published_at"))
    category = normalize_category_name(article.get("category") or article.get("ai_category") or infer_category(merged_text))

    canonical_title = build_canonical_title(title, actor_entities, place_entities, action, outcome)
    signature_tokens = list(dict.fromkeys([*entity_names, *map(normalize_token, keywords), normalize_token(action), normalize_token(outcome), normalize_token(event_type)]))

    return EventFeatures(
        article=article,
        canonical_title=canonical_title,
        category=category,
        event_type=event_type,
        action=action,
        outcome=outcome,
        published_at=published_at,
        keywords=keywords,
        entities=normalized_entities,
        entity_names=[token for token in entity_names if token],
        actor_entities=actor_entities,
        place_entities=place_entities,
        signature_tokens=[token for token in signature_tokens if token],
    )


def build_event_clusters(articles: List[Dict[str, Any]]) -> List[EventCluster]:
    features = [extract_event_features(article) for article in articles if article and article.get("title")]
    features.sort(key=lambda item: item.published_at, reverse=True)
    clusters: List[EventCluster] = []

    for feature in features:
        matched_cluster: Optional[EventCluster] = None
        best_match_score = 0.0
        best_match_pair: Optional[Dict[str, Any]] = None

        for cluster in clusters:
            candidate_matches = []
            for existing_feature in cluster.features[-5:]:
                pair_match = compute_match(feature, existing_feature)
                if pair_match["isMatch"]:
                    candidate_matches.append((pair_match["score"], existing_feature, pair_match))
            if candidate_matches:
                candidate_matches.sort(key=lambda item: item[0], reverse=True)
                top_score, _, pair_match = candidate_matches[0]
                if top_score > best_match_score:
                    best_match_score = top_score
                    matched_cluster = cluster
                    best_match_pair = pair_match

        if matched_cluster:
            matched_cluster.features.append(feature)
            matched_cluster.articles.append(feature.article)
            matched_cluster.sources.add(feature.article["source"])
            matched_cluster.updated_at = max(matched_cluster.updated_at, feature.published_at)
            if best_match_pair and best_match_pair["score"] > matched_cluster.max_pair_score:
                matched_cluster.max_pair_score = best_match_pair["score"]
                matched_cluster.best_pair = {
                    "left": feature.article,
                    "right": best_match_pair["otherArticle"],
                    "score": best_match_pair["score"],
                    "breakdown": best_match_pair["breakdown"],
                }
            continue

        cluster = EventCluster(
            event_id=str(uuid.uuid4()),
            event_title=feature.canonical_title,
            category=feature.category,
            event_type=feature.event_type,
        )
        cluster.features.append(feature)
        cluster.articles.append(feature.article)
        cluster.sources.add(feature.article["source"])
        cluster.updated_at = feature.published_at
        clusters.append(cluster)

    valid_clusters: List[EventCluster] = []
    for cluster in clusters:
        if len(cluster.sources) < 2:
            continue

        cluster.best_pair = choose_best_comparison_pair(cluster.features)
        if cluster.best_pair:
            cluster.max_pair_score = cluster.best_pair["score"]

        if cluster.best_pair:
            valid_clusters.append(cluster)

    valid_clusters.sort(
        key=lambda cluster: (cluster.max_pair_score or (cluster.best_pair or {}).get("score", 0), len(cluster.sources)),
        reverse=True,
    )
    return valid_clusters


def compute_match(left: EventFeatures, right: EventFeatures) -> Dict[str, Any]:
    if left.article["sourceNormalized"] == right.article["sourceNormalized"]:
        return {
            "isMatch": False,
            "score": 0.0,
            "reason": "same_source",
            "otherArticle": right.article,
            "breakdown": {"sourceDiversity": 0.0},
        }

    time_hours = abs((left.published_at - right.published_at).total_seconds()) / 3600
    if time_hours > 48:
        return {
            "isMatch": False,
            "score": 0.0,
            "reason": "time_window_exceeded",
            "otherArticle": right.article,
            "breakdown": {"timeProximity": round(max(0.0, 1 - (time_hours / 48)), 3)},
        }

    entity_overlap = jaccard_similarity(
        left.entity_names or [normalize_token(keyword) for keyword in left.keywords],
        right.entity_names or [normalize_token(keyword) for keyword in right.keywords],
    )
    keyword_overlap = jaccard_similarity(left.signature_tokens, right.signature_tokens)
    actor_overlap = jaccard_similarity([normalize_entity_name(item) for item in left.actor_entities], [normalize_entity_name(item) for item in right.actor_entities])
    place_overlap = jaccard_similarity([normalize_entity_name(item) for item in left.place_entities], [normalize_entity_name(item) for item in right.place_entities])

    anchor_overlap = max(entity_overlap, keyword_overlap, actor_overlap)
    if anchor_overlap < 0.40:
        return {
            "isMatch": False,
            "score": round(anchor_overlap * 100, 1),
            "reason": "entity_overlap_below_threshold",
            "otherArticle": right.article,
            "breakdown": {
                "entityOverlap": round(entity_overlap, 3),
                "keywordOverlap": round(keyword_overlap, 3),
                "actorOverlap": round(actor_overlap, 3),
                "placeOverlap": round(place_overlap, 3),
            },
        }

    title_similarity = normalized_similarity(left.article["title"], right.article["title"])
    summary_similarity = normalized_similarity(left.article.get("summary"), right.article.get("summary"))
    canonical_similarity = normalized_similarity(left.canonical_title, right.canonical_title)
    event_type_match = 1.0 if left.event_type == right.event_type else 0.0
    category_match = 1.0 if left.category == right.category else 0.0
    action_match = 1.0 if left.action and left.action == right.action else 0.0
    outcome_match = 1.0 if left.outcome and left.outcome == right.outcome else 0.0
    time_proximity = max(0.0, 1 - (time_hours / 48.0))

    score = (
        anchor_overlap * 0.36 +
        title_similarity * 0.16 +
        summary_similarity * 0.12 +
        canonical_similarity * 0.12 +
        place_overlap * 0.06 +
        category_match * 0.06 +
        event_type_match * 0.05 +
        action_match * 0.04 +
        outcome_match * 0.03 +
        time_proximity * 0.10
    ) * 100

    is_match = score >= 62.0
    return {
        "isMatch": is_match,
        "score": round(score, 1),
        "reason": "matched" if is_match else "score_below_threshold",
        "otherArticle": right.article,
        "breakdown": {
            "entityOverlap": round(entity_overlap, 3),
            "keywordOverlap": round(keyword_overlap, 3),
            "actorOverlap": round(actor_overlap, 3),
            "placeOverlap": round(place_overlap, 3),
            "titleSimilarity": round(title_similarity, 3),
            "summarySimilarity": round(summary_similarity, 3),
            "canonicalSimilarity": round(canonical_similarity, 3),
            "eventTypeMatch": round(event_type_match, 3),
            "categoryMatch": round(category_match, 3),
            "actionMatch": round(action_match, 3),
            "outcomeMatch": round(outcome_match, 3),
            "timeProximity": round(time_proximity, 3),
        },
    }


def compute_editorial_contrast(
    left: EventFeatures,
    right: EventFeatures,
    breakdown: Optional[Dict[str, Any]] = None,
) -> float:
    details = breakdown or {}
    title_similarity = float(details.get("titleSimilarity") or normalized_similarity(left.article.get("title"), right.article.get("title")))
    summary_similarity = float(details.get("summarySimilarity") or normalized_similarity(left.article.get("summary"), right.article.get("summary")))

    left_title_tokens = analysis_tokenize(left.article.get("title") or "")
    right_title_tokens = analysis_tokenize(right.article.get("title") or "")
    left_body_tokens = analysis_tokenize(analysis_body_text(left.article))
    right_body_tokens = analysis_tokenize(analysis_body_text(right.article))

    title_delta = analysis_symmetric_token_ratio(left_title_tokens, right_title_tokens)
    body_delta = analysis_symmetric_token_ratio(left_body_tokens, right_body_tokens)
    actor_delta = analysis_symmetric_token_ratio(left.actor_entities, right.actor_entities)
    quote_delta = 1.0 if bool(analysis_quote_phrases(analysis_body_text(left.article))) != bool(analysis_quote_phrases(analysis_body_text(right.article))) else 0.0

    contrast = (
        (1 - title_similarity) * 0.34 +
        (1 - summary_similarity) * 0.26 +
        title_delta * 0.14 +
        body_delta * 0.18 +
        actor_delta * 0.05 +
        quote_delta * 0.03
    )
    return round(max(0.0, min(1.0, contrast)), 3)


def is_near_duplicate_pair(
    left: EventFeatures,
    right: EventFeatures,
    breakdown: Optional[Dict[str, Any]] = None,
) -> bool:
    details = breakdown or {}
    title_similarity = float(details.get("titleSimilarity") or normalized_similarity(left.article.get("title"), right.article.get("title")))
    summary_similarity = float(details.get("summarySimilarity") or normalized_similarity(left.article.get("summary"), right.article.get("summary")))
    keyword_overlap = float(details.get("keywordOverlap") or 0.0)
    return title_similarity >= 0.94 and summary_similarity >= 0.90 and keyword_overlap >= 0.65


def choose_best_comparison_pair(features: Sequence[EventFeatures]) -> Optional[Dict[str, Any]]:
    selected_pair = None
    selected_score = -1.0

    for index, left in enumerate(features):
        for right in features[index + 1:]:
            match = compute_match(left, right)
            if not match["isMatch"]:
                continue

            contrast = compute_editorial_contrast(left, right, match["breakdown"])
            near_duplicate = is_near_duplicate_pair(left, right, match["breakdown"])
            selection_score = (match["score"] * 0.72) + (contrast * 28.0) - (18.0 if near_duplicate else 0.0)

            if selection_score > selected_score:
                selected_score = selection_score
                selected_pair = {
                    "left": left.article,
                    "right": right.article,
                    "score": match["score"],
                    "breakdown": {
                        **match["breakdown"],
                        "editorialContrast": contrast,
                        "nearDuplicate": near_duplicate,
                        "selectionScore": round(selection_score, 1),
                    },
                }

    return selected_pair


def build_comparison_analysis(left: Dict[str, Any], right: Dict[str, Any]) -> Dict[str, Any]:
    left_entities = extract_event_features(left)
    right_entities = extract_event_features(right)
    pair_meta = compose_pair_meta(left, right, left_entities, right_entities)

    headline_a, headline_b = compose_headline_section(left, right, pair_meta)
    focus_a, focus_b = compose_focus_section(left, right, left_entities, right_entities, pair_meta)
    tone_a, tone_b = compose_tone_section(left, right, pair_meta)
    actor_a, actor_b = compose_actor_section(left, right, left_entities, right_entities, pair_meta)
    missing_a, missing_b = compose_missing_section(left, right, left_entities, right_entities, pair_meta)

    return {
        "headlineComparison": {
            "sourceA": headline_a,
            "sourceB": headline_b,
        },
        "focusComparison": {
            "sourceA": focus_a,
            "sourceB": focus_b,
        },
        "toneComparison": {
            "sourceA": tone_a,
            "sourceB": tone_b,
        },
        "actorPresentation": {
            "sourceA": actor_a,
            "sourceB": actor_b,
        },
        "missingOrUnderplayed": {
            "sourceA": missing_a,
            "sourceB": missing_b,
        },
        "overallSummary": compose_overall_summary(left, right, pair_meta),
    }


def attach_event_to_article(article: Dict[str, Any], event_id: str, event_title: str) -> Dict[str, Any]:
    payload = dict(article)
    payload["eventId"] = event_id
    payload["eventTitle"] = event_title
    return payload


def dedupe_articles(articles: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    deduped: List[Dict[str, Any]] = []
    seen_keys = set()
    for article in articles:
        if not article:
            continue
        title_key = normalize_text(article.get("title"))
        url_key = normalize_text(article.get("url"))
        source_key = normalize_source_name(article.get("source"))
        dedupe_key = url_key or f"{source_key}:{title_key}"
        if not dedupe_key or dedupe_key in seen_keys:
            continue
        seen_keys.add(dedupe_key)
        deduped.append(article)
    return deduped


def infer_category(text: str) -> str:
    try:
        return normalize_category_name(nlp_manager.classify_text(text))
    except Exception:
        lowered = (text or "").lower()
        if any(word in lowered for word in ["minister", "president", "government", "court", "seçim", "bakan", "cumhurbaş", "cumhurbas", "meclis"]):
            return "Politics"
        if any(word in lowered for word in ["inflation", "interest rate", "market", "dolar", "borsa", "merkez bank", "faiz"]):
            return "Economy"
        if any(word in lowered for word in ["football", "basketball", "match", "goal", "maç", "gol", "lig", "şampiyon", "sampiyon"]):
            return "Sports"
        if any(word in lowered for word in ["ai", "technology", "software", "apple", "google", "microsoft", "teknoloji", "yapay zeka"]):
            return "Technology"
        return "World"


def normalize_category_name(category: Optional[str]) -> str:
    if not category:
        return "World"
    lowered = str(category).strip().lower()
    mapping = {
        "politics": "Politics",
        "politika": "Politics",
        "nation": "Politics",
        "economy": "Economy",
        "business": "Economy",
        "ekonomi": "Economy",
        "world": "World",
        "dünya": "World",
        "dunya": "World",
        "technology": "Technology",
        "teknoloji": "Technology",
        "tech": "Technology",
        "sports": "Sports",
        "spor": "Sports",
        "health": "Health",
        "sağlık": "Health",
        "saglik": "Health",
        "science": "Technology",
    }
    return mapping.get(lowered, str(category).strip().title())


def normalize_source_name(source: Optional[str]) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(source or "").lower())


def normalize_token(value: str) -> str:
    cleaned = re.sub(r"[^a-z0-9çğıöşü]+", "", str(value or "").lower())
    return cleaned.strip()


def normalize_entity_name(value: str) -> str:
    parts = [
        token for token in normalize_text(value).split()
        if token and token not in STOP_WORDS
    ]
    return "".join(parts)


def normalize_text(value: Optional[str]) -> str:
    text = re.sub(r"\s+", " ", str(value or "").lower())
    text = re.sub(r"[^a-z0-9çğıöşü\s]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def tokenize_text(text: str) -> List[str]:
    cleaned = normalize_text(text)
    return [token for token in cleaned.split() if len(token) > 2 and token not in STOP_WORDS]


def extract_keywords(text: str, limit: int = 8) -> List[str]:
    tokens = tokenize_text(text)
    counts = Counter(tokens)
    keywords = [token for token, _ in counts.most_common(limit * 2)]
    deduped = []
    for token in keywords:
        if token in deduped:
            continue
        deduped.append(token)
        if len(deduped) >= limit:
            break
    return deduped


def extract_fallback_entities(text: str) -> List[Dict[str, str]]:
    entities = []
    matches = re.findall(r"\b([A-ZÇĞİÖŞÜ][a-zçğıöşü]+(?:\s+[A-ZÇĞİÖŞÜ][a-zçğıöşü]+)+)\b", text or "")
    matches += re.findall(r"\b([A-Z]{2,}(?:\s+[A-Z][a-z]+)?)\b", text or "")
    seen = set()
    for match in matches:
        token = normalize_token(match)
        if len(token) < 3 or token in seen:
            continue
        seen.add(token)
        entities.append({"name": match, "type": "ORGANIZATION"})
    return entities[:5]


def detect_action(text: str) -> str:
    lowered = normalize_text(text)
    for term in ACTION_TERMS:
        if normalize_text(term) in lowered:
            return term
    return "reported"


def detect_outcome(text: str) -> str:
    lowered = normalize_text(text)
    for term in OUTCOME_TERMS:
        if normalize_text(term) in lowered:
            return term
    return "update"


def detect_event_type(text: str, category: Optional[str]) -> str:
    lowered = normalize_text(text)
    if any(term in lowered for term in ["court", "judge", "ruling", "mahkeme", "yargı", "yargi"]):
        return "court_decision"
    if any(term in lowered for term in ["interest rate", "inflation", "economic", "faiz", "enflasyon", "merkez bank"]):
        return "economic_decision"
    if any(term in lowered for term in ["statement", "announced", "açıkladı", "açıklama", "duyurdu"]):
        return "official_statement"
    if any(term in lowered for term in ["attack", "conflict", "war", "ceasefire", "saldırı", "çatışma", "savaş", "ateskes", "ateşkes"]):
        return "international_conflict"
    if any(term in lowered for term in ["match", "final", "league", "gol", "maç", "lig", "final"]):
        return "major_match"
    if any(term in lowered for term in ["earthquake", "flood", "wildfire", "deprem", "sel", "yangın", "yangin"]):
        return "disaster"
    normalized_category = normalize_category_name(category)
    return {
        "Politics": "official_statement",
        "Economy": "economic_decision",
        "Sports": "major_match",
        "Technology": "technology_development",
        "World": "world_development",
    }.get(normalized_category, "general_update")


def build_canonical_title(title: str, actors: Sequence[str], places: Sequence[str], action: str, outcome: str) -> str:
    actor_part = ", ".join(list(actors)[:2])
    place_part = f" in {places[0]}" if places else ""
    if actor_part:
        return f"{actor_part} {action} {outcome}{place_part}".strip()
    trimmed_title = re.sub(r"\s+", " ", title or "").strip()
    return trimmed_title[:160] if trimmed_title else f"{action} {outcome}".strip()


def parse_datetime_value(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if not value:
        return datetime.now(timezone.utc)

    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(float(value), tz=timezone.utc)

    text = str(value).strip()
    if not text:
        return datetime.now(timezone.utc)

    for parser in (
        lambda input_text: datetime.fromisoformat(input_text.replace("Z", "+00:00")),
        parsedate_to_datetime,
    ):
        try:
            parsed = parser(text)
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc)
        except Exception:
            continue

    return datetime.now(timezone.utc)


def jaccard_similarity(left: Sequence[str], right: Sequence[str]) -> float:
    left_set = {item for item in left if item}
    right_set = {item for item in right if item}
    if not left_set or not right_set:
        return 0.0
    intersection = left_set & right_set
    union = left_set | right_set
    return len(intersection) / len(union)


def normalized_similarity(left: Optional[str], right: Optional[str]) -> float:
    left_text = normalize_text(left)
    right_text = normalize_text(right)
    if not left_text or not right_text:
        return 0.0
    return SequenceMatcher(None, left_text, right_text).ratio()


def analysis_visible_text(value: Optional[str]) -> str:
    text = html.unescape(str(value or "")).replace("\xa0", " ")
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"https?://\S+", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bwww\.\S+", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bThe post\b.*?\bappeared first on\b[^.]*\.?", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"#site[_-]?link\w*", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\b\d{1,2}[./-]\d{1,2}[./-]\d{2,4}\b", " ", text)
    text = re.sub(r"\b\d{1,2}[./-]\d{4}\b", " ", text)
    text = re.sub(r"\b\d{1,2}:\d{2}\b", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def analysis_body_text(article: Dict[str, Any]) -> str:
    pieces: List[str] = []
    seen = set()
    title = analysis_visible_text(article.get("title"))
    for key in ("summary", "description", "content", "ai_summary"):
        if not article.get(key):
            continue
        value = analysis_visible_text(article.get(key))
        if title:
            value = re.sub(re.escape(title), " ", value, count=1, flags=re.IGNORECASE)
            value = re.sub(r"\s+", " ", value).strip()
        normalized = normalize_text(value)
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        pieces.append(value)
    return " ".join(pieces).strip()


def analysis_raw_tokens(text: str) -> List[str]:
    lowered = analysis_visible_text(text).lower()
    return re.findall(r"[^\W_]+", lowered, flags=re.UNICODE)


def analysis_is_meaningful_token(token: str) -> bool:
    cleaned = normalize_text(token)
    if not cleaned:
        return False
    if cleaned in STOP_WORDS or cleaned in ANALYSIS_NOISE_TOKENS:
        return False
    if any(char.isdigit() for char in cleaned):
        return True
    if cleaned in ANALYSIS_IMPORTANT_SHORT_TOKENS:
        return True
    return len(cleaned) >= 5


def analysis_tokenize(text: str) -> List[str]:
    return [token for token in analysis_raw_tokens(text) if analysis_is_meaningful_token(token)]


def analysis_quote_phrases(text: str) -> List[str]:
    matches = re.findall(r"[\"“”«»]([^\"“”«»]{3,120})[\"“”«»]", analysis_visible_text(text))
    phrases: List[str] = []
    seen = set()
    for match in matches:
        value = analysis_visible_text(match)
        key = normalize_text(value)
        if not key or key in seen:
            continue
        seen.add(key)
        phrases.append(value)
    return phrases[:3]


def analysis_numbers(text: str) -> List[str]:
    matches = re.findall(r"\b\d[\d\.,%:-]*\b", analysis_visible_text(text))
    values: List[str] = []
    seen = set()
    for match in matches:
        cleaned = match.strip()
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        values.append(cleaned)
    return values[:4]


def analysis_distinctive_terms(primary_tokens: Sequence[str], secondary_tokens: Sequence[str], limit: int = 4) -> List[str]:
    secondary_set = {normalize_text(token) for token in secondary_tokens if analysis_is_meaningful_token(token)}
    values: List[str] = []
    seen = set()
    for token in primary_tokens:
        normalized = normalize_text(token)
        if not analysis_is_meaningful_token(token) or normalized in secondary_set or normalized in seen:
            continue
        values.append(token)
        seen.add(normalized)
        if len(values) >= limit:
            break
    return values


def analysis_diff_phrases(primary_text: str, secondary_text: str, limit: int = 3) -> List[str]:
    primary_tokens = analysis_raw_tokens(primary_text)
    secondary_tokens = analysis_raw_tokens(secondary_text)
    matcher = SequenceMatcher(
        None,
        [normalize_text(token) for token in primary_tokens],
        [normalize_text(token) for token in secondary_tokens],
    )
    phrases: List[str] = []
    seen = set()

    for tag, i1, i2, _, _ in matcher.get_opcodes():
        if tag not in {"replace", "delete"}:
            continue
        segment = primary_tokens[i1:i2]
        meaningful = [token for token in segment if analysis_is_meaningful_token(token)]
        if not any(any(char.isalpha() for char in token) for token in meaningful):
            continue
        if len(meaningful) < 2 and not any(any(char.isdigit() for char in token) for token in meaningful):
            continue
        phrase = " ".join(meaningful[:6]).strip()
        normalized = normalize_text(phrase)
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        phrases.append(phrase)
        if len(phrases) >= limit:
            break

    return phrases


def analysis_symmetric_token_ratio(left_tokens: Sequence[str], right_tokens: Sequence[str]) -> float:
    left_set = {normalize_text(token) for token in left_tokens if token}
    right_set = {normalize_text(token) for token in right_tokens if token}
    union = left_set | right_set
    if not union:
        return 0.0
    return len(left_set ^ right_set) / len(union)


def analysis_human_join(items: Sequence[str]) -> str:
    values = [analysis_visible_text(item) for item in items if analysis_visible_text(item)]
    if not values:
        return ""
    if len(values) == 1:
        return values[0]
    if len(values) == 2:
        return f"{values[0]} ve {values[1]}"
    return f"{', '.join(values[:-1])} ve {values[-1]}"


def analysis_tone_profile(text: str) -> Dict[str, int]:
    visible = analysis_visible_text(text)
    lowered = normalize_text(visible)
    return {
        "dramatic": sum(1 for term in ["crisis", "shock", "urgent", "historic", "kriz", "şok", "acil", "sert"] if term in lowered),
        "attribution": sum(1 for term in ["said", "told", "according", "reported", "confirmed", "stated", "belirtti", "açıkladı", "duyurdu", "iddia"] if term in lowered),
        "quotes": len(analysis_quote_phrases(visible)),
        "punctuation": visible.count("!") + visible.count("?"),
        "length": len(analysis_tokenize(visible)),
    }


def compose_pair_meta(
    left: Dict[str, Any],
    right: Dict[str, Any],
    left_features: EventFeatures,
    right_features: EventFeatures,
) -> Dict[str, Any]:
    left_title = analysis_visible_text(left.get("title"))
    right_title = analysis_visible_text(right.get("title"))
    left_body = analysis_body_text(left)
    right_body = analysis_body_text(right)
    left_title_tokens = analysis_tokenize(left_title)
    right_title_tokens = analysis_tokenize(right_title)
    left_body_tokens = analysis_tokenize(left_body)
    right_body_tokens = analysis_tokenize(right_body)
    left_actor_keys = [normalize_entity_name(item) for item in left_features.actor_entities]
    right_actor_keys = [normalize_entity_name(item) for item in right_features.actor_entities]
    title_similarity = normalized_similarity(left_title, right_title)
    summary_similarity = normalized_similarity(left_body, right_body)

    return {
        "leftTitle": left_title,
        "rightTitle": right_title,
        "leftBody": left_body,
        "rightBody": right_body,
        "titleSimilarity": title_similarity,
        "summarySimilarity": summary_similarity,
        "nearDuplicate": title_similarity >= 0.94 and summary_similarity >= 0.90,
        "editorialContrast": compute_editorial_contrast(
            left_features,
            right_features,
            {"titleSimilarity": title_similarity, "summarySimilarity": summary_similarity},
        ),
        "leftTitleDiffPhrases": analysis_diff_phrases(left_title, right_title),
        "rightTitleDiffPhrases": analysis_diff_phrases(right_title, left_title),
        "leftBodyDiffPhrases": analysis_diff_phrases(left_body, right_body),
        "rightBodyDiffPhrases": analysis_diff_phrases(right_body, left_body),
        "leftTitleUnique": analysis_distinctive_terms(left_title_tokens, right_title_tokens),
        "rightTitleUnique": analysis_distinctive_terms(right_title_tokens, left_title_tokens),
        "leftBodyUnique": analysis_distinctive_terms(left_body_tokens, right_body_tokens),
        "rightBodyUnique": analysis_distinctive_terms(right_body_tokens, left_body_tokens),
        "leftActorsUnique": [actor for actor in left_features.actor_entities if normalize_entity_name(actor) not in set(right_actor_keys)][:3],
        "rightActorsUnique": [actor for actor in right_features.actor_entities if normalize_entity_name(actor) not in set(left_actor_keys)][:3],
        "leftNumbersUnique": analysis_distinctive_terms(analysis_numbers(left_title + " " + left_body), analysis_numbers(right_title + " " + right_body), limit=3),
        "rightNumbersUnique": analysis_distinctive_terms(analysis_numbers(right_title + " " + right_body), analysis_numbers(left_title + " " + left_body), limit=3),
        "leftQuotes": analysis_quote_phrases(left_title + " " + left_body),
        "rightQuotes": analysis_quote_phrases(right_title + " " + right_body),
        "leftTone": analysis_tone_profile(left_body or left_title),
        "rightTone": analysis_tone_profile(right_body or right_title),
    }


def compose_headline_section(left: Dict[str, Any], right: Dict[str, Any], pair_meta: Dict[str, Any]) -> Tuple[str, str]:
    left_title = pair_meta["leftTitle"]
    right_title = pair_meta["rightTitle"]
    if pair_meta["titleSimilarity"] >= 0.96:
        return (
            "Başlık karşı kaynakla neredeyse birebir aynı; ayrı bir editoryal çerçeve kurmuyor.",
            "Source A ile aynı başlık omurgasını koruyor; ek bağlam veya yeni vurgu eklemiyor.",
        )

    def sentence(title: str, own_unique: List[str], own_phrases: List[str], other_title: str, side: str) -> str:
        parts: List[str] = []
        if own_phrases and pair_meta["titleSimilarity"] < 0.9:
            parts.append(f"\"{own_phrases[0]}\" ayrıntısını başlığa taşıyor")
        elif own_unique and pair_meta["titleSimilarity"] < 0.88:
            parts.append(f"{analysis_human_join(own_unique[:3])} vurgusunu öne çıkarıyor")
        if ":" in title:
            parts.append("iki parçalı bir başlık kurup bağlam ekliyor")
        if analysis_quote_phrases(title):
            parts.append("alıntı ifadesini başlığa taşıyor")
        if len(analysis_tokenize(title)) > len(analysis_tokenize(other_title)) + 3:
            parts.append("karşı kaynağa göre daha ayrıntılı yazılmış")
        elif len(analysis_tokenize(title)) + 3 < len(analysis_tokenize(other_title)):
            parts.append("karşı kaynağa göre daha kısa ve doğrudan")
        elif pair_meta["titleSimilarity"] >= 0.88 and not own_phrases:
            parts.append("karşı kaynaktaki başlık yapısını büyük ölçüde koruyor")
        if not parts:
            parts.append("olayı doğrudan veriyor")
        prefix = "Başlık" if side == "left" else "Başlıkta"
        return f"{prefix} " + "; ".join(parts) + "."

    return (
        sentence(left_title, pair_meta["leftTitleUnique"], pair_meta["leftTitleDiffPhrases"], right_title, "left"),
        sentence(right_title, pair_meta["rightTitleUnique"], pair_meta["rightTitleDiffPhrases"], left_title, "right"),
    )


def compose_focus_section(
    left: Dict[str, Any],
    right: Dict[str, Any],
    left_features: EventFeatures,
    right_features: EventFeatures,
    pair_meta: Dict[str, Any],
) -> Tuple[str, str]:
    left_strong_details = any([
        pair_meta["leftBodyDiffPhrases"],
        pair_meta["leftActorsUnique"],
        pair_meta["leftNumbersUnique"],
        pair_meta["leftQuotes"],
    ])
    right_strong_details = any([
        pair_meta["rightBodyDiffPhrases"],
        pair_meta["rightActorsUnique"],
        pair_meta["rightNumbersUnique"],
        pair_meta["rightQuotes"],
    ])
    if pair_meta["summarySimilarity"] >= 0.95 and not left_strong_details and not right_strong_details:
        return (
            "Metin, ana bilgi omurgasında karşı kaynakla neredeyse aynı; belirgin ek vurgu üretmiyor.",
            "İçerik, Source A ile aynı temel bilgileri tekrar ediyor; odak farkı çok sınırlı.",
        )

    if pair_meta["editorialContrast"] < 0.14 and not left_strong_details and not right_strong_details:
        return (
            "Metin, temel olay akışını karşı kaynakla çok benzer kuruyor; eklediği özgün detay sınırlı.",
            "İçerik, Source A ile aynı ana bilgileri taşıyor; odak farkı ancak küçük ifade farklarında kalıyor.",
        )

    def sentence(
        own_features: EventFeatures,
        unique_terms: List[str],
        diff_phrases: List[str],
        unique_actors: List[str],
        unique_numbers: List[str],
        quotes: List[str],
    ) -> str:
        parts: List[str] = []
        if unique_actors:
            parts.append(f"{analysis_human_join(unique_actors[:2])} aktörünü açıkça merkeze alıyor")
        elif own_features.actor_entities and pair_meta["editorialContrast"] >= 0.2:
            parts.append(f"{analysis_human_join(own_features.actor_entities[:2])} ekseninden ilerliyor")
        if quotes:
            parts.append(f"\"{quotes[0][:52]}\" ifadesini öne çıkarıyor")
        if unique_numbers:
            parts.append(f"{analysis_human_join(unique_numbers[:2])} sayısal detayı veriyor")
        if diff_phrases:
            parts.append(f"\"{diff_phrases[0]}\" ayrıntısını ekliyor")
        elif len(unique_terms) >= 2 and pair_meta["editorialContrast"] >= 0.2:
            parts.append(f"{analysis_human_join(unique_terms[:3])} ayrıntılarını belirginleştiriyor")
        if own_features.place_entities and pair_meta["editorialContrast"] >= 0.22:
            parts.append(f"{own_features.place_entities[0]} bağlamını görünür tutuyor")
        if not parts:
            parts.append("ana gelişmeyi karşı kaynakla büyük ölçüde aynı çerçevede aktarıyor")
        return "Metin " + "; ".join(parts) + "."

    return (
        sentence(left_features, pair_meta["leftBodyUnique"], pair_meta["leftBodyDiffPhrases"], pair_meta["leftActorsUnique"], pair_meta["leftNumbersUnique"], pair_meta["leftQuotes"]),
        sentence(right_features, pair_meta["rightBodyUnique"], pair_meta["rightBodyDiffPhrases"], pair_meta["rightActorsUnique"], pair_meta["rightNumbersUnique"], pair_meta["rightQuotes"]),
    )


def compose_tone_section(left: Dict[str, Any], right: Dict[str, Any], pair_meta: Dict[str, Any]) -> Tuple[str, str]:
    left_tone = pair_meta["leftTone"]
    right_tone = pair_meta["rightTone"]
    if pair_meta["nearDuplicate"]:
        return (
            "Ton nötr ve ajans dili çizgisinde; karşı kaynaktan belirgin biçimde ayrışmıyor.",
            "Source A ile aynı nötr haber tonunu sürdürüyor; fark daha çok ifade düzeyinde kalıyor.",
        )

    def sentence(current: Dict[str, int], other: Dict[str, int], side: str) -> str:
        parts: List[str] = []
        if current["attribution"] > other["attribution"]:
            parts.append("atıf ve kaynak belirtme fiillerini daha çok kullanıyor")
        if current["quotes"] > other["quotes"]:
            parts.append("alıntı tonunu daha görünür kılıyor")
        if current["dramatic"] > other["dramatic"] or current["punctuation"] > other["punctuation"]:
            parts.append("daha sert ve dikkat çekici kelimeler seçiyor")
        if current["length"] > other["length"] * 1.2:
            parts.append("daha açıklayıcı ve ayrıntılı bir anlatım kuruyor")
        elif current["length"] < other["length"] * 0.8:
            parts.append("daha kısa ve doğrudan yazıyor")
        if not parts:
            parts.append("ton olarak karşı kaynağa yakın, nötr bir çizgide kalıyor")
        prefix = "Dil" if side == "left" else "Anlatım"
        return f"{prefix} " + "; ".join(parts) + "."

    return (
        sentence(left_tone, right_tone, "left"),
        sentence(right_tone, left_tone, "right"),
    )


def compose_actor_section(
    left: Dict[str, Any],
    right: Dict[str, Any],
    left_features: EventFeatures,
    right_features: EventFeatures,
    pair_meta: Dict[str, Any],
) -> Tuple[str, str]:
    def sentence(own_features: EventFeatures, unique_actors: List[str], other_features: EventFeatures, side: str) -> str:
        if unique_actors:
            return f"Aktör sunumunda {analysis_human_join(unique_actors[:2])} özellikle öne çıkarılıyor."
        if pair_meta["editorialContrast"] < 0.18:
            if side == "left":
                return "Aktör çerçevesi karşı kaynakla büyük ölçüde aynı; yeni bir kişi veya kurum ön plana çıkmıyor."
            return "Source A ile benzer aktör dizilimi korunuyor; farklı bir kişi/kurum ekseni kurulmuyor."
        if own_features.actor_entities and other_features.actor_entities:
            if side == "left":
                return f"Aktörler {analysis_human_join(own_features.actor_entities[:2])} üzerinden veriliyor; karşı kaynağa göre ek bir yeni isim öne çıkmıyor."
            return f"Source A ile benzer biçimde {analysis_human_join(own_features.actor_entities[:2])} ekseni korunuyor; farklı bir aktör çerçevesi kurmuyor."
        if own_features.place_entities:
            return f"Aktör yerine mekansal bağlam öne çıkıyor; {own_features.place_entities[0]} daha görünür."
        if side == "left":
            return "Aktör sunumu genel çerçevede kalıyor; kişi veya kurum vurgusu sınırlı."
        return "Kişi ve kurum konumlandırması sınırlı; anlatı daha çok olay cümlesi üzerinden ilerliyor."

    return (
        sentence(left_features, pair_meta["leftActorsUnique"], right_features, "left"),
        sentence(right_features, pair_meta["rightActorsUnique"], left_features, "right"),
    )


def compose_missing_section(
    left: Dict[str, Any],
    right: Dict[str, Any],
    left_features: EventFeatures,
    right_features: EventFeatures,
    pair_meta: Dict[str, Any],
) -> Tuple[str, str]:
    def sentence(missing_terms: List[str], missing_phrases: List[str], missing_actors: List[str], missing_numbers: List[str], missing_quotes: List[str], side: str) -> str:
        parts: List[str] = []
        if missing_actors:
            parts.append(f"{analysis_human_join(missing_actors[:2])} aktörü")
        if missing_numbers:
            parts.append(f"{analysis_human_join(missing_numbers[:2])} sayısal bilgisi")
        if missing_quotes:
            parts.append(f"\"{missing_quotes[0][:45]}\" ifadesi")
        if missing_phrases:
            parts.append(f"\"{missing_phrases[0]}\" ayrıntısı")
        elif len(missing_terms) >= 2:
            parts.append(f"{analysis_human_join(missing_terms[:3])} ayrıntısı")
        if not parts:
            if side == "left":
                return "Karşı kaynakta olup burada belirgin biçimde eksik kalan bir bilgi görünmüyor."
            return "Source A'da yer alan ana bilgiler burada da mevcut; kayda değer ek eksik farkı yok."
        return "Karşı kaynakta öne çıkan " + analysis_human_join(parts) + " burada daha zayıf kalıyor."

    return (
        sentence(pair_meta["rightBodyUnique"], pair_meta["rightBodyDiffPhrases"], pair_meta["rightActorsUnique"], pair_meta["rightNumbersUnique"], pair_meta["rightQuotes"], "left"),
        sentence(pair_meta["leftBodyUnique"], pair_meta["leftBodyDiffPhrases"], pair_meta["leftActorsUnique"], pair_meta["leftNumbersUnique"], pair_meta["leftQuotes"], "right"),
    )


def compose_overall_summary(left: Dict[str, Any], right: Dict[str, Any], pair_meta: Dict[str, Any]) -> str:
    left_source = analysis_visible_text(left.get("source") or "Kaynak A")
    right_source = analysis_visible_text(right.get("source") or "Kaynak B")
    if pair_meta["nearDuplicate"]:
        return (
            f"{left_source} ile {right_source} metinleri büyük ölçüde aynı haber kopyasını kullanıyor. "
            "Belirgin editoryal fark çok sınırlı; farklar daha çok küçük kelime seçimi ve biçim düzeyinde kalıyor."
        )

    if pair_meta["editorialContrast"] < 0.14:
        return (
            f"{left_source} ile {right_source} aynı olayı neredeyse aynı bilgi omurgasıyla veriyor. "
            "Fark, esas olarak başlık uzunluğu ve küçük kelime seçimlerinde kalıyor; belirgin editoryal ayrışma görünmüyor."
        )

    def focus_phrase(source: str, phrases: List[str], terms: List[str], actors: List[str], quotes: List[str]) -> str:
        if actors:
            return f"{source}, {analysis_human_join(actors[:2])} aktörünü daha görünür kılıyor"
        if quotes:
            return f"{source}, \"{quotes[0][:45]}\" ifadesini öne çıkarıyor"
        if phrases:
            return f"{source}, \"{phrases[0]}\" ayrıntısını özellikle ekliyor"
        if len(terms) >= 2:
            return f"{source}, {analysis_human_join(terms[:3])} ayrıntılarına yaslanıyor"
        return f"{source}, ana bilgileri karşı kaynakla çok benzer kuruyor"

    left_focus = focus_phrase(left_source, pair_meta["leftBodyDiffPhrases"], pair_meta["leftBodyUnique"], pair_meta["leftActorsUnique"], pair_meta["leftQuotes"])
    right_focus = focus_phrase(right_source, pair_meta["rightBodyDiffPhrases"], pair_meta["rightBodyUnique"], pair_meta["rightActorsUnique"], pair_meta["rightQuotes"])
    tone_sentence = "Ton farkı sınırlı." if abs(pair_meta["leftTone"]["dramatic"] - pair_meta["rightTone"]["dramatic"]) <= 1 and abs(pair_meta["leftTone"]["attribution"] - pair_meta["rightTone"]["attribution"]) <= 1 else "Ton tarafında kelime seçimi ve atıf kullanımı ayrışıyor."
    return f"{left_focus}. {right_focus}. {tone_sentence}"


def describe_headline_style(title: str) -> str:
    lowered = normalize_text(title)
    if any(term in lowered for term in ["breaking", "urgent", "shock", "crisis", "son dakika", "kriz"]):
        return "Başlık daha dramatik ve aciliyet vurgusu yüksek."
    if any(term in lowered for term in ["say", "announced", "confirmed", "açıkladı", "duyurdu", "bildirdi"]):
        return "Başlık daha düz, açıklama odaklı ve nötr kurulmuş."
    return "Başlık olayı doğrudan anlatıyor ve görece dengeli bir dil kullanıyor."


def describe_tone(text: str) -> str:
    lowered = normalize_text(text)
    dramatic_hits = sum(1 for term in ["critical", "devastating", "urgent", "historic", "kriz", "şok", "sok", "acil"] if term in lowered)
    neutral_hits = sum(1 for term in ["reported", "stated", "according", "açıkladı", "bildirdi", "duyurdu"] if term in lowered)
    if dramatic_hits > neutral_hits:
        return "Dil daha dramatik ve gerilim hissi üretiyor."
    if neutral_hits:
        return "Dil daha nötr ve bilgi aktarma ağırlıklı."
    return "Dil standart haber tonu ile verilmiş."


def summarize_focus(text: str, features: EventFeatures) -> str:
    focus_parts = []
    if features.actor_entities:
        focus_parts.append(f"aktör olarak {', '.join(features.actor_entities[:2])}")
    if features.outcome and features.outcome != "update":
        focus_parts.append(f"sonuç olarak {features.outcome}")
    if features.place_entities:
        focus_parts.append(f"yer olarak {features.place_entities[0]}")
    if not focus_parts:
        keywords = ", ".join(features.keywords[:3]) or "ana gelişme"
        focus_parts.append(f"özellikle {keywords}")
    return "Kaynak daha çok " + ", ".join(focus_parts) + " unsurunu öne çıkarıyor."


def describe_actor_presentation(features: EventFeatures) -> str:
    if features.actor_entities:
        return f"Aktörler {', '.join(features.actor_entities[:2])} üzerinden merkezde konumlandırılmış."
    if features.place_entities:
        return f"Coğrafi bağlam olarak {features.place_entities[0]} öne çıkıyor."
    return "Aktör sunumu sınırlı; olay daha genel bir çerçevede anlatılıyor."


def find_underplayed_details(primary: EventFeatures, secondary: EventFeatures) -> str:
    primary_tokens = set(primary.signature_tokens)
    missing = [token for token in secondary.signature_tokens if token and token not in primary_tokens]
    if not missing:
        return "Karşı tarafta öne çıkan belirgin ek bir ayrıntı görünmüyor."
    return "Karşı kaynakta öne çıkan " + ", ".join(missing[:3]) + " ayrıntıları burada daha az vurgulanıyor."


def build_overall_summary(left: Dict[str, Any], right: Dict[str, Any]) -> str:
    left_source = left.get("source") or "Kaynak A"
    right_source = right.get("source") or "Kaynak B"
    left_category = left.get("category") or left.get("ai_category") or "World"
    right_category = right.get("category") or right.get("ai_category") or "World"
    return (
        f"{left_source} ile {right_source} aynı olayı anlatıyor ancak odak cümleleri ve vurgu merkezleri farklılaşıyor. "
        f"İlk kaynak {left_category} bağlamını daha belirgin tutarken ikinci kaynak {right_category} tarafında sonucu ve aktör ilişkilerini daha görünür kılıyor. "
        "İki metin de aynı olay kümesine ait kabul edildiği için analiz yalnızca anlatım farklarını özetliyor."
    )


def make_stable_id(source: str, url_or_title: str) -> str:
    return hashlib.md5(f"{source}:{url_or_title}".encode("utf-8", errors="ignore")).hexdigest()


comparison_service = ComparisonService()
