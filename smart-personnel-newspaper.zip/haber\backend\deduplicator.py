import re
from typing import Set

def get_word_set(text: str) -> Set[str]:
    """
    Metni temizleyerek (küçük harf, noktalama işareti kaldırma) kelime kümesine çevirir.
    MinHash/Jaccard mantığına zemin hazırlar.
    """
    if not text:
        return set()
    # Sadece alfanumerik karakterleri al, gerisini sil
    clean_text = re.sub(r'[^\w\s]', '', text.lower())
    words = clean_text.split()
    return set(words)

def calculate_jaccard_similarity(text1: str, text2: str) -> float:
    """
    İki kelime kümesi arasındaki Jaccard Benzerlik İndeksi'ni hesaplar.
    Formül: (Kesişim Kümesi Boyutu) / (Birleşim Kümesi Boyutu)
    (FR-1.2: Gelişmiş Metin Benzerliği ve Kopya Tespiti)
    """
    set1 = get_word_set(text1)
    set2 = get_word_set(text2)
    
    if not set1 or not set2:
        return 0.0
        
    intersection = set1.intersection(set2)
    union = set1.union(set2)
    
    return len(intersection) / len(union) if len(union) > 0 else 0.0

def is_duplicate(new_dto, existing_dtos, similarity_threshold=0.75):
    """
    Gelen NewsDTO'nun, Veritabanındaki diğer DTO'lara göre kopya olup olmadığını sorgular.
    1. Hızlı Arama: URL Hash (SHA-256) (O(1) Karmaşıklık)
    2. Derin Arama: Jaccard Kelime Kesişimi
    """
    new_hash = new_dto.url_hash or ""
    new_desc = new_dto.description or ""
    
    for existing in existing_dtos:
        # 1. SHA-256 URL MAC CHECK
        existing_hash = getattr(existing, "url_hash", "")
        if new_hash and existing_hash == new_hash:
            print(f"[DEDUPLICATOR] Birebir Kopya Engellendi (SHA-256): {new_dto.title}")
            return True
            
        # 2. JACCARD TEXT SIMILARITY
        existing_desc = getattr(existing, "content_text", getattr(existing, "description", ""))
        # Yeterli kelime varsa (Örn: Makale boyutu)
        if len(new_desc) > 30 and len(existing_desc) > 30:
            sim_ratio = calculate_jaccard_similarity(new_desc, existing_desc)
            if sim_ratio > similarity_threshold:
                print(f"[DEDUPLICATOR] İcerik Benzerligi Saptandi (Jaccard %{sim_ratio*100:.1f}): {new_dto.title}")
                return True
                
    return False
