import json
from typing import List
from fastapi import WebSocket

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast_news(self, message: str, article_data: dict):
        payload = json.dumps({"message": message, "article": article_data})
        for connection in self.active_connections:
            try:
                await connection.send_text(payload)
            except Exception:
                pass

ws_manager = ConnectionManager()
