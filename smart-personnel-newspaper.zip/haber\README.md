# 🗞️ Smart Personnel Newspaper

> Yapay Zeka destekli, çoklu kaynaklardan haber toplayan, karşılaştıran ve kişiselleştirilmiş akış sunan akıllı haber platformu.

## ✨ Özellikler

- **100+ Küresel Kaynak** — GNews API, TRT Haber, Hürriyet RSS ve daha fazlası
- **AI Haber Karşılaştırma** — Aynı olayı farklı kaynakların nasıl aktardığını analiz eder
- **NLP Pipeline** — Otomatik kategorizasyon, özetleme, duygu analizi
- **Kişiselleştirilmiş Akış** — Kullanıcı ilgi alanlarına göre adaptif sıralama
- **OSINT Dashboard** — Varlık izleme, trend analizi, coğrafi ısı haritası
- **RAG Chat** — Haberlerle sohbet edebilme (OpenAI entegrasyonu)
- **Çok Dilli Destek** — Türkçe / İngilizce / İspanyolca / Fransızca / Almanca

## 🛠️ Teknoloji Stack

| Katman | Teknoloji |
|--------|-----------|
| **Frontend** | Vanilla HTML/CSS/JS |
| **Backend** | FastAPI + Uvicorn |
| **Database** | SQLite (dev) / PostgreSQL (prod) |
| **ORM** | SQLAlchemy |
| **NLP** | OpenAI GPT-4o-mini, HuggingFace Zero-Shot |
| **Vector DB** | ChromaDB (opsiyonel) |
| **Task Queue** | Celery (opsiyonel) |

---

## 🚀 Hızlı Başlangıç (Kurulum)

### Gereksinimler

- **Python 3.10+** — [İndir](https://www.python.org/downloads/)
- **Git** — [İndir](https://git-scm.com/downloads)

### 1. Projeyi Klonla

```bash
git clone https://github.com/KULLANICI_ADI/smart-personnel-newspaper.git
cd smart-personnel-newspaper/haber
```

### 2. Otomatik Kurulum (Önerilen — Windows)

Projeyi tek tıkla çalıştırmak için:

```
start_project.bat
```

Bu script otomatik olarak:
1. ✅ Sanal ortam oluşturur (`.venv`)
2. ✅ `.env` dosyasını hazırlar
3. ✅ Tüm bağımlılıkları yükler
4. ✅ Backend sunucusunu başlatır

### 3. Manuel Kurulum

Eğer manuel yapmak isterseniz:

```bash
# Backend dizinine geç
cd backend

# Sanal ortam oluştur
python -m venv .venv

# Sanal ortamı aktifleştir
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# Bağımlılıkları yükle
pip install -r requirements.txt

# .env dosyasını oluştur
copy .env.example .env        # Windows
# cp .env.example .env        # macOS/Linux

# Sunucuyu başlat
python -m uvicorn api:app --host 127.0.0.1 --port 8000 --reload
```

### 4. API Anahtarlarını Ayarla

`backend/.env` dosyasını düzenleyip kendi API anahtarlarınızı girin:

```env
# ZORUNLU — GNews API (ücretsiz hesap: https://gnews.io/dashboard)
NEWS_API_KEY=buraya_gnews_api_keyinizi_yapistirin

# OPSİYONEL — OpenAI (yoksa mock mod çalışır)
OPENAI_API_KEY=buraya_openai_api_keyinizi_yapistirin
```

> ⚠️ **Not:** `NEWS_API_KEY` olmadan haber çekilemez. Ücretsiz GNews hesabı günde 100 istek sağlar.

### 5. Uygulamaya Eriş

Sunucu başladıktan sonra tarayıcınızda:

| Sayfa | URL |
|-------|-----|
| **Ana Sayfa** | http://127.0.0.1:8000 |
| **API Docs (Swagger)** | http://127.0.0.1:8000/docs |

---

## 📁 Proje Yapısı

```
haber/
├── index.html              # Ana frontend sayfası
├── start_project.bat       # Tek tıkla başlatma scripti
├── css/
│   ├── style.css           # Ana stil dosyası
│   └── animations.css      # Animasyonlar
├── js/
│   ├── main.js             # Ana uygulama mantığı
│   ├── api.js              # Backend API çağrıları
│   ├── auth.js             # Kimlik doğrulama
│   ├── i18n.js             # Çoklu dil desteği
│   ├── comparison-engine.js # Haber karşılaştırma motoru
│   ├── earth_background.js  # 3D arka plan animasyonu
│   ├── gazette.js          # Gazete görünümü
│   └── state.js            # Uygulama durumu yönetimi
├── images/                 # Görsel dosyalar
└── backend/
    ├── api.py              # FastAPI ana uygulama
    ├── models.py           # SQLAlchemy modelleri
    ├── db.py               # Veritabanı bağlantısı
    ├── nlp_service.py      # NLP / AI servisi
    ├── comparison_service.py     # Haber karşılaştırma motoru
    ├── comparison_feed_service.py # Karşılaştırma akış servisi
    ├── newsapi_client.py   # GNews API istemcisi
    ├── rss_client.py       # TRT / Hürriyet RSS istemcisi
    ├── recommender.py      # Öneri motoru
    ├── fetcher.py          # Haber çekme servisi
    ├── vector_db.py        # ChromaDB vektör veritabanı
    ├── osint_api.py        # OSINT dashboard API'leri
    ├── tasks.py            # Celery arka plan görevleri
    ├── requirements.txt    # Python bağımlılıkları
    ├── .env.example        # Ortam değişkenleri şablonu
    └── news/               # Haber toplama modülleri
        ├── aggregator.py
        ├── cache_manager.py
        ├── sources.py
        ├── parser.py
        └── scheduler.py
```

---

## 🤝 Ekip Çalışması Notları

### İlk Kurulumdan Sonra
1. `git pull` ile güncel kodu çekin
2. `pip install -r backend/requirements.txt` ile yeni bağımlılıkları yükleyin
3. `.env` dosyanızın güncel olduğundan emin olun

### Yeni Bağımlılık Eklerken
1. `pip install PAKET_ADI` ile yükleyin
2. `pip freeze > requirements.txt` **YAPMAYIN** — Elle `requirements.txt`'e ekleyin
3. Commit'e dahil edin

### Önemli Uyarılar
- ❌ `.env` dosyasını **asla** commit etmeyin (API anahtarları içerir)
- ❌ `news.db` dosyasını commit etmeyin (her makinede otomatik oluşur)
- ❌ `.venv/` klasörünü commit etmeyin
- ✅ Kod değişikliklerinde `.gitignore` kurallarına uyun

---

## ⚡ Tek Komutla Kurulum

Projeyi klonladıktan sonra **sadece bir komut** çalıştırmanız yeterli:

```bash
git clone https://github.com/KULLANICI_ADI/smart-personnel-newspaper.git
cd smart-personnel-newspaper/haber
```

Ardından:

```
setup.bat
```

**Bu tek komut otomatik olarak şunları yapar:**

| Adım | İşlem |
|------|-------|
| 1 | ✅ Python'un yüklü olup olmadığını kontrol eder |
| 2 | ✅ Sanal ortam (`.venv`) oluşturur |
| 3 | ✅ `.env` dosyasını şablondan kopyalar |
| 4 | ✅ Tüm Python paketlerini yükler (`pip install`) |
| 5 | ✅ Veritabanını hazırlar (`news.db`) |

Kurulum bittikten sonra projeyi başlatmak için:

```
start_project.bat
```

> 💡 **Tek yapmanız gereken ek işlem:** `backend/.env` dosyasını açıp `NEWS_API_KEY` değerine kendi GNews API anahtarınızı girmek. Ücretsiz hesap: https://gnews.io/dashboard

---

## 📝 Lisans

Bu proje akademik amaçlı geliştirilmektedir.
