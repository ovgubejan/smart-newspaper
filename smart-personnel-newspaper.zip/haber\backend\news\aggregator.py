# backend/news/aggregator.py
import asyncio
from datetime import datetime
from typing import List
from .sources import GLOBAL_RSS_SOURCES
from .parser import parser_instance
from .deduplicator import filter_duplicates
from .cache_manager import news_cache
from .models import GlobalNewsItem

# AI ENTEGRASYONU İÇİN IMPORTLAR
import sys
import os
# Ana modüllere erişim (backend/news dizininden dışarı çıkış)
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from vector_db import vector_db_manager

class NewsAggregator:
    def __init__(self):
        self.is_running = False

    async def fetch_all_sources(self) -> List[GlobalNewsItem]:
        """
        100+ kaynağı paralel olarak çeker ve birleştirir.
        """
        tasks = [parser_instance.fetch_and_parse(src) for src in GLOBAL_RSS_SOURCES]
        results = await asyncio.gather(*tasks)
        
        all_news = []
        for res in results:
            if res:
                all_news.extend(res)
        return all_news

    async def run_once(self):
        """
        Tek bir toplama ve işleme döngüsü.
        """
        print(f"[AGGREGATOR] {len(GLOBAL_RSS_SOURCES)} kaynak taranmaya başlanıyor...")
        start_time = datetime.utcnow()
        
        # 1. FETCH
        all_news = await self.fetch_all_sources()
        print(f"[AGGREGATOR] {len(all_news)} ham haber toplandı.")
        
        # 2. SORT (pub_date DESC)
        all_news.sort(key=lambda x: x.pub_date, reverse=True)
        
        # 3. DEDUPLICATE (URL + Fuzzy Title)
        unique_news = filter_duplicates(all_news)
        print(f"[AGGREGATOR] Mükerrerler elendi. {len(unique_news)} benzersiz haber kaldı.")
        
        # 4. UPDATE CACHE (Hafızada Tutma)
        news_cache.update_cache(unique_news)
        
        # 5. AI INTEGRATION (CHROMADB)
        # Sadece en güncel 20 haberi AI sistemine kaydedelim 
        # (Sistem performansı ve donmaları engellemek için)
        ai_sync_count = 0
        for item in unique_news[:20]:
            try:
                # Her dönüşte event_loop'a nefes aldır, API kilitlenmesin
                await asyncio.sleep(0.05)
                
                # Makale ID'si olarak linkten bir hash üretelim
                import hashlib
                art_id = hashlib.md5(item.link.encode()).hexdigest()
                
                # ChromaDB'ye ekleme (RAG için aranabilir hale getirme)
                success = vector_db_manager.add_article_to_vector_db(
                    article_id=art_id,
                    title=item.title,
                    content=item.description
                )
                if success:
                    ai_sync_count += 1
            except Exception as e:
                print(f"[AGGREGATOR] AI Entegrasyon Hatası: {e}")
        
        duration = (datetime.utcnow() - start_time).total_seconds()
        print(f"[AGGREGATOR] Döngü tamamlandı ({duration:.1f}s). {ai_sync_count} haber AI Belleğine (ChromaDB) işlendi.")

    async def start_loop(self):
        """
        5 dakikada bir (300 saniye) çalışan arka plan döngüsü.
        """
        if self.is_running:
            return
            
        self.is_running = True
        print("[AGGREGATOR] Periyodik tarama döngüsü başlatıldı (5 Dakika).")
        
        while self.is_running:
            try:
                await self.run_once()
            except Exception as e:
                print(f"[AGGREGATOR] Kritik Döngü Hatası: {e}")
            
            # 5 Dakika bekle
            await asyncio.sleep(300)

aggregator_instance = NewsAggregator()
