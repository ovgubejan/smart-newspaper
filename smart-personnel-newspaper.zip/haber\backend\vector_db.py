import os

try:
    import chromadb
except ImportError:
    chromadb = None

try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    SentenceTransformer = None

# ChromaDB veritabani yollari ve koleksiyon tanimi
CHROMA_DATA_DIR = os.path.join(os.path.dirname(__file__), "chroma_data")
COLLECTION_NAME = "news_embeddings"


class VectorDBManager:
    def __init__(self):
        self.client = None
        self.collection = None
        self.encoder = None
        self.is_available = False

        if chromadb is None:
            print("[VECTOR_DB] chromadb kurulmadigi icin vektor ozellikleri devre disi.")
            return

        try:
            # Persistent (kalici) Chroma veritabani baglantisi
            self.client = chromadb.PersistentClient(path=CHROMA_DATA_DIR)
            self.collection = self.client.get_or_create_collection(
                name=COLLECTION_NAME,
                metadata={"hnsw:space": "cosine"},
            )
        except Exception as e:
            print(f"[VECTOR_DB] Chroma istemcisi baslatilamadi: {e}")
            self.client = None
            self.collection = None
            return

        # Model yerelde yoksa uygulamayi dusurmek yerine vektor ozelliklerini kapat.
        print("[VECTOR_DB] all-MiniLM-L6-v2 Semantic Model yukleniyor...")
        if SentenceTransformer is None:
            print("[VECTOR_DB] sentence_transformers kurulmadigi icin embedding modeli devre disi.")
            return
        try:
            self.encoder = SentenceTransformer("all-MiniLM-L6-v2", local_files_only=True)
            self.is_available = True
            print("[VECTOR_DB] Model basariyla yuklendi!")
        except Exception as e:
            print(f"[VECTOR_DB] Model devre disi: {e}")

    def _embeddings_enabled(self):
        return self.is_available and self.encoder is not None and self.collection is not None

    def add_article_to_vector_db(self, article_id: str, title: str, content: str):
        """
        Gelen makalenin baslik ve ozet/icerigini birlestirip ChromaDB'ye ekler.
        """
        if not self._embeddings_enabled():
            print(f"[VECTOR_DB] Atlaniyor ({article_id}): embedding modeli kullanilamiyor.")
            return False

        if not title and not content:
            print(f"[VECTOR_DB] Uyari: {article_id} nolu makale icerigi bos.")
            return False

        semantic_text = f"Baslik: {title}\nIcerik: {content}"

        try:
            embedding = self.encoder.encode(semantic_text).tolist()
        except Exception as e:
            print(f"[VECTOR_DB] Embedding uretim hatasi ({article_id}): {e}")
            return False

        try:
            self.collection.add(
                ids=[str(article_id)],
                embeddings=[embedding],
                documents=[semantic_text],
            )
            print(f"[VECTOR_DB] Basari: {article_id} ChromaDB'ye eklendi.")
            return True
        except Exception as e:
            print(f"[VECTOR_DB] ChromaDB kayit hatasi ({article_id}): {e}")
            return False

    def query(self, text: str, n_results: int = 3):
        """Serbest metin sorgusunu vektor aramaya donusturur."""
        if not self._embeddings_enabled():
            return {
                "documents": [[]],
                "ids": [[]],
                "distances": [[]],
                "error": "vector_db_unavailable",
            }

        try:
            query_embedding = self.encoder.encode(text).tolist()
            return self.collection.query(
                query_embeddings=[query_embedding],
                n_results=n_results,
                include=["documents", "distances"],
            )
        except Exception as e:
            print(f"[VECTOR_DB] Sorgu hatasi: {e}")
            return {"documents": [[]], "ids": [[]], "distances": [[]], "error": str(e)}

    def find_similar_articles(self, article_id: str, top_k: int = 5):
        """
        Bir makalenin embedding'ini bulup en benzer diger makaleleri getirir.
        """
        if not self._embeddings_enabled():
            return {"similar_ids": [], "scores": [], "error": "vector_db_unavailable"}

        get_res = self.collection.get(ids=[str(article_id)], include=["embeddings"])
        embeddings = get_res.get("embeddings") if get_res else None
        if not get_res or embeddings is None or len(embeddings) == 0:
            return {"error": "Bu makale icin ChromaDB'de embedding verisi bulunamadi."}

        target_embedding = get_res["embeddings"][0]

        try:
            results = self.collection.query(
                query_embeddings=[target_embedding],
                n_results=top_k + 1,
                include=["distances"],
            )

            if not results["ids"] or len(results["ids"][0]) == 0:
                return {"similar_ids": [], "scores": []}

            similar_ids = []
            similar_scores = []

            for i, matched_id in enumerate(results["ids"][0]):
                if matched_id != str(article_id):
                    similar_ids.append(matched_id)
                    dist = results["distances"][0][i]
                    similarity = max(0, 1.0 - dist)
                    similar_scores.append(similarity)

            return {
                "similar_ids": similar_ids[:top_k],
                "scores": similar_scores[:top_k],
            }
        except Exception as e:
            print(f"[VECTOR_DB] Benzerlik arama hatasi ({article_id}): {e}")
            return {"error": str(e)}


# Singleton nesne, uygulama genelinde kullanilacak
vector_db_manager = VectorDBManager()
