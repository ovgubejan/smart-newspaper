# scraper.py — Haber içeriklerini kaynak siteden çeker
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import re

# Bellek içi önbellek
_content_cache = {}
CACHE_TTL = 1800  # 30 dakika

# Site bazlı CSS seçicileri — haber metninin olduğu ana container
SITE_SELECTORS = {
    "trthaber.com": [
        "div.detay-icerik",
        "div.news-content",
        "div.detail-content",
        "div.content-text",
        "article .content",
        "div.newsDetailText",
    ],
    "hurriyet.com.tr": [
        "div.news-content",
        "div.article-body",
        "div.rhd-article-text",
        "div.news-detail-text",
        "article .content",
    ],
    "default": [
        "article",
        "[itemprop='articleBody']",
        "div.article-body",
        "div.post-content",
        "div.entry-content",
        "div.story-body",
        "div.content-text",
        "main",
    ]
}

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept-Language": "tr-TR,tr;q=0.9,en;q=0.8",
}


def _get_selectors_for_url(url: str) -> list:
    """URL'ye göre doğru CSS seçicileri döndür."""
    for domain, selectors in SITE_SELECTORS.items():
        if domain in url:
            return selectors
    return SITE_SELECTORS["default"]


def _clean_text(text: str) -> str:
    """Çekilen metni temizle."""
    # Birden fazla boşluk/satırı tek satıra indir
    text = re.sub(r'\n\s*\n', '\n\n', text)
    text = re.sub(r'[ \t]+', ' ', text)
    # Reklam ve gereksiz kısımları temizle
    noise = [
        r'(?i)haberi paylaş.*',
        r'(?i)sosyal medyada paylaş.*',
        r'(?i)yorumlar?\s*\(\d+\)',
        r'(?i)ilgili haberler.*',
        r'(?i)etiketler?\s*:.*',
        r'(?i)reklam.*',
    ]
    for pattern in noise:
        text = re.sub(pattern, '', text)
    return text.strip()


def scrape_article(url: str) -> dict:
    """
    Verilen URL'den haber içeriğini çeker.
    Döndürür: {"content": str, "images": list, "error": str|None}
    """
    if not url or not url.startswith("http"):
        return {"content": "", "images": [], "error": "Geçersiz URL"}

    # Önbellek kontrolü
    cache_key = url.strip()
    if cache_key in _content_cache:
        cached, ts = _content_cache[cache_key]
        if (datetime.utcnow() - ts).total_seconds() < CACHE_TTL:
            return cached

    try:
        resp = requests.get(url, headers=HEADERS, timeout=12, allow_redirects=True)
        resp.raise_for_status()
        resp.encoding = resp.apparent_encoding or "utf-8"

        soup = BeautifulSoup(resp.text, "html.parser")

        # Gereksiz elementleri kaldır
        for tag in soup.find_all(["script", "style", "iframe", "nav", "footer",
                                   "aside", "form", "noscript", "svg"]):
            tag.decompose()

        # Reklam divlerini kaldır
        for ad in soup.find_all(class_=re.compile(r'(?i)(advert|banner|sponsor|social|share|comment|related)')):
            ad.decompose()

        # Site bazlı seçicilerle içerik bul
        selectors = _get_selectors_for_url(url)
        content_el = None
        for selector in selectors:
            content_el = soup.select_one(selector)
            if content_el:
                break

        if not content_el:
            # Fallback: tüm <p> etiketlerini topla
            paragraphs = soup.find_all("p")
            texts = [p.get_text(strip=True) for p in paragraphs if len(p.get_text(strip=True)) > 40]
            content_text = "\n\n".join(texts)
        else:
            # İçerik elementinden paragrafları çek
            paragraphs = content_el.find_all("p")
            if paragraphs:
                texts = [p.get_text(strip=True) for p in paragraphs if len(p.get_text(strip=True)) > 20]
                content_text = "\n\n".join(texts)
            else:
                content_text = content_el.get_text("\n", strip=True)

        content_text = _clean_text(content_text)

        # Görselleri çek
        images = []
        if content_el:
            for img in content_el.find_all("img", src=True):
                src = img["src"]
                if src.startswith("//"):
                    src = "https:" + src
                if src.startswith("http") and "logo" not in src.lower() and "icon" not in src.lower():
                    images.append(src)

        # Minimum içerik kontrolü
        if len(content_text) < 50:
            # Son çare: meta description veya og:description
            meta = soup.find("meta", {"property": "og:description"}) or \
                   soup.find("meta", {"name": "description"})
            if meta and meta.get("content"):
                content_text = meta["content"]

        result = {
            "content": content_text,
            "images": images[:5],  # En fazla 5 görsel
            "error": None
        }

        _content_cache[cache_key] = (result, datetime.utcnow())
        return result

    except requests.exceptions.Timeout:
        return {"content": "", "images": [], "error": "Bağlantı zaman aşımına uğradı"}
    except requests.exceptions.ConnectionError:
        return {"content": "", "images": [], "error": "Siteye bağlanılamadı"}
    except Exception as e:
        print(f"[SCRAPER] Hata ({url}): {e}")
        return {"content": "", "images": [], "error": str(e)}


if __name__ == "__main__":
    # Test
    test_url = "https://www.trthaber.com/haber/gundem/bakan-ciftci-hedefimiz-ceza-degil-kurallara-uyulmasi-946159.html"
    result = scrape_article(test_url)
    print(f"İcerik uzunlugu: {len(result['content'])} karakter")
    print(f"Gorseller: {len(result['images'])}")
    print(f"İcerik (ilk 500):\n{result['content'][:500]}")
