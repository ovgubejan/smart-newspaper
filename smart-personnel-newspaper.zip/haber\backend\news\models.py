# backend/news/models.py
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class GlobalNewsItem(BaseModel):
    """
    Standardized news item for the global aggregator.
    """
    title: str
    description: str
    link: str
    pub_date: datetime
    source: str
    country: str
    image_url: Optional[str] = None
