import asyncio
import io
import sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("--- 1. Testing Weather Service (GDACS) ---")
from weather_service import weather_manager
asyncio.run(weather_manager.fetch_gdacs_events())

print("\n--- 2. Testing NLP Zero-Shot Categories ---")
from nlp_service import nlp_manager
text = "The Federal Reserve unexpectedly raised the main interest rate by 50 basis points. The stock market tumbled immediately after the announcement as investors worried about credit tightening."
res = nlp_manager.classify_text(text)
print(f"Haber: {text}")
print(f"Sınıflandırma Sonucu (Kategori): {res}")
