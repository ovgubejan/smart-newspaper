# tasks.py
from celery import Celery
from celery.schedules import crontab

# app tanımlandıktan sonra iç içe dairesel bağımlılığı (circular limit) engellemek için imports:
from fetcher import NewsIngestionService, WebCrawlerStrategy, APINewsStrategy
from nlp_service import nlp_manager
from db import db
from vector_db import vector_db_manager

# Gelişmiş Celery Mimarisi (Redis olmadan yerel SQLite üzerinden)
app = Celery('haber_advanced_tasks', broker='sqla+sqlite:///celery_broker.sqlite', backend='db+sqlite:///celery_backend.sqlite')

# Sık Kullanılan Kaynaklar (Örnek)
CRAWLER_SOURCES_EN = ["https://feeds.bbci.co.uk/news/rss.xml"]
API_SOURCES_GLOBAL = ["https://api.mocknews.com/v1/top-headlines"] 

@app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    # Çekim yapan işlemler IO Bound'dur. (Standart Kuyruk)
    sender.add_periodic_task(crontab(minute='*/15'), run_api_ingestion.s("en"), name='15m_Ingest_API_EN')
    sender.add_periodic_task(crontab(minute=0, hour='*'), run_crawler_ingestion_hourly.s(), name='Hourly_Ingest_Crawlers_ALL')
    # Kurumsal Etkinlik Takip Görevi
    sender.add_periodic_task(crontab(minute=0, hour='*'), check_upcoming_events.s(), name='Hourly_Check_Upcoming_Events')
    # Yeni OSINT (Global Veri) Görevi - saatte bir çalışır
    sender.add_periodic_task(crontab(minute=0, hour='*'), fetch_global_news_task.s(), name='Hourly_OSINT_Global_News')
    # Kelebek Etkisi / Anomali Taraması (6 Saatte Bir)
    sender.add_periodic_task(crontab(minute=0, hour='*/6'), analyze_global_trends_task.s(), name='Analyze_Global_Trends_Every_6_Hours')
    # Küresel Afet / Hava Radarı (2 Saatte Bir)
    sender.add_periodic_task(crontab(minute=0, hour='*/2'), fetch_extreme_weather_task.s(), name='BiHourly_Disasters_Radar')

# ==========================================
# KURUMSAL ETKİNLİK ZAMANLAYICI (Modül 6)
# ==========================================
@app.task
def check_upcoming_events():
    print("[CELERY-TASK-EVENTS] Yaklasan Etkinlikler denetleniyor...")
    from notifier import notifier
    from db import SessionLocal
    from models import InstitutionalEvent
    from datetime import datetime, timedelta
    
    db_session = SessionLocal()
    try:
        now = datetime.utcnow()
        limit = now + timedelta(hours=24) # 24 saat uyarısı
        
        upcoming = db_session.query(InstitutionalEvent).filter(
            InstitutionalEvent.start_time >= now,
            InstitutionalEvent.start_time <= limit
        ).all()
        
        for evt in upcoming:
            # Gerçekte: ilgili departmandaki user email'leri çekilir
            notifier.send_email_notification("all_staff@haber.local", f"HATIRLATMA: {evt.title}", f"{evt.start_time} tarihinde planlıdır.\nAçıklama: {evt.description}")
            if evt.is_critical:
                notifier.send_push_notification("device_abc123", "ACIL UYARI", evt.title)
    finally:
        db_session.close()

@app.task
def run_api_ingestion(language: str):
    print(f"[CELERY-TASK-API] API Cekimi (Dil: {language})")
    service = NewsIngestionService(APINewsStrategy())
    for source in API_SOURCES_GLOBAL:
        service.execute_ingestion(source, language=language)

@app.task
def generate_summary_for_cluster_task(cluster_articles):
    # Cluster için genel toplu rapor çıkarma / özetleme (İsteğe Bağlı FR.3)
    pass

@app.task
def analyze_global_trends_task():
    """6 saatte bir çalışan Kelebek Etkisi analiz tetikleyicisi"""
    print("[CELERY-TASK-TRENDS] Kuresel anomali ve Z-Score analizi baslatiliyor...")
    from analytics import analyzer
    
    spikes = analyzer.analyze_trends()
    print(f"[CELERY-TASK-TRENDS] Analiz tamamlandi. Bulunan Trend Sayisi: {len(spikes)}")
    return f"Completed. Spikes: {len(spikes)}"

@app.task
def fetch_extreme_weather_task():
    """2 saatte bir çalışan GDACS veri çekicisi"""
    print("[CELERY-TASK-WEATHER] Ekstrem hava ve afet durumlari taraniyor...")
    import asyncio
    from weather_service import weather_manager
    
    # asyncio run for sync celery task to run async function
    asyncio.run(weather_manager.fetch_gdacs_events())
    return "Weather Radar completed."

@app.task
def run_crawler_ingestion_hourly():
    print("[CELERY-TASK-CRAWLER] Saatlik RSS Crawl...")
    service = NewsIngestionService(WebCrawlerStrategy())
    for url in CRAWLER_SOURCES_EN:
        service.execute_ingestion(url, "en")

@app.task
def fetch_global_news_task():
    import asyncio
    from fetcher import fetch_global_news_async
    
    print("[CELERY-TASK-OSINT] Global (Reuters, BBC, Google News) çekimi başlıyor...")
    GLOBAL_SOURCES = [
        "https://feeds.bbci.co.uk/news/world/rss.xml",
        "https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en"
    ]
    
    for source in GLOBAL_SOURCES:
        try:
            # OSINT modülü asenkron olduğu için senkron celery içerisinde asyncio ile wrap ediyoruz
            asyncio.run(fetch_global_news_async(source, language="en"))
        except Exception as e:
            print(f"[CELERY-TASK-OSINT] Kaynak basarisiz ({source}): {e}")

# ==========================================
# YENİ NLP ASENKRON İŞLEM KUYRUĞU (CPU-Bound)
# (NFR-4: NLP tasks execute asynchronously)
# ==========================================
@app.task(queue='nlp_tasks', acks_late=True)
def process_article_nlp_task(article_id: str):
    """
    Bu fonksiyon DB'den ham metni alıp sınıflandırma, etiket çıkarma, özetleme ve duygu analizi yapar.
    Ağır CPU işlemi olduğu için özel bir nlp_tasks kuyruğunda bekletilir.
    """
    # 1. DB'den Veriyi Getir
    article = db.get_article(article_id)
    if not article or article.is_nlp_processed:
        return "[HATA/ZATEN_İŞLENDİ] Makale bulunamadı veya işlenmiş."

    content = article.content_text
    print(f"\n[NLP KUYRUGU BASLADI] {article.title}")
    
    # 2. NLP Pipeline Adımları
    category = nlp_manager.classify_text(content)
    tags = nlp_manager.extract_keywords(content, max_words=4)
    summary = nlp_manager.summarize_bullets(content)
    sentiment = nlp_manager.analyze_sentiment(content)
    
    # YENİ: NER ve Duygu Skoru
    try:
        entities = nlp_manager.extract_entities(content)
        sentiment_score = nlp_manager.calculate_sentiment_score(content)
    except Exception as nlp_e:
        print(f"[NLP NER HATA] Varlik cikarimi basarisiz: {nlp_e}")
        entities = []
        sentiment_score = 0.0
    
    # 3. DB'yi Güncelle
    db.update_article_with_nlp(article_id, category, tags, summary, sentiment, sentiment_score)
    try:
        db.add_article_entities(article_id, entities)
    except Exception as db_e:
        print(f"[DB NER HATA] Entity veritabanina eklenemedi: {db_e}")
    
    # 4. Vektör Veritabanına (ChromaDB) Kaydet
    try:
        vector_db_manager.add_article_to_vector_db(str(article_id), article.title, content)
        
        # 5. Yeni haber eklendiğinde API Önbelleğini (Cache) Temizle
        import diskcache as dc
        import os
        cache_dir = os.path.join(os.path.dirname(__file__), "api_cache")
        try:
            with dc.Cache(cache_dir) as cache:
                cache.clear()
            print(f"[CACHE] Yeni haber ({article_id}) eklendi, ana sayfa önbelleği temizlendi.")
        except Exception as ce:
            print(f"[CACHE HATA] Onbellek temizlenirken hata olustu: {ce}")
            
    except Exception as e:
        print(f"[NLP KUYRUGU HATA] ChromaDB Entegrasyonu basarisiz oldu: {e}")
        
    return f"NLP Tamamlandı: {article_id}"

# Note: NewsDTO imported in ingestion services if needed.
