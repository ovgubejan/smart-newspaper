from typing import List, Dict, Any
import random
import requests
from models import SentimentType

import os
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

class NLPService:
    """
    Haber metinleri üzerinde OpenAI ChatGPT API ile
    sınıflandırma (Classification) ve özetleme (Summarization) yapar.
    """
    def __init__(self, use_mock: bool = True):
        self.use_mock = use_mock
        self.openai_api_key = os.getenv("OPENAI_API_KEY", "")
        self.openai_api_key = os.getenv("OPENAI_API_KEY", "")
        self.openai_model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
        self._zero_shot_classifier = None
        self.summary_cache = {}
        self.classify_cache = {}
        
        # Eğer API Key varsa gerçek modda çalış
        if self._has_real_ai_key():
            self.use_mock = False
            print(f"[NLP_INIT] OpenAI mod aktif — model: {self.openai_model}")
        else:
            self.use_mock = True
            print("[NLP_INIT] OpenAI key bulunamadi, mock mod aktif.")
        
        self.categories_pool = ["Technology", "Politics", "Economy", "Sports", "Health", "Science", "World", "Weather", "Culture", "Education"]

    def _has_real_ai_key(self) -> bool:
        placeholders = {"", "buraya_openai_api_keyinizi_yapistirin", "sk-..."}
        return bool(self.openai_api_key and self.openai_api_key not in placeholders)

    def _call_openai(self, system_prompt: str, user_prompt: str, max_tokens: int = 200, temperature: float = 0.2) -> str:
        """OpenAI ChatGPT API çağrısı (ortak yardımcı)."""
        if not self.openai_api_key:
            return ""
        
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.openai_api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": self.openai_model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=15)
            if response.status_code == 429:
                print("[NLP_OPENAI] Rate limit hit (429). Falling back to mock/local.")
                # self.use_mock = True # İsterseniz kalıcı mock'a geçebiliriz
                return ""
            response.raise_for_status()
            data = response.json()
            return data["choices"][0]["message"]["content"].strip()
        except Exception as exc:
            print(f"[NLP_OPENAI] API hatasi: {exc}")
            return ""

    def _fallback_summary(self, text: str) -> str:
        clean = " ".join((text or "").split())
        if not clean:
            return "- Özet üretilemedi.\n- Kaynak içerik boş geldi.\n- Daha sonra tekrar deneyin."

        parts = [segment.strip(" .") for segment in clean.replace("!", ".").replace("?", ".").split(".") if segment.strip()]
        if not parts:
            parts = [clean]

        bullets = []
        for sentence in parts[:3]:
            short_sentence = sentence[:140].rstrip()
            bullets.append(f"- {short_sentence}.")

        while len(bullets) < 3:
            bullets.append("- Haber akışı için kısa açıklama mevcut.")

        return "\n".join(bullets[:3])

    def _summarize_with_openai(self, text: str) -> str:
        """OpenAI ChatGPT ile haber özetleme."""
        if not self.openai_api_key:
            return self._fallback_summary(text)

        cache_key = text.strip()[:500]
        if cache_key in self.summary_cache:
            return self.summary_cache[cache_key]

        system = "Sen bir Türkçe haber özetleyicisisin. Kısa, net ve tarafsız özetler üretirsin."
        user = (
            "Aşağıdaki haber metnini Türkçe olarak en fazla 3 kısa madde halinde özetle. "
            "Her satır '- ' ile başlasın. Abartı kullanma, net ol.\n\n"
            f"Haber:\n{text[:1500]}"
        )

        result = self._call_openai(system, user, max_tokens=200, temperature=0.2)
        if not result:
            result = self._fallback_summary(text)
        
        self.summary_cache[cache_key] = result
        return result

    def get_zero_shot_classifier(self):
        """Zero Shot modelini lazy loading ile bir kez yükler (CPU/GPU Hybrid Offloading)."""
        if self._zero_shot_classifier is None:
            print("[NLP_INIT] Loading Zero-Shot Classification Model (valhalla/distilbart-mnli-12-3) with Accelerate Hybrid Offloading...")
            try:
                from transformers import pipeline, AutoModelForSequenceClassification, AutoTokenizer
                import os
                
                model_name = "valhalla/distilbart-mnli-12-3"
                offload_dir = os.path.join(os.path.dirname(__file__), "offload")
                os.makedirs(offload_dir, exist_ok=True)

                tokenizer = AutoTokenizer.from_pretrained(model_name)
                # Accelerate kütüphanesi ile RTX 4050 için dinamik cihaz haritası ve sistem RAM'ine offload
                model = AutoModelForSequenceClassification.from_pretrained(
                    model_name,
                    device_map="auto",
                    offload_folder=offload_dir,
                    offload_state_dict=True
                )
                
                self._zero_shot_classifier = pipeline("zero-shot-classification", model=model, tokenizer=tokenizer)
            except Exception as e:
                print(f"[NLP_ERROR] HuggingFace Pipeline Load Error (Accelerate): {e}")
                self._zero_shot_classifier = "ERROR"
        return self._zero_shot_classifier

    def classify_text(self, text: str) -> str:
        """
        HuggingFace Zero-Shot ile %100 kesin kategori eşleştirmesi.
        Eğitim gerektirmeden self.categories_pool havuzundan en mantıklı kategoriyi seçer.
        """
        if not text:
            return "World"
            
        cache_key = text.strip()[:300]
        if cache_key in self.classify_cache:
            return self.classify_cache[cache_key]
        
        classifier = self.get_zero_shot_classifier()
        
        # Eğer kütüphane load edilemediyse fallback at:
        if classifier == "ERROR":
            fallback = self._keyword_classify(text)
            self.classify_cache[cache_key] = fallback
            return fallback
            
        # Zero-Shot NLP Pipeline Çalıştırması
        try:
            short_text = text[:800] # Hız için ilk 800 karaktere bakılır
            prediction = classifier(short_text, self.categories_pool, multi_label=False)
            best_label = prediction['labels'][0]
            
            self.classify_cache[cache_key] = best_label
            return best_label
        except Exception as e:
            print(f"[NLP_ERROR] Zero-shot prediction failed: {e}")
            fallback = self._keyword_classify(text)
            self.classify_cache[cache_key] = fallback
            return fallback

    def _keyword_classify(self, text: str) -> str:
        """Keyword tabanlı basit sınıflandırma (fallback)."""
        text_lower = text.lower()
        
        weather_kw = ["hava durumu", "sıcaklık", "yağmur", "kar", "rüzgar", "derece", "fırtına", "meteoroloji", "hava sıcaklığı",
                      "weather", "forecast", "temperature", "storm", "hurricane", "tornado", "flood", "drought", "celsius", "fahrenheit",
                      "rain", "snow", "wind", "sunny", "cloudy", "thunderstorm", "climate"]
        if any(kw in text_lower for kw in weather_kw):
            return "Weather"
        
        tech_kw = ["teknoloji", "yapay zeka", "yazılım", "bilgisayar", "internet", "dijital", "uygulama", "api", "tech", "robot", "siber",
                   "technology", "artificial intelligence", "software", "computer", "digital", "app", "cyber", "ai"]
        if any(kw in text_lower for kw in tech_kw):
            return "Technology"
        
        sports_kw = ["spor", "maç", "gol", "lig", "futbol", "basketbol", "şampiyon", "transfer", "turnuva", "olimpiyat",
                     "sports", "match", "goal", "league", "football", "soccer", "basketball", "champion", "tournament", "olympic"]
        if any(kw in text_lower for kw in sports_kw):
            return "Sports"
        
        economy_kw = ["ekonomi", "borsa", "dolar", "euro", "enflasyon", "faiz", "bütçe", "ihracat", "ithalat", "piyasa", "merkez bankası",
                      "economy", "stock", "dollar", "inflation", "interest rate", "budget", "export", "import", "market", "central bank", "gdp"]
        if any(kw in text_lower for kw in economy_kw):
            return "Economy"
        
        health_kw = ["sağlık", "hastane", "doktor", "tedavi", "hastalık", "aşı", "ilaç", "kanser", "koronavirüs", "pandemi",
                     "health", "hospital", "doctor", "treatment", "disease", "vaccine", "medicine", "cancer", "pandemic"]
        if any(kw in text_lower for kw in health_kw):
            return "Health"
        
        science_kw = ["bilim", "araştırma", "keşif", "uzay", "nasa", "dna", "deney", "fizik", "kimya", "gen",
                      "science", "research", "discovery", "space", "experiment", "physics", "chemistry"]
        if any(kw in text_lower for kw in science_kw):
            return "Science"
        
        edu_kw = ["eğitim", "okul", "üniversite", "öğrenci", "sınav", "yks", "ales", "öğretmen", "müfredat",
                  "education", "school", "university", "student", "exam", "teacher", "curriculum"]
        if any(kw in text_lower for kw in edu_kw):
            return "Education"
        
        culture_kw = ["kültür", "sanat", "sinema", "müzik", "tiyatro", "sergi", "konser", "festival", "roman", "edebiyat",
                      "culture", "art", "cinema", "music", "theater", "exhibition", "concert", "festival", "literature"]
        if any(kw in text_lower for kw in culture_kw):
            return "Culture"
        
        politics_kw = ["siyaset", "politika", "seçim", "meclis", "bakan", "cumhurbaşkanı", "parti", "hükümet", "yasa", "kanun", "milletvekili",
                       "politics", "election", "parliament", "minister", "president", "party", "government", "law", "senator", "congress"]
        if any(kw in text_lower for kw in politics_kw):
            return "Politics"
            
        general_kw = ["kaza", "silah", "cinayet", "polis", "jandarma", "olay", "uyarı", "şiddet", "saldırı", "mahkeme", "ölüm", "kavga", "vurdu", "dehşet", "yaralandı", "yaralı", "çarp", "korkunç", "yangın", "operasyon", "gözaltı", "kurtarma", "itfaiye"]
        if any(kw in text_lower for kw in general_kw):
            return "General"
        
        return "World"

    def translate_text(self, text: str, target_lang: str) -> str:
        """Haber metnini hedef dile çevir."""
        if not text or target_lang == "tr":
            return text
        
        lang_names = {"en": "English", "es": "Spanish", "fr": "French", "de": "German", "tr": "Turkish"}
        lang_name = lang_names.get(target_lang, "English")
        
        cache_key = f"{target_lang}:{text.strip()[:300]}"
        if cache_key in self.summary_cache:
            return self.summary_cache[cache_key]
        
        if self.use_mock:
            return text  # Mock modda çeviri yapma
        
        system = f"You are a professional translator. Translate the following text to {lang_name}. Only output the translation, nothing else."
        result = self._call_openai(system, text[:1500], max_tokens=500, temperature=0.3)
        
        if result:
            self.summary_cache[cache_key] = result
            return result
        return text

    def extract_keywords(self, text: str, max_words: int = 5) -> List[str]:
        """Otomatik Etiketleme."""
        if self.use_mock:
            words = [w for w in text.split() if len(w) > 5][:max_words]
            return [w.capitalize() for w in words]
        
        system = "Verilen haber metninden en önemli 5 anahtar kelimeyi çıkar. Her kelimeyi virgülle ayır."
        result = self._call_openai(system, text[:800], max_tokens=50, temperature=0.1)
        if result:
            return [kw.strip() for kw in result.split(",")][:max_words]
        return []

    def summarize_bullets(self, text: str) -> str:
        """Max 3 madde özetleme."""
        if self.use_mock:
            return self._fallback_summary(text)
        else:
            return self._summarize_with_openai(text)

    def analyze_sentiment(self, text: str) -> SentimentType:
        """Duygu Analizi."""
        if self.use_mock:
            text_lower = text.lower()
            if "alert" in text_lower or "breaking" in text_lower or "son dakika" in text_lower:
                return SentimentType.URGENT
            elif "başarı" in text_lower or "success" in text_lower:
                return SentimentType.POSITIVE
            return random.choice([SentimentType.NEUTRAL, SentimentType.NEGATIVE, SentimentType.POSITIVE])
        
        system = "Haber metninin duygusal tonunu belirle. Sadece şu cevaplardan birini yaz: POSITIVE, NEGATIVE, NEUTRAL, URGENT"
        result = self._call_openai(system, text[:500], max_tokens=10, temperature=0.1)
        if result:
            mapping = {"POSITIVE": SentimentType.POSITIVE, "NEGATIVE": SentimentType.NEGATIVE, "URGENT": SentimentType.URGENT}
            return mapping.get(result.strip().upper(), SentimentType.NEUTRAL)
        return SentimentType.NEUTRAL

    def chat_with_article(self, text: str, question: str) -> str:
        """(RAG) Haberin bağlamına dayalı soru yanıtlama sistemi"""
        if self.use_mock:
            return "Sohbet özelliği için '.env' içerisine geçerli bir OPENAI_API_KEY girmelisiniz (Mock modundayım)."

        system = (
            "Sen zeki, bağımsız ve son derece sınırlı bir AI asistanısın. "
            "AŞAĞIDAKİ KURALA KESİNLİKLE UY: Sadece sana verilen "
            "HABER METNİ (Context) içeriğindeki bilgilere dayanarak cevap ver. "
            "Eğer sorunun cevabı metnin içinde açıkça YER ALMIYORSA (veya doğrudan çıkarılamıyorsa), "
            "uzatmadan sadece 'Sana sunulan haber metninde bu yönde bir bilgi bulunmuyor.' de."
        )
        
        # Sınırlandırma (Token tasarrufu)
        safe_text = text[:3000] if len(text) > 3000 else text
        
        user = (
            f"HABER METNİ:\n{safe_text}\n\n"
            f"KULLANICI SORUSU: {question}\n\n"
            "Cevabın:"
        )
        
        result = self._call_openai(system, user, max_tokens=350, temperature=0.1)
        if result:
            return result
        return "Sistem şu anda meşgul, lütfen daha sonra tekrar deneyiniz."

    def chat_global(self, context_data: str, question: str) -> str:
        """Genel haber asistanı (Float Chat) için endpoint fonksiyonu."""
        if self.use_mock:
            return "Arka planda OPENAI_API_KEY bulunamadığından sistem deneme modundadır."
            
        system = (
            "Sen 'BilimHaber' isimli haber portalının akıllı yapay zeka asistanısın. "
            "Kullanıcılara profesyonel ve yardımcı olacak yanıtlar verirsin. "
            f"Şu anki gündem özetleri aşağıdadır. Buna göre cevap ver:\n{context_data[:3000]}"
        )
        return self._call_openai(system, question, max_tokens=400, temperature=0.5)

    def extract_entities(self, text: str) -> List[Dict[str, str]]:
        """
        Metin içindeki varlıkları (Location, Organization, Disease, Event) çıkartır.
        SpaCy modelini veya kural tabanlı regexleri kullanır.
        """
        if not hasattr(self, '_nlp_spacy'):
            try:
                import spacy
                self._nlp_spacy = spacy.load("en_core_web_sm")
            except ImportError:
                print("[NER] spaCy bulunamadi, varlik cikarimi yapilamiyor.")
                self._nlp_spacy = None
            except OSError:
                print("[NER] en_core_web_sm modeli bulunamadi, varlik cikarimi yapilamiyor.")
                self._nlp_spacy = None

        entities = []
        found_names = set()
        
        # 1. Kural tabanlı çıkarım (Hastalıklar ve Krizler)
        text_lower = text.lower()
        diseases = ["covid-19", "coronavirus", "cancer", "flu", "pandemi", "salgın", "virüs", "malaria", "ebola"]
        events = ["deprem", "savaş", "kriz", "earthquake", "war", "crisis", "tsunami", "seçim", "election", "sel", "flood"]
        
        for d in diseases:
            if d in text_lower and d not in found_names:
                entities.append({"name": d.capitalize(), "type": "DISEASE"})
                found_names.add(d)
                
        for e in events:
            if e in text_lower and e not in found_names:
                entities.append({"name": e.capitalize(), "type": "EVENT"})
                found_names.add(e)
                
        # 2. SpaCy tabanlı NER (Location, Organization)
        if self._nlp_spacy and text:
            doc = self._nlp_spacy(text[:3000]) # Sınırlandırma
            for ent in doc.ents:
                ent_name = ent.text.strip()
                if len(ent_name) < 2 or ent_name.lower() in found_names:
                    continue
                    
                if ent.label_ in ["GPE", "LOC"]:
                    entities.append({"name": ent_name, "type": "LOCATION"})
                    found_names.add(ent_name.lower())
                elif ent.label_ == "ORG":
                    entities.append({"name": ent_name, "type": "ORGANIZATION"})
                    found_names.add(ent_name.lower())
                    
        return entities

    def calculate_sentiment_score(self, text: str) -> float:
        """Haber metninin duygu skorunu -1.0 ile 1.0 arasında hesaplar."""
        if not text:
            return 0.0
            
        if not hasattr(self, '_vader'):
            try:
                from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
                self._vader = SentimentIntensityAnalyzer()
            except ImportError:
                print("[SENTIMENT] vaderSentiment bulunamadi, skor 0.0 donuyor.")
                return 0.0
                
        scores = self._vader.polarity_scores(text[:2000])
        return float(scores.get('compound', 0.0))

# Singleton
nlp_manager = NLPService(use_mock=True)
# nlp_manager.use_mock = True  # Kuvvetle zorla (isteğe bağlı)
