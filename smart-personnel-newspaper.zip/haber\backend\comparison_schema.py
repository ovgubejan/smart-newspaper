from __future__ import annotations

from sqlalchemy import inspect, text


NEWS_ARTICLE_COLUMNS = {
    "source_type": "ALTER TABLE news_articles ADD COLUMN source_type VARCHAR(50)",
    "author": "ALTER TABLE news_articles ADD COLUMN author VARCHAR(200)",
    "category": "ALTER TABLE news_articles ADD COLUMN category VARCHAR(100)",
    "country": "ALTER TABLE news_articles ADD COLUMN country VARCHAR(100)",
    "image_url": "ALTER TABLE news_articles ADD COLUMN image_url VARCHAR(1000)",
    "keywords": "ALTER TABLE news_articles ADD COLUMN keywords JSON",
    "entities": "ALTER TABLE news_articles ADD COLUMN entities JSON",
    "normalized_hash": "ALTER TABLE news_articles ADD COLUMN normalized_hash VARCHAR(64)",
    "event_id": "ALTER TABLE news_articles ADD COLUMN event_id VARCHAR(36)",
    "created_at": "ALTER TABLE news_articles ADD COLUMN created_at DATETIME",
    "updated_at": "ALTER TABLE news_articles ADD COLUMN updated_at DATETIME",
}

INDEX_STATEMENTS = [
    "CREATE INDEX IF NOT EXISTS ix_news_articles_normalized_hash ON news_articles (normalized_hash)",
    "CREATE INDEX IF NOT EXISTS ix_news_articles_event_id ON news_articles (event_id)",
    "CREATE INDEX IF NOT EXISTS ix_comparison_events_event_hash ON comparison_events (event_hash)",
    "CREATE INDEX IF NOT EXISTS ix_comparison_feed_items_priority_score ON comparison_feed_items (priority_score)",
    "CREATE INDEX IF NOT EXISTS ix_comparison_feed_items_new_until ON comparison_feed_items (new_until)",
]


def ensure_comparison_schema(engine, base) -> None:
    base.metadata.create_all(engine)
    inspector = inspect(engine)

    if "news_articles" not in inspector.get_table_names():
        return

    existing_columns = {column["name"] for column in inspector.get_columns("news_articles")}
    statements = [sql for column, sql in NEWS_ARTICLE_COLUMNS.items() if column not in existing_columns]

    with engine.begin() as connection:
        for statement in statements:
            connection.execute(text(statement))
        for statement in INDEX_STATEMENTS:
            connection.execute(text(statement))
