// js/earth_background.js
// Initialize Three.js Scene for Earth Background with glowing data streams converging to Turkey

let earthBackgroundStarted = false;

function initEarthBackground() {
    if (earthBackgroundStarted) return;
    earthBackgroundStarted = true;

    const canvas = document.getElementById('webgl-earth-bg');
    if (!canvas) return;

    // Ensure Three.js is loaded
    if (typeof THREE === 'undefined') {
        console.error("Three.js is not loaded.");
        return;
    }

    // SCENE, CAMERA, RENDERER
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020813); // Deep space navy/charcoal tone

    const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
    // Position camera for a cinematic, wide-angle view
    camera.position.set(0, 6, 32); 

    const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // optimize performance
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const isSmallScreen = window.innerWidth < 1024;

    // POST-PROCESSING: BLOOM (if available)
    let composer = null;
    if (!prefersReducedMotion && !isSmallScreen && typeof THREE.EffectComposer !== 'undefined' && typeof THREE.UnrealBloomPass !== 'undefined') {
        const renderScene = new THREE.RenderPass(scene, camera);
        const bloomPass = new THREE.UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 1.5, 0.4, 0.85);
        bloomPass.threshold = 0.15;
        bloomPass.strength = 1.2;
        bloomPass.radius = 0.8;

        composer = new THREE.EffectComposer(renderer);
        composer.addPass(renderScene);
        composer.addPass(bloomPass);
    }

    // MAIN GROUP to rotate everything together smoothly
    const earthGroup = new THREE.Group();
    scene.add(earthGroup);

    // TILT EARTH for natural look (Axial tilt ~ 23.5 degrees)
    earthGroup.rotation.z = 23.5 * (Math.PI / 180);

    // EARTH GLOBE
    const radius = 10;
    const segments = 64;
    const earthGeo = new THREE.SphereGeometry(radius, segments, segments);
    
    // High-contrast, sleek modern material
    const earthMat = new THREE.MeshStandardMaterial({
        color: 0x051020, // Very deep navy
        emissive: 0x000000,
        roughness: 0.6,
        metalness: 0.3,
    });
    
    // Load high-resolution texture
    const textureLoader = new THREE.TextureLoader();
    textureLoader.load('https://unpkg.com/three-globe/example/img/earth-night.jpg', (texture) => {
        texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
        earthMat.map = texture;
        earthMat.color = new THREE.Color(0xffffff);
        earthMat.needsUpdate = true;
    });

    const earthMesh = new THREE.Mesh(earthGeo, earthMat);
    earthGroup.add(earthMesh);

    // GLOWING DIGITAL GRID OVERLAY
    const gridGeo = new THREE.SphereGeometry(radius + 0.05, 48, 48);
    const gridMat = new THREE.MeshBasicMaterial({
        color: 0x00ffff, // Cyan
        wireframe: true,
        transparent: true,
        opacity: 0.03, // Subtle overlay
        blending: THREE.AdditiveBlending
    });
    const gridMesh = new THREE.Mesh(gridGeo, gridMat);
    earthGroup.add(gridMesh);

    // ATMOSPHERE HALO
    const haloGeo = new THREE.SphereGeometry(radius + 0.3, 64, 64);
    const haloMat = new THREE.MeshBasicMaterial({
        color: 0x0055ff,
        transparent: true,
        opacity: 0.1,
        side: THREE.BackSide,
        blending: THREE.AdditiveBlending
    });
    const haloMesh = new THREE.Mesh(haloGeo, haloMat);
    earthGroup.add(haloMesh);

    // LIGHTING
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.2);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(20, 15, 10);
    scene.add(dirLight);

    // Cinematic blue rim light
    const blueRimLight = new THREE.PointLight(0x00aaff, 3, 50);
    blueRimLight.position.set(-20, 0, -10);
    scene.add(blueRimLight);

    // HELPER FUNCTION: Convert Lat/Lon to Vector3
    function getPosFromLatLon(lat, lon, R) {
        const phi = (90 - lat) * (Math.PI / 180);
        const theta = (lon + 180) * (Math.PI / 180);
        const x = -(R * Math.sin(phi) * Math.cos(theta));
        const z = (R * Math.sin(phi) * Math.sin(theta));
        const y = (R * Math.cos(phi));
        return new THREE.Vector3(x, y, z);
    }

    // TARGET: TURKEY COORDINATES
    const turkeyLat = 39.0;
    const turkeyLon = 35.0;
    const turkeyPos = getPosFromLatLon(turkeyLat, turkeyLon, radius + 0.1);

    // PULSE MESH AT TURKEY
    const pulseMat = new THREE.MeshBasicMaterial({
        color: 0x00ffff, // Cyan
        transparent: true,
        opacity: 0.8,
        blending: THREE.AdditiveBlending,
        depthWrite: false
    });
    const pulseGeo = new THREE.CircleGeometry(0.6, 32);
    const pulseMesh = new THREE.Mesh(pulseGeo, pulseMat);
    pulseMesh.position.copy(turkeyPos);
    
    // Make circle lay flat on surface
    const normal = turkeyPos.clone().normalize();
    pulseMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
    earthGroup.add(pulseMesh);

    // Center bright dot for Turkey
    const centerDotMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const centerDotGeo = new THREE.CircleGeometry(0.15, 16);
    const centerDot = new THREE.Mesh(centerDotGeo, centerDotMat);
    centerDot.position.copy(turkeyPos).multiplyScalar(1.001);
    centerDot.quaternion.copy(pulseMesh.quaternion);
    earthGroup.add(centerDot);

    // Light pulse source at Turkey
    const pulseLight = new THREE.PointLight(0x00ffff, 0, 15);
    pulseLight.position.copy(turkeyPos).multiplyScalar(1.05); // hover slightly above
    earthGroup.add(pulseLight);

    // DATA STREAMS GENERATION
    const streams = [];
    const numStreams = prefersReducedMotion ? 0 : (isSmallScreen ? 16 : 32);
    
    for(let i=0; i < numStreams; i++) {
        // Random global starting points
        const startLat = (Math.random() - 0.5) * 140; // Avoid exact poles
        const startLon = (Math.random() - 0.5) * 360;
        const startPos = getPosFromLatLon(startLat, startLon, radius);

        // Calculate control point for arced trajectory
        const midPos = startPos.clone().add(turkeyPos).multiplyScalar(0.5);
        // Push midPos outward to create altitude arc
        const distance = startPos.distanceTo(turkeyPos);
        midPos.normalize().multiplyScalar(radius + (distance * 0.3));

        const curve = new THREE.QuadraticBezierCurve3(startPos, midPos, turkeyPos);
        const curvePoints = curve.getPoints(60);
        
        const lineGeo = new THREE.BufferGeometry().setFromPoints(curvePoints);
        const lineMat = new THREE.LineBasicMaterial({
            color: 0x00ffff,
            transparent: true,
            opacity: 0.7,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });
        
        const line = new THREE.Line(lineGeo, lineMat);
        line.geometry.setDrawRange(0, 0); // Start invisible
        earthGroup.add(line);

        streams.push({
            line: line,
            progress: Math.random() * -1.5, // Staggered start times
            speed: 0.008 + Math.random() * 0.006 // Varied speeds
        });
    }

    // Camera initial framing: ensure Turkey is in view
    // Start camera rotated slightly offset for dramatic effect
    camera.lookAt(new THREE.Vector3(0, 0, 0));

    // ANIMATION LOOP
    let activePulse = false;
    let pulseTime = 0;

    function animate() {
        requestAnimationFrame(animate);

        // 1. Smooth Earth Rotation
        earthGroup.rotation.y += 0.0015;

        // 2. Animate Data Streams
        let streamsArriving = 0;
        
        streams.forEach(stream => {
            stream.progress += stream.speed;
            
            if(stream.progress > 0 && stream.progress <= 1) {
                // Drawing the line towards Turkey
                const drawCount = Math.floor(stream.progress * 60);
                // Keep only the tail of the line showing for a comet effect
                const tailLength = 15; 
                const startIdx = Math.max(0, drawCount - tailLength);
                stream.line.geometry.setDrawRange(startIdx, drawCount - startIdx);
            } else if (stream.progress > 1 && stream.progress < 1.1) {
                // Instantly arrived
                streamsArriving++;
                stream.line.geometry.setDrawRange(0, 0); 
            } else if (stream.progress >= 1.1) {
                // Reset stream
                stream.progress = Math.random() * -1;
            }
        });

        // 3. Animate Pulse
        if(streamsArriving > 0) {
            pulseTime = 1.0; // Trigger pulse
        }

        if(pulseTime > 0) {
            pulseTime -= 0.03;
            // Expand circle
            const scale = 1 + (1 - pulseTime) * 3;
            pulseMesh.scale.set(scale, scale, 1);
            // Fade out circle
            pulseMesh.material.opacity = pulseTime * 0.8;
            
            // Peak light intensity
            pulseLight.intensity = pulseTime * 3;
            
            // Highlight center dot
            centerDot.material.color.setHex(0xffffff);
            centerDot.scale.set(1.5, 1.5, 1);
        } else {
            pulseMesh.scale.set(1, 1, 1);
            pulseMesh.material.opacity = 0;
            pulseLight.intensity = 0;
            
             // Default center dot
            centerDot.material.color.setHex(0x00ffff);
            centerDot.scale.set(1, 1, 1);
        }

        // 4. Render
        if (composer) {
            composer.render();
        } else {
            renderer.render(scene, camera);
        }
    }
    animate();

    // RESIZE HANDLER
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
        if (composer) composer.setSize(window.innerWidth, window.innerHeight);
    });
}

function bootEarthBackground() {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const delay = window.innerWidth < 1024 ? 1200 : 450;
    const start = () => window.setTimeout(initEarthBackground, delay);

    if (typeof window.requestIdleCallback === 'function') {
        window.requestIdleCallback(start, { timeout: 2500 });
        return;
    }

    start();
}

if (document.readyState === 'complete') {
    bootEarthBackground();
} else {
    window.addEventListener('load', bootEarthBackground, { once: true });
}
