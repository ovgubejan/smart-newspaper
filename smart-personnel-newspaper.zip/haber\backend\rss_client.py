# rss_client.py
import feedparser
from datetime import datetime
import os
from news_dto import NewsDTO

# Basit Bellek İçi Önbellek (Caching) Mekanizması
_rss_cache = {}
CACHE_TTL_SECONDS = 900 # 15 Dakika

TRT_RSS_URL = "https://www.trthaber.com/manset_articles.rss"

# Hürriyet Kategori Map
HURRIYET_FEEDS = {
    "gundem": "Politics",     # http://www.hurriyet.com.tr/rss/gundem
    "ekonomi": "Economy",    # http://www.hurriyet.com.tr/rss/ekonomi
    "dunya": "World",        # http://www.hurriyet.com.tr/rss/dunya
    "spor": "Sports",        # http://www.hurriyet.com.tr/rss/spor
    "teknoloji": "Technology" # http://www.hurriyet.com.tr/rss/teknoloji
}

# TRT Kategori Map (URL içindeki ASCII isimlendirmeden)
TRT_URL_MAP = {
    "gundem": "Politics", "ekonomi": "Economy", "spor": "Sports",
    "dunya": "World", "teknoloji": "Technology", "saglik": "Health",
    "bilim-teknoloji": "Technology", "turkiye": "Politics"
}

def fetch_rss_news(url, source_name, cache_key, default_category="World", category_map=None):
    """Genel RSS çekme fonksiyonu (Caching dahil)"""
    if cache_key in _rss_cache:
        cached_data, timestamp = _rss_cache[cache_key]
        if (datetime.utcnow() - timestamp).total_seconds() < CACHE_TTL_SECONDS:
            return cached_data

    try:
        import requests
        print(f"[RSS_CLIENT] {source_name} RSS cekiliyor: {url}")
        resp = requests.get(url, timeout=5)
        resp.raise_for_status()
        feed = feedparser.parse(resp.content)
        dtos = []
        import re
        
        for entry in feed.entries:
            # 1. Kategori Map Mantığı
            category = default_category
            if category_map:
                for url_key, en_cat in category_map.items():
                    if f"/{url_key}/" in entry.link.lower() or f"/{url_key}" in entry.link.lower():
                        category = en_cat
                        break
            
            # 2. Resim Ayıklama Mantığı
            image_url = None
            # Hürriyet / Genel media:content
            if 'media_content' in entry and len(entry.media_content) > 0:
                image_url = entry.media_content[0]['url']
            # Enclosure check (Hürriyet or others)
            elif 'enclosures' in entry and len(entry.enclosures) > 0:
                image_url = entry.enclosures[0]['href']
            # TRT Haber / Description içindeki IMG tagı
            elif hasattr(entry, 'description') and '<img src=' in entry.description:
                img_match = re.search(r'<img src="([^"]+)"', entry.description)
                if img_match:
                    image_url = img_match.group(1)
            
            # None safety
            if image_url and not image_url.startswith('http'):
                image_url = None
            
            dto = NewsDTO(
                title=entry.title,
                url=entry.link,
                description=entry.description if hasattr(entry, 'description') else entry.summary,
                source=source_name,
                language="tr",
                image_url=image_url
            )
            dto.ai_category = category #DTO'yu API tarafında kolaylaştırmak için geçici field
            dtos.append(dto)
        
        _rss_cache[cache_key] = (dtos, datetime.utcnow())
        return dtos
    except Exception as e:
        print(f"[RSS_CLIENT] {source_name} Hata: {e}")
        return []

def fetch_trt_news():
    return fetch_rss_news(TRT_RSS_URL, "TRT Haber", "trt_manset", category_map=TRT_URL_MAP)

def fetch_all_hurriyet_news():
    """Tüm Hürriyet kategorilerini çeker"""
    all_news = []
    for slug, cat in HURRIYET_FEEDS.items():
        url = f"http://www.hurriyet.com.tr/rss/{slug}"
        news = fetch_rss_news(url, "Hürriyet", f"hurriyet_{slug}", default_category=cat)
        all_news.extend(news)
    return all_news

if __name__ == "__main__":
    # Test
    trt = fetch_trt_news()
    hurriyet = fetch_all_hurriyet_news()
    print(f"TRT: {len(trt)}, Hürriyet: {len(hurriyet)}")
    for n in (trt + hurriyet)[:10]:
        cat = getattr(n, 'ai_category', 'N/A')
        print(f"  [{cat}] {n.source}: {n.title}")
