"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type ProtectedRouteProps = {
    children: React.ReactNode;
};

export default function ProtectedRoute({
    children,
}: ProtectedRouteProps) {
    const router = useRouter();
    const [authorized, setAuthorized] = useState(false);

    useEffect(() => {
        const currentUser = localStorage.getItem("currentUser");

        if (!currentUser) {
            router.push("/login");
        } else {
            setAuthorized(true);
        }
    }, [router]);

    if (!authorized) {
        return (
            <main className="flex min-h-screen items-center justify-center bg-slate-100">
                <p className="text-slate-600">Yükleniyor...</p>
            </main>
        );
    }

    return <>{children}</>;
}