"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

export default function Navbar() {
    const router = useRouter();
    const pathname = usePathname();

    const handleLogout = () => {
        localStorage.removeItem("currentUser");
        localStorage.removeItem("preferences");
        localStorage.removeItem("bookmarks");
        localStorage.removeItem("readArticles");
        router.push("/login");
    };

    const navLinkClass = (path: string) =>
        `rounded-lg px-3 py-2 text-sm font-medium transition ${pathname === path
            ? "bg-blue-100 text-blue-700"
            : "text-slate-700 hover:bg-slate-100"
        }`;

    return (
        <header className="border-b border-slate-200 bg-white">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
                <Link href="/feed" className="text-xl font-bold text-blue-600">
                    Smart Personnel Newspaper
                </Link>

                <nav className="flex items-center gap-3">
                    <Link href="/feed" className={navLinkClass("/feed")}>
                        Feed
                    </Link>

                    <Link href="/search" className={navLinkClass("/search")}>
                        Search
                    </Link>

                    <Link href="/bookmarks" className={navLinkClass("/bookmarks")}>
                        Bookmarks
                    </Link>

                    <Link href="/profile" className={navLinkClass("/profile")}>
                        Profile
                    </Link>

                    <button
                        onClick={handleLogout}
                        className="rounded-lg bg-red-500 px-3 py-2 text-sm font-medium text-white hover:bg-red-600"
                    >
                        Çıkış
                    </button>
                </nav>
            </div>
        </header>
    );
}