"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

const categories = [
    "Technology",
    "Business",
    "Health",
    "Sports",
    "Education",
    "Science",
    "Entertainment",
];

export default function PreferencesPage() {
    const [selected, setSelected] = useState<string[]>([]);
    const router = useRouter();

    useEffect(() => {
        const savedPreferences = localStorage.getItem("preferences");
        if (savedPreferences) {
            setSelected(JSON.parse(savedPreferences));
        }
    }, []);

    const toggleCategory = (cat: string) => {
        if (selected.includes(cat)) {
            setSelected(selected.filter((c) => c !== cat));
        } else {
            setSelected([...selected, cat]);
        }
    };

    const handleContinue = () => {
        localStorage.setItem("preferences", JSON.stringify(selected));
        router.push("/feed");
    };

    return (
        <main className="flex min-h-screen items-center justify-center bg-slate-100 px-4 py-10">
            <div className="w-full max-w-xl rounded-2xl bg-white p-8 shadow-lg">
                <h1 className="mb-4 text-2xl font-bold text-slate-900">
                    İlgi Alanlarını Seç
                </h1>

                <div className="mb-6 grid grid-cols-2 gap-4">
                    {categories.map((cat) => (
                        <button
                            key={cat}
                            type="button"
                            onClick={() => toggleCategory(cat)}
                            className={`rounded-xl border px-4 py-3 font-medium transition ${selected.includes(cat)
                                    ? "border-blue-600 bg-blue-600 text-white"
                                    : "border-slate-300 bg-white text-slate-800 hover:bg-slate-50"
                                }`}
                        >
                            {cat}
                        </button>
                    ))}
                </div>

                <button
                    onClick={handleContinue}
                    className="w-full rounded-xl bg-blue-600 py-3 font-semibold text-white transition hover:bg-blue-700"
                >
                    Devam Et
                </button>
            </div>
        </main>
    );
}