"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";
import { allNews } from "@/data/news";

export default function FeedPage() {
    const [preferences, setPreferences] = useState<string[]>([]);
    const [sortBy, setSortBy] = useState("relevance");
    const [readArticles, setReadArticles] = useState<number[]>([]);

    useEffect(() => {
        const savedPreferences = localStorage.getItem("preferences");
        if (savedPreferences) {
            setPreferences(JSON.parse(savedPreferences));
        }

        const savedReadArticles = localStorage.getItem("readArticles");
        if (savedReadArticles) {
            setReadArticles(JSON.parse(savedReadArticles));
        }
    }, []);

    const filteredNews = useMemo(() => {
        let result = [...allNews];

        if (preferences.length > 0) {
            result = result.filter((item) => preferences.includes(item.category));
        }

        if (sortBy === "date") {
            result.sort((a, b) => b.date.localeCompare(a.date));
        } else if (sortBy === "popularity") {
            result.sort((a, b) => b.popularity - a.popularity);
        } else {
            result.sort((a, b) => b.popularity - a.popularity);
        }

        return result;
    }, [preferences, sortBy]);

    return (
        <ProtectedRoute>
            <Navbar />

            <main className="min-h-screen bg-slate-100 px-4 py-10">
                <div className="mx-auto max-w-5xl">
                    <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                        <div>
                            <h1 className="text-3xl font-bold text-slate-900">Haber Akışı</h1>
                            <p className="mt-2 text-slate-600">
                                Seçilen ilgi alanlarına göre kişiselleştirilmiş içerikler
                            </p>
                        </div>

                        <select
                            value={sortBy}
                            onChange={(e) => setSortBy(e.target.value)}
                            className="rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900"
                        >
                            <option value="relevance">Relevance</option>
                            <option value="date">Tarihe Göre</option>
                            <option value="popularity">Popülerliğe Göre</option>
                        </select>
                    </div>

                    {preferences.length > 0 && (
                        <div className="mb-6 flex flex-wrap gap-2">
                            {preferences.map((item) => (
                                <span
                                    key={item}
                                    className="rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-700"
                                >
                                    {item}
                                </span>
                            ))}
                        </div>
                    )}

                    {filteredNews.length === 0 ? (
                        <div className="rounded-2xl bg-white p-6 text-slate-600 shadow">
                            Seçtiğin kategorilere uygun haber bulunamadı.
                        </div>
                    ) : (
                        <div className="grid gap-4">
                            {filteredNews.map((news) => {
                                const isRead = readArticles.includes(news.id);

                                return (
                                    <Link
                                        key={news.id}
                                        href={`/article/${news.id}`}
                                        className="block rounded-2xl bg-white p-5 shadow transition hover:bg-slate-50"
                                    >
                                        <div className="mb-3 flex flex-wrap items-center gap-2 text-sm">
                                            <span className="font-medium text-blue-600">
                                                {news.category}
                                            </span>
                                            <span className="text-slate-400">•</span>
                                            <span className="text-slate-600">{news.source}</span>
                                            <span className="text-slate-400">•</span>
                                            <span className="text-slate-600">{news.date}</span>
                                            <span className="text-slate-400">•</span>
                                            <span className="text-slate-600">
                                                Popularity: {news.popularity}
                                            </span>

                                            {isRead && (
                                                <>
                                                    <span className="text-slate-400">•</span>
                                                    <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700">
                                                        Read
                                                    </span>
                                                </>
                                            )}
                                        </div>

                                        <h2 className="mb-2 text-xl font-semibold text-slate-900">
                                            {news.title}
                                        </h2>
                                        <p className="text-slate-600">{news.summary}</p>
                                    </Link>
                                );
                            })}
                        </div>
                    )}
                </div>
            </main>
        </ProtectedRoute>
    );
}