"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";
import { allNews, NewsItem } from "@/data/news";

export default function BookmarksPage() {
    const [bookmarkedNews, setBookmarkedNews] = useState<NewsItem[]>([]);

    const loadBookmarks = () => {
        const savedBookmarks = localStorage.getItem("bookmarks");
        const parsedBookmarks: number[] = savedBookmarks
            ? JSON.parse(savedBookmarks)
            : [];

        const filteredNews = allNews.filter((news) =>
            parsedBookmarks.includes(news.id)
        );

        setBookmarkedNews(filteredNews);
    };

    useEffect(() => {
        loadBookmarks();
    }, []);

    const handleRemoveBookmark = (id: number) => {
        const savedBookmarks = localStorage.getItem("bookmarks");
        const parsedBookmarks: number[] = savedBookmarks
            ? JSON.parse(savedBookmarks)
            : [];

        const updatedBookmarks = parsedBookmarks.filter((item) => item !== id);

        localStorage.setItem("bookmarks", JSON.stringify(updatedBookmarks));
        loadBookmarks();
    };

    return (
        <ProtectedRoute>
            <Navbar />

            <main className="min-h-screen bg-slate-100 px-4 py-10">
                <div className="mx-auto max-w-4xl">
                    <h1 className="mb-8 text-3xl font-bold text-slate-900">
                        Bookmarks
                    </h1>

                    {bookmarkedNews.length === 0 ? (
                        <div className="rounded-2xl bg-white p-5 text-slate-600 shadow">
                            Henüz kaydedilmiş haber yok.
                        </div>
                    ) : (
                        <div className="grid gap-4">
                            {bookmarkedNews.map((news) => (
                                <div
                                    key={news.id}
                                    className="rounded-2xl bg-white p-5 shadow"
                                >
                                    <Link
                                        href={`/article/${news.id}`}
                                        className="block hover:opacity-90"
                                    >
                                        <p className="mb-2 text-sm font-medium text-blue-600">
                                            {news.category}
                                        </p>
                                        <h2 className="mb-2 text-xl font-semibold text-slate-900">
                                            {news.title}
                                        </h2>
                                        <p className="text-slate-600">{news.summary}</p>
                                    </Link>

                                    <button
                                        onClick={() => handleRemoveBookmark(news.id)}
                                        className="mt-4 rounded-lg bg-red-500 px-4 py-2 text-sm font-medium text-white hover:bg-red-600"
                                    >
                                        Kaydı Kaldır
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </main>
        </ProtectedRoute>
    );
}