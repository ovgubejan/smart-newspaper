import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-100 to-slate-200 text-slate-900">
      <div className="mx-auto flex min-h-screen max-w-6xl flex-col justify-center px-6 py-16">
        <div className="max-w-3xl">
          <p className="mb-4 inline-block rounded-full bg-blue-100 px-4 py-1 text-sm font-medium text-blue-700">
            Smart Personnel Newspaper
          </p>

          <h1 className="mb-6 text-4xl font-bold leading-tight md:text-6xl">
            Kurumsal haberleri ve duyuruları
            <span className="text-blue-600"> kişiselleştirilmiş </span>
            şekilde takip et
          </h1>

          <p className="mb-8 max-w-2xl text-lg text-slate-600">
            Personellere özel haber akışı, tercihlere göre filtreleme, yer
            imleri ve kullanıcı odaklı modern bir gazete sistemi.
          </p>

          <div className="flex flex-col gap-4 sm:flex-row">
            <Link
              href="/login"
              className="rounded-xl bg-blue-600 px-6 py-3 text-center font-semibold text-white transition hover:bg-blue-700"
            >
              Giriş Yap
            </Link>

            <Link
              href="/register"
              className="rounded-xl border border-slate-300 bg-white px-6 py-3 text-center font-semibold text-slate-800 transition hover:bg-slate-50"
            >
              Kayıt Ol
            </Link>
          </div>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-3">
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <h2 className="mb-2 text-xl font-semibold">Kişisel Akış</h2>
            <p className="text-slate-600">
              İlgi alanlarına göre haberleri ve duyuruları öne çıkar.
            </p>
          </div>

          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <h2 className="mb-2 text-xl font-semibold">Kolay Erişim</h2>
            <p className="text-slate-600">
              Arama, filtreleme ve yer imleri ile içeriklere hızlı ulaş.
            </p>
          </div>

          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <h2 className="mb-2 text-xl font-semibold">Modern Arayüz</h2>
            <p className="text-slate-600">
              Mobil ve masaüstünde temiz, anlaşılır ve kullanışlı deneyim.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}