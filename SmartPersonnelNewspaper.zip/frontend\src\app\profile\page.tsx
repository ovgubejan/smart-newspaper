"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";

type CurrentUser = {
    fullName: string;
    email: string;
    role: string;
};

export default function ProfilePage() {
    const [user, setUser] = useState<CurrentUser | null>(null);
    const [preferences, setPreferences] = useState<string[]>([]);

    useEffect(() => {
        const savedUser = localStorage.getItem("currentUser");
        const savedPreferences = localStorage.getItem("preferences");

        if (savedUser) {
            setUser(JSON.parse(savedUser));
        }

        if (savedPreferences) {
            setPreferences(JSON.parse(savedPreferences));
        }
    }, []);

    return (
        <ProtectedRoute>
            <Navbar />

            <main className="min-h-screen bg-slate-100 px-4 py-10">
                <div className="mx-auto w-full max-w-xl rounded-2xl bg-white p-8 shadow">
                    <h1 className="mb-6 text-3xl font-bold text-slate-900">Profil</h1>

                    <div className="space-y-5">
                        <div>
                            <p className="text-sm text-slate-500">Ad Soyad</p>
                            <p className="text-lg font-medium text-slate-900">
                                {user?.fullName || "Bilinmiyor"}
                            </p>
                        </div>

                        <div>
                            <p className="text-sm text-slate-500">E-posta</p>
                            <p className="text-lg font-medium text-slate-900">
                                {user?.email || "Bilinmiyor"}
                            </p>
                        </div>

                        <div>
                            <p className="text-sm text-slate-500">Rol</p>
                            <p className="text-lg font-medium text-slate-900">
                                {user?.role || "User"}
                            </p>
                        </div>

                        <div>
                            <p className="text-sm text-slate-500">İlgi Alanları</p>
                            <div className="mt-2 flex flex-wrap gap-2">
                                {preferences.length > 0 ? (
                                    preferences.map((item) => (
                                        <span
                                            key={item}
                                            className="rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-700"
                                        >
                                            {item}
                                        </span>
                                    ))
                                ) : (
                                    <p className="text-slate-600">Henüz tercih seçilmedi.</p>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </ProtectedRoute>
    );
}