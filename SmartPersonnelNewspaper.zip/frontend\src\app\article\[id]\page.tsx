"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";
import { allNews } from "@/data/news";

export default function ArticlePage() {
    const params = useParams();
    const id = Number(params.id);

    const article = allNews.find((item) => item.id === id);
    const [isBookmarked, setIsBookmarked] = useState(false);

    useEffect(() => {
        const savedBookmarks = localStorage.getItem("bookmarks");
        const parsedBookmarks: number[] = savedBookmarks
            ? JSON.parse(savedBookmarks)
            : [];

        setIsBookmarked(parsedBookmarks.includes(id));

        const savedReadArticles = localStorage.getItem("readArticles");
        const parsedReadArticles: number[] = savedReadArticles
            ? JSON.parse(savedReadArticles)
            : [];

        if (!parsedReadArticles.includes(id)) {
            const updatedReadArticles = [...parsedReadArticles, id];
            localStorage.setItem("readArticles", JSON.stringify(updatedReadArticles));
        }
    }, [id]);

    const handleBookmarkToggle = () => {
        const savedBookmarks = localStorage.getItem("bookmarks");
        const parsedBookmarks: number[] = savedBookmarks
            ? JSON.parse(savedBookmarks)
            : [];

        let updatedBookmarks: number[];

        if (parsedBookmarks.includes(id)) {
            updatedBookmarks = parsedBookmarks.filter((item) => item !== id);
            setIsBookmarked(false);
        } else {
            updatedBookmarks = [...parsedBookmarks, id];
            setIsBookmarked(true);
        }

        localStorage.setItem("bookmarks", JSON.stringify(updatedBookmarks));
    };

    if (!article) {
        return (
            <ProtectedRoute>
                <Navbar />
                <main className="flex min-h-screen items-center justify-center bg-slate-100 px-4">
                    <div className="rounded-2xl bg-white p-8 shadow">
                        <h1 className="mb-3 text-2xl font-bold text-slate-900">
                            Makale bulunamadı
                        </h1>
                        <Link href="/feed" className="text-blue-600">
                            Haber akışına dön
                        </Link>
                    </div>
                </main>
            </ProtectedRoute>
        );
    }

    return (
        <ProtectedRoute>
            <Navbar />

            <main className="min-h-screen bg-slate-100 px-4 py-10">
                <div className="mx-auto max-w-3xl rounded-2xl bg-white p-8 shadow">
                    <p className="mb-2 text-sm font-medium text-blue-600">
                        {article.category}
                    </p>

                    <h1 className="mb-4 text-3xl font-bold text-slate-900">
                        {article.title}
                    </h1>

                    <p className="leading-8 text-slate-700">{article.content}</p>

                    <div className="mt-8 flex flex-wrap gap-3">
                        <button
                            onClick={handleBookmarkToggle}
                            className={`rounded-lg px-4 py-2 font-medium text-white ${isBookmarked
                                    ? "bg-green-600 hover:bg-green-700"
                                    : "bg-blue-600 hover:bg-blue-700"
                                }`}
                        >
                            {isBookmarked ? "Kaydedildi" : "Kaydet"}
                        </button>

                        <Link
                            href="/feed"
                            className="rounded-lg bg-slate-700 px-4 py-2 font-medium text-white hover:bg-slate-800"
                        >
                            Feed'e Dön
                        </Link>
                    </div>
                </div>
            </main>
        </ProtectedRoute>
    );
}