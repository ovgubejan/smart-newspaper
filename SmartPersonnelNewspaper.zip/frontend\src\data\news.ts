export type NewsItem = {
    id: number;
    title: string;
    category: string;
    source: string;
    date: string;
    popularity: number;
    summary: string;
    content: string;
};

export const allNews: NewsItem[] = [
    {
        id: 1,
        title: "AI teknolojileri hızla gelişiyor",
        category: "Technology",
        source: "Tech Daily",
        date: "2026-03-10",
        popularity: 95,
        summary:
            "Yapay zeka sistemleri birçok sektörde daha fazla kullanılmaya başladı.",
        content:
            "Yapay zeka artık eğitimden sağlığa, finanstan güvenliğe kadar birçok alanda aktif olarak kullanılmaya başlanmıştır. Bu gelişim, kurumların daha hızlı ve verimli karar almasına yardımcı olmaktadır.",
    },
    {
        id: 2,
        title: "Şirketler ekonomik büyümeye odaklanıyor",
        category: "Business",
        source: "Business World",
        date: "2026-03-12",
        popularity: 80,
        summary:
            "Kurumsal yatırımlar ve yeni stratejiler iş dünyasında öne çıkıyor.",
        content:
            "Kurumsal şirketler yeni dönem stratejilerini büyüme, verimlilik ve dijital dönüşüm üzerine kuruyor. Bu süreçte veri odaklı karar verme daha önemli hale geliyor.",
    },
    {
        id: 3,
        title: "Yeni sağlık araştırmaları umut veriyor",
        category: "Health",
        source: "Health News",
        date: "2026-03-15",
        popularity: 88,
        summary:
            "Sağlık alanındaki yeni araştırmalar dikkat çekici sonuçlar üretiyor.",
        content:
            "Son dönemde yapılan sağlık araştırmaları, erken teşhis ve kişiselleştirilmiş tedavi yöntemleri açısından umut verici sonuçlar ortaya koymaktadır.",
    },
    {
        id: 4,
        title: "Bilim dünyasında yeni keşifler yapıldı",
        category: "Science",
        source: "Science Globe",
        date: "2026-03-11",
        popularity: 72,
        summary:
            "Yeni bilimsel çalışmalar önemli sonuçlar ortaya koymaya başladı.",
        content:
            "Bilim dünyasında yapılan yeni araştırmalar, hem akademik hem de endüstriyel uygulamalar açısından dikkat çekici fırsatlar sunmaktadır.",
    },
    {
        id: 5,
        title: "Eğitim teknolojilerinde yeni dönem",
        category: "Education",
        source: "Edu Today",
        date: "2026-03-14",
        popularity: 67,
        summary:
            "Dijital eğitim araçları öğrenme deneyimini değiştirmeye devam ediyor.",
        content:
            "Eğitim teknolojileri, öğrenci takibi, kişiselleştirilmiş içerik ve uzaktan öğrenme süreçlerinde önemli katkılar sağlamaktadır.",
    },
];