# SmartPersonnelNewspaper - Frontend

This is a Next.js-based personalized news application.

## 🚀 Getting Started

To run the project locally, follow these steps:

### 1. Install Dependencies
```bash
npm install
```

### 2. Run the Development Server
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

---

## 📖 Partner Guide
A more detailed guide for project partners, including implemented features (SRS) and technical details, can be found in the root directory:
- [PROJECT_GUIDE.md](../PROJECT_GUIDE.md)

---

## 🛠 Tech Stack
- **Next.js 16** (App Router)
- **Tailwind CSS**
- **Prisma** (PostgreSQL)
- **LocalStorage** (Mock Authentication)
