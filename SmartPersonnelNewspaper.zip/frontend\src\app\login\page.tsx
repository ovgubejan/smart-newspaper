"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";

export default function LoginPage() {
    const router = useRouter();

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    const handleLogin = (e: FormEvent) => {
        e.preventDefault();
        setError("");

        const savedUser = localStorage.getItem("mockUser");

        if (!savedUser) {
            setError("Önce kayıt olmanız gerekiyor.");
            return;
        }

        const parsedUser = JSON.parse(savedUser);

        if (parsedUser.email === email && parsedUser.password === password) {
            localStorage.setItem(
                "currentUser",
                JSON.stringify({
                    fullName: parsedUser.fullName,
                    email: parsedUser.email,
                    role: "User",
                })
            );

            router.push("/preferences");
        } else {
            setError("E-posta veya şifre hatalı.");
        }
    };

    return (
        <main className="flex min-h-screen items-center justify-center bg-slate-100 px-4 py-10">
            <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900">Giriş Yap</h1>
                    <p className="mt-2 text-sm text-slate-600">
                        Hesabına giriş yaparak kişiselleştirilmiş haber akışına ulaş.
                    </p>
                </div>

                <form onSubmit={handleLogin} className="space-y-5">
                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            E-posta
                        </label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="ornek@mail.com"
                            className="w-full rounded-xl border border-slate-300 px-4 py-3 text-slate-900 placeholder:text-slate-500 outline-none transition focus:border-blue-500" />
                    </div>

                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Şifre
                        </label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Şifrenizi girin"
                            className="w-full rounded-xl border border-slate-300 px-4 py-3 text-slate-900 placeholder:text-slate-500 outline-none transition focus:border-blue-500" />
                    </div>

                    {error && (
                        <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">
                            {error}
                        </p>
                    )}

                    <button
                        type="submit"
                        className="w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white transition hover:bg-blue-700"
                    >
                        Giriş Yap
                    </button>
                </form>

                <p className="mt-6 text-center text-sm text-slate-600">
                    Hesabın yok mu?{" "}
                    <Link href="/register" className="font-semibold text-blue-600">
                        Kayıt Ol
                    </Link>
                </p>

                <div className="mt-6 text-center">
                    <Link href="/" className="text-sm text-slate-500 hover:text-slate-700">
                        Ana sayfaya dön
                    </Link>
                </div>
            </div>
        </main>
    );
}