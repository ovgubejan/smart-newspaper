"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";

export default function RegisterPage() {
    const router = useRouter();

    const [fullName, setFullName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [passwordRepeat, setPasswordRepeat] = useState("");
    const [error, setError] = useState("");

    const handleRegister = (e: FormEvent) => {
        e.preventDefault();
        setError("");

        if (!fullName || !email || !password || !passwordRepeat) {
            setError("Lütfen tüm alanları doldurun.");
            return;
        }

        if (password !== passwordRepeat) {
            setError("Şifreler eşleşmiyor.");
            return;
        }

        localStorage.setItem(
            "mockUser",
            JSON.stringify({
                fullName,
                email,
                password,
            })
        );

        router.push("/login");
    };

    return (
        <main className="flex min-h-screen items-center justify-center bg-slate-100 px-4 py-10">
            <div className="w-full max-w-lg rounded-2xl bg-white     p-8 shadow-lg">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900">Kayıt Ol</h1>
                    <p className="mt-2 text-sm text-slate-600">
                        Yeni hesap oluşturarak sistemi kullanmaya başla.
                    </p>
                </div>

                <form onSubmit={handleRegister} className="space-y-5">
                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Ad Soyad
                        </label>
                        <input
                            type="text"
                            value={fullName}
                            onChange={(e) => setFullName(e.target.value)}
                            placeholder="Ad Soyad"
                            className="w-full rounded-xl border border-slate-300 px-4 py-3 text-slate-900 placeholder:text-slate-500 outline-none transition focus:border-blue-500" />
                    </div>

                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            E-posta
                        </label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="ornek@mail.com"
                            className="w-full rounded-xl border border-slate-300 px-4 py-3 text-slate-900 placeholder:text-slate-500 outline-none transition focus:border-blue-500" />
                    </div>

                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Şifre
                        </label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Şifre oluştur"
                            className="w-full rounded-xl border border-slate-300 px-4 py-3 text-slate-900 placeholder:text-slate-500 outline-none transition focus:border-blue-500" />
                    </div>

                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Şifre Tekrar
                        </label>
                        <input
                            type="password"
                            value={passwordRepeat}
                            onChange={(e) => setPasswordRepeat(e.target.value)}
                            placeholder="Şifreyi tekrar gir"
                            className="w-full rounded-xl border border-slate-300 px-4 py-3 text-slate-900 placeholder:text-slate-500 outline-none transition focus:border-blue-500" />
                    </div>

                    {error && (
                        <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">
                            {error}
                        </p>
                    )}

                    <button
                        type="submit"
                        className="w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white transition hover:bg-blue-700"
                    >
                        Kayıt Ol
                    </button>
                </form>

                <p className="mt-6 text-center text-sm text-slate-600">
                    Zaten hesabın var mı?{" "}
                    <Link href="/login" className="font-semibold text-blue-600">
                        Giriş Yap
                    </Link>
                </p>

                <div className="mt-6 text-center">
                    <Link href="/" className="text-sm text-slate-500 hover:text-slate-700">
                        Ana sayfaya dön
                    </Link>
                </div>
            </div>
        </main>
    );
}