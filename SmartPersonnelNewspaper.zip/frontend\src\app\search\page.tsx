"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";
import { allNews } from "@/data/news";

export default function SearchPage() {
    const [query, setQuery] = useState("");
    const [selectedCategory, setSelectedCategory] = useState("All");
    const [selectedSource, setSelectedSource] = useState("All");
    const [sortBy, setSortBy] = useState("date");

    const categories = ["All", ...new Set(allNews.map((item) => item.category))];
    const sources = ["All", ...new Set(allNews.map((item) => item.source))];

    const filteredNews = useMemo(() => {
        let result = [...allNews];

        if (query.trim()) {
            result = result.filter((item) =>
                item.title.toLowerCase().includes(query.toLowerCase())
            );
        }

        if (selectedCategory !== "All") {
            result = result.filter((item) => item.category === selectedCategory);
        }

        if (selectedSource !== "All") {
            result = result.filter((item) => item.source === selectedSource);
        }

        if (sortBy === "date") {
            result.sort((a, b) => b.date.localeCompare(a.date));
        } else if (sortBy === "popularity") {
            result.sort((a, b) => b.popularity - a.popularity);
        } else if (sortBy === "title") {
            result.sort((a, b) => a.title.localeCompare(b.title));
        }

        return result;
    }, [query, selectedCategory, selectedSource, sortBy]);

    return (
        <ProtectedRoute>
            <Navbar />

            <main className="min-h-screen bg-slate-100 px-4 py-10">
                <div className="mx-auto max-w-5xl">
                    <h1 className="mb-6 text-3xl font-bold text-slate-900">Search</h1>

                    <div className="mb-6 grid gap-4 rounded-2xl bg-white p-5 shadow md:grid-cols-4">
                        <input
                            type="text"
                            placeholder="Haber ara..."
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            className="rounded-xl border border-slate-300 px-4 py-3 text-slate-900 placeholder:text-slate-500 outline-none focus:border-blue-500"
                        />

                        <select
                            value={selectedCategory}
                            onChange={(e) => setSelectedCategory(e.target.value)}
                            className="rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900"
                        >
                            {categories.map((cat) => (
                                <option key={cat} value={cat}>
                                    {cat}
                                </option>
                            ))}
                        </select>

                        <select
                            value={selectedSource}
                            onChange={(e) => setSelectedSource(e.target.value)}
                            className="rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900"
                        >
                            {sources.map((source) => (
                                <option key={source} value={source}>
                                    {source}
                                </option>
                            ))}
                        </select>

                        <select
                            value={sortBy}
                            onChange={(e) => setSortBy(e.target.value)}
                            className="rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900"
                        >
                            <option value="date">Tarihe Göre</option>
                            <option value="popularity">Popülerliğe Göre</option>
                            <option value="title">Başlığa Göre</option>
                        </select>
                    </div>

                    <div className="grid gap-4">
                        {filteredNews.map((news) => (
                            <Link
                                key={news.id}
                                href={`/article/${news.id}`}
                                className="block rounded-2xl bg-white p-5 shadow transition hover:bg-slate-50"
                            >
                                <div className="mb-3 flex flex-wrap items-center gap-2 text-sm">
                                    <span className="font-medium text-blue-600">
                                        {news.category}
                                    </span>
                                    <span className="text-slate-400">•</span>
                                    <span className="text-slate-600">{news.source}</span>
                                    <span className="text-slate-400">•</span>
                                    <span className="text-slate-600">{news.date}</span>
                                    <span className="text-slate-400">•</span>
                                    <span className="text-slate-600">
                                        Popularity: {news.popularity}
                                    </span>
                                </div>

                                <h2 className="mb-2 text-xl font-semibold text-slate-900">
                                    {news.title}
                                </h2>
                                <p className="text-slate-600">{news.summary}</p>
                            </Link>
                        ))}

                        {filteredNews.length === 0 && (
                            <div className="rounded-2xl bg-white p-5 text-slate-600 shadow">
                                Sonuç bulunamadı.
                            </div>
                        )}
                    </div>
                </div>
            </main>
        </ProtectedRoute>
    );
}