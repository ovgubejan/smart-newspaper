# 📋 Project Partner Guide: SmartPersonnelNewspaper

Welcome to the **SmartPersonnelNewspaper** project! This guide is designed to help you understand the current state of the project, the implemented features (SRS items), and how to get everything running on your machine.

---

## 🛠 Project Overview
This is a Next.js-based personalized news application. It currently uses a **Mock Data System** (stored in `localStorage` and static files) to demonstrate functionality without needing a complex backend setup immediately.

### Technical Stack
- **Framework**: Next.js 16 (App Router)
- **Styling**: Tailwind CSS
- **Database**: Prisma (Schema defined, not yet integrated into the UI logic)
- **State Management**: React Hooks + LocalStorage

---

## ✅ Implemented SRS Items
The following features are currently implemented and functional:

1. **[U-1] User Authentication**
   - **Registration**: Users can create a mock account (`/register`).
   - **Login**: Users can log in with their mock credentials (`/login`).
   - **Route Protection**: Sensitive pages (Feed, Search, etc.) are protected; unauthorized users are redirected to login.

2. **[A-1] News Aggregation & Display**
   - **Mock Data**: A collection of articles is available in `src/data/news.ts`.
   - **Article View**: Users can click on a news item to see the full content (`/article/[id]`).

3. **[A-2] Personalization**
   - **Preferences**: Users can select their favorite categories during the first login or in the preferences page (`/preferences`).
   - **Filtering**: The news feed automatically filters content based on these preferences.

4. **[A-3] Ranking & Sorting**
   - **Criteria**: Users can sort news by **Date**, **Popularity**, or **Relevance** on the Feed page.

5. **[U-2] Bookmarks**
   - Users can "Save" articles. Saved articles are listed in the `/bookmarks` page.

6. **[U-3] Read History**
   - The system tracks which articles have been read and marks them with a "Read" badge in the feed.

7. **[U-4] Search**
   - A functional search interface (`/search`) allows users to find specific news items.

---

## 🚀 How to Run the Project

Follow these steps to set up the project on your local machine:

### 1. Prerequisites
- **Node.js** (LTS version recommended)
- **npm** (comes with Node.js)

### 2. Installation
Extract the zip file, open your terminal in the `frontend` directory, and run:
```bash
npm install
```

### 3. Running the Server
Start the development server:
```bash
npm run dev
```
The app will be available at [http://localhost:3000](http://localhost:3000).

---

## 📂 Key File Structure
- `src/app/`: Contains all the pages (Next.js App Router).
- `src/components/`: Reusable UI components (Navbar, ProtectedRoute).
- `src/data/news.ts`: The mock database of news articles.
- `prisma/schema.prisma`: The planned database schema for PostgreSQL.

---

## 📝 Next Steps for Development
- **Database Integration**: Switch from `localStorage` to **Prisma + PostgreSQL** using the provided schema.
- **Admin Dashboard**: Implement the `ADMIN` role features.
- **Real API Integration**: Replace mock data with real news from an external API.

Happy coding! 🚀
